# PR 5306 Linux gate evidence

This bundle records the Linux proof for gate `pr-5306-reset-linux-gate-20261107` at offered source head `f9bc92c5a38b082a0dd3cc2fd1f1f64f54d1f22b` (`nick-boss-tech/solr:solr-18527-submit`), against contributor base `01c65183ab01411e292c90ba5ab10c1c7056c219`. It was run on `phone-agent-2` with Ubuntu 24.04.4, OpenJDK 21.0.12.1, BATS 1.10.0, and the serialized host Gradle lock.

## Results

- `tidy` and the following `git diff --exit-code` both passed; no source changes remained.
- The standard CLI integration task passed: 6 tests, 0 failures, 0 errors, 0 skips. The six tests cover secure-example startup and marked-directory rerun plus all four reset-safety cases.
- The Picocli task passed: 47 tests, 0 failures, 0 errors, 3 skips. All six required secure/reset tests passed without skips. Only three Docker-dependent Tika extraction cases in the configured suite were skipped because Docker is unavailable; this skip was explicitly allowed by the claim and user instruction.
- The final `./gradlew check -x test -Ptests.seed=18527C0FFEE` passed (exit 0), including CLI-doc freshness, local Antora/ref-guide site generation and site-link checking. The checkout at the assigned head stayed clean.
- The contributor-base negative control ran the copied reset test as the only untracked file and failed as expected: the unowned-home case's command succeeded when it should have been refused. The baseline JUnit records 4 assertion failures, 0 errors and 0 skips.

The first check attempt encountered a remote Antora UI-bundle download timeout. A later attempt failed in the CLI-doc generator while two local Solr processes from the failing baseline control were still running. Those two gate-owned processes were stopped after verifying their command lines; the final exact-head check then passed. No live Solr test nodes remained afterward. Across 631 inode samples, minimum free inodes were 20.9295%, above the 15% stop threshold.

The raw baseline JUnit XML is included unchanged. It has 1,408 literal backspace control characters from progress output, so a separate visibly escaped copy is included and was parsed successfully. Both reports show the same four assertion failures.

## Contents

`commands.txt`, `exit-codes.tsv`, `environment.txt`, source/base heads and the exact reset test establish provenance. `tidy.log`, both positive BATS logs and their JUnit reports, baseline logs/reports, three check logs (two earlier failures and the final passing run), per-command inode samples, and cleanup records preserve the proof and retry history. `source/test_secure_example_reset.bats` is the exact test file used in the baseline copy; its SHA-256 sidecar is included. `SHA256SUMS` hashes the files in this bundle other than itself; the board evidence pointer hashes the compressed bundle.
