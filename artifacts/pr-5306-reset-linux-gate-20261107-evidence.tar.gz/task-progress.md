# PR 5306 Linux gate — final result

**Verdict: passed** for source head `f9bc92c5a38b082a0dd3cc2fd1f1f64f54d1f22b` on `nick-boss-tech/solr:solr-18527-submit`; contributor base was `01c65183ab01411e292c90ba5ab10c1c7056c219`. Active board: `nick-boss-tech/solr:coordination-v2`.

## Proof results

- `./gradlew tidy`: exit 0. `git diff --exit-code`: exit 0; the offered source tree remained clean.
- `./gradlew :solr:packaging:integrationTests --tests test_secure_example.bats --tests test_secure_example_reset.bats -Ptests.seed=18527C0FFEE`: exit 0; JUnit has 6 tests, 0 failures, 0 errors, 0 skips. This includes the secure-example startup and marked-directory rerun plus all four reset-safety cases.
- `./gradlew :solr:packaging:integrationTestsPicocli --tests test_secure_example.bats --tests test_secure_example_reset.bats -Ptests.seed=18527C0FFEE`: exit 0; JUnit has 47 tests, 0 failures, 0 errors, 3 skips. All six required secure-example/reset cases passed without skips in this mode. The only skips were three Docker-dependent Tika extraction cases in `test_extraction.bats`; Docker is unavailable, and the existing claim authorizes those skips.
- Final `./gradlew check -x test -Ptests.seed=18527C0FFEE`: exit 0 after cleaning the isolated baseline-test processes. `checkCliDocsUpToDate`, `buildLocalAntoraSite`, `buildLocalSite`, `checkSiteLinks`, and the top-level check passed. The source tree remained clean.
- Baseline negative control: at the exact contributor base, the required BATS file was absent from the base tree and was the only untracked file after copying it from the offered head. The required Gradle command returned 1 with the unowned-home case failing for the intended reason: `assert_failure` reported that the secure-example command succeeded when it was expected to fail. The JUnit summary is 4 tests, 4 assertion failures, 0 errors, 0 skips. All test homes and the fake installation were under BATS temp directories.

## Environment and cleanup

The host was the authorized Linux `phone-agent-2` sandbox with Ubuntu 24.04.4, OpenJDK 21.0.12.1, BATS 1.10.0, Git, curl and OpenSSL. Docker was not installed. Builds and tests ran serially behind `/workspace/tools/.gradle-phone-agent-2.lock` with the inode guard and live watcher. Across 631 samples, the minimum free-inode percentage was 20.9295%, above the 15% stop floor.

The first full check attempt timed out downloading the Antora UI bundle. A later check attempt, made while the failing baseline suite had left two local Solr test nodes running, crashed the CLI-doc generator. Both nodes were verified as gate-owned and stopped; the isolated BATS homes, partial bundle download and disposable base checkout were removed. The final exact-head check then passed. No source, PR, Jira or original `/workspace/solr` coordination-ui work was modified.

The raw baseline JUnit XML is preserved, but includes 1,408 literal backspace control characters from CLI progress output and is not accepted by strict XML 1.0 parsers. The raw file is unchanged; a separate visibly escaped copy was parsed to confirm the same four assertion failures.

## Evidence

All evidence is preserved under `/workspace/gates/logs/phone-agent-2/pr5306-reset-linux-gate-20261107/`, including exact commands, exit codes, environment/head records, full logs, JUnit XML, raw and sanitized baseline reports, inode samples, cleanup record and SHA-256 manifest. The exact source test file and its hash are also preserved. The final board receipt will link a public evidence bundle and its hash.

## Board references and publication rules

The refreshed `coordination-v2` tip before posting was `2ecdbc19567dbaaac665ded6b751f1e7605b7120`. Current assignment: https://raw.githubusercontent.com/nick-boss-tech/solr/coordination-v2/records/assignment/pr-5306-reset-linux-gate-20261107.json. Current gate requirements: https://raw.githubusercontent.com/nick-boss-tech/solr/coordination-v2/records/gate/pr-5306-reset-linux-gate-20261107.json. Board workflow: https://raw.githubusercontent.com/nick-boss-tech/solr/coordination-v2/WORKFLOW.md. Board writer/evidence instructions: https://raw.githubusercontent.com/nick-boss-tech/solr/coordination-v2/tools/README.md. The current claim is at `records/claim/pr-5306-reset-linux-gate-20261107.json`, owner `phone-agent-2`.

The live writer requires `tools/board.py publish --remote origin --branch coordination-v2 --file RECORD.json` for create-only JSON records. The evidence subcommand only computes a SHA-256 pointer; it does not upload or verify the artifact. Upload the evidence bundle to an authorized HTTPS evidence store and independently verify the retrieved bytes before publishing its pointer. Publish the final receipt and report before the canonical release record. Claims remain immutable; the release is terminal for this job.
