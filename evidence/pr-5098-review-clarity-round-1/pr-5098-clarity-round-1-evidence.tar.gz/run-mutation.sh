#!/bin/bash
# PR 5098 clarity gate: configuration-sensitivity mutation + restored rerun. Host lock held.
set -u
OUT=~/workspace/tools/gate-5098
H=981b7c230bdd1428b60867dd1ea700576b94b393
MUT=~/workspace/solr-clones/5098-mut
HELPER=solr/test-framework/src/java/org/apache/solr/cloud/AbstractFullDistribZkTestBase.java
TEST=solr/core/src/test/org/apache/solr/cloud/RecoveryAfterSoftCommitTest.java
SEED=A57A22E346C237C6
G=~/workspace/tools/solr-gradle.sh
mkdir -p $OUT
exec 9>~/workspace/tools/.solr-test-queue.lock
flock 9
exec > >(tee -a $OUT/mutation.log) 2>&1
echo "mutation start UTC: $(date -u +%FT%TZ)"
pkill -f "Gradle[D]aemon" 2>/dev/null; sleep 2
rm -f ~/.gradle/caches/journal-1/journal-1.lock
cd $MUT || exit 1
git checkout -q -- . 2>/dev/null; git checkout -q $H
python3 - <<'PYEOF'
p = 'solr/test-framework/src/java/org/apache/solr/cloud/AbstractFullDistribZkTestBase.java'
s = open(p).read()
old = "      builder.sendDirectUpdatesToShardLeadersOnly();\n"
assert s.count(old) == 1, "mutation anchor count != 1"
open(p, 'w').write(s.replace(old, ""))
print("call omitted")
PYEOF
echo "MUT HEAD: $(git rev-parse HEAD)"
git diff | tee $OUT/mutation.diff
sha256sum $HELPER $TEST | tee $OUT/mutation-hashes.txt
echo "=== mutation run start UTC: $(date -u +%FT%TZ)"
$G :solr:core:cleanTest :solr:core:test --tests org.apache.solr.cloud.RecoveryAfterSoftCommitTest.test -Ptests.seed=$SEED 9>&- > $OUT/mutation-run.log 2>&1
echo "mutation run rc=$?"
mkdir -p $OUT/xml-mutation
find $MUT -path "*build/test-results/test/TEST-org.apache.solr.cloud.RecoveryAfterSoftCommitTest.xml" -exec cp {} $OUT/xml-mutation/ \; 2>/dev/null
ls $OUT/xml-mutation/
git checkout -q -- $HELPER
echo "restored; status (excl gradle.properties): $(git status --porcelain | grep -v gradle.properties | wc -l)"
sha256sum $HELPER | tee $OUT/restored-hashes.txt
echo "=== restored rerun start UTC: $(date -u +%FT%TZ)"
$G :solr:core:cleanTest :solr:core:test --tests org.apache.solr.cloud.RecoveryAfterSoftCommitTest.test -Ptests.seed=$SEED 9>&- > $OUT/restored-run.log 2>&1
echo "restored run rc=$?"
mkdir -p $OUT/xml-restored
find $MUT -path "*build/test-results/test/TEST-org.apache.solr.cloud.RecoveryAfterSoftCommitTest.xml" -exec cp {} $OUT/xml-restored/ \; 2>/dev/null
ls $OUT/xml-restored/
echo "mutation end UTC: $(date -u +%FT%TZ)"
