#!/bin/bash
# PR 5098 clarity gate preflight at H: root tidy + diff check. Host lock held.
set -u
OUT=~/workspace/tools/gate-5098
H=981b7c230bdd1428b60867dd1ea700576b94b393
POS=~/workspace/solr-clones/5098-pos
G=~/workspace/tools/solr-gradle.sh
mkdir -p $OUT
exec 9>~/workspace/tools/.solr-test-queue.lock
flock 9
exec > >(tee -a $OUT/preflight.log) 2>&1
echo "preflight start UTC: $(date -u +%FT%TZ)"
df -h /home/hatch | tail -1
pkill -f "Gradle[D]aemon" 2>/dev/null; sleep 2
rm -f ~/.gradle/caches/journal-1/journal-1.lock
cd $POS || exit 1
echo "POS HEAD: $(git rev-parse HEAD) (expect $H)"
echo "=== root tidy start UTC: $(date -u +%FT%TZ)"
$G tidy 9>&- > $OUT/tidy.log 2>&1
echo "tidy rc=$?"
git status --porcelain | grep -v '^?? gradle.properties$' | tee $OUT/tidy-status.txt
if [ -s $OUT/tidy-status.txt ]; then echo "TIDY_DIRTY"; else echo "TIDY_CLEAN"; fi
git checkout -- gradle/libs.versions.toml 2>/dev/null
git diff --check > $OUT/diffcheck.log 2>&1; echo "git diff --check rc=$?"
echo "preflight end UTC: $(date -u +%FT%TZ)"
