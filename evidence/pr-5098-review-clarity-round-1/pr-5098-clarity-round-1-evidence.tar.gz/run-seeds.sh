#!/bin/bash
# PR 5098 clarity gate: six seed runs + root check at H. Host lock held.
set -u
OUT=~/workspace/tools/gate-5098
H=981b7c230bdd1428b60867dd1ea700576b94b393
POS=~/workspace/solr-clones/5098-pos
G=~/workspace/tools/solr-gradle.sh
mkdir -p $OUT
exec 9>~/workspace/tools/.solr-test-queue.lock
flock 9
exec > >(tee -a $OUT/seeds.log) 2>&1
echo "seeds start UTC: $(date -u +%FT%TZ)"
pkill -f "Gradle[D]aemon" 2>/dev/null; sleep 2
rm -f ~/.gradle/caches/journal-1/journal-1.lock
cd $POS || exit 1
echo "POS HEAD: $(git rev-parse HEAD) (expect $H)"
for SEED in A57A22E346C237C6 18530C0DE0000001 18530C0DE0000002 18530C0DE0000003 18530C0DE0000004 18530C0DE0000005; do
  echo "=== seed $SEED start UTC: $(date -u +%FT%TZ)"
  $G :solr:core:cleanTest :solr:core:test --tests org.apache.solr.cloud.RecoveryAfterSoftCommitTest.test -Ptests.seed=$SEED 9>&- > $OUT/seed-$SEED.log 2>&1
  echo "seed $SEED rc=$?"
  mkdir -p $OUT/xml-$SEED
  find $POS -path "*build/test-results/test/TEST-org.apache.solr.cloud.RecoveryAfterSoftCommitTest.xml" -exec cp {} $OUT/xml-$SEED/ \; 2>/dev/null
  ls $OUT/xml-$SEED/
done
echo "=== root check start UTC: $(date -u +%FT%TZ)"
$G check -x test 9>&- > $OUT/rootcheck.log 2>&1
echo "root check rc=$?"
echo "POS final status (excl gradle.properties): $(git status --porcelain | grep -v gradle.properties | wc -l)"
echo "seeds end UTC: $(date -u +%FT%TZ)"
