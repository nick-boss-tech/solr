#!/bin/bash
# PR 5301 round 3 controlled comparison: H3 with flap() reverted to close/reopen, stress once at the failed seed. Host lock held.
set -u
OUT=~/workspace/tools/gate-5301-r3
H3=dfde9bde0a348ad44e6f6ceec197d478ef11bfd0
CMP=~/workspace/solr-clones/5301-cmp
ST=solr/core/src/test/org/apache/solr/cloud/TestConnectionManagerReconnectStress.java
SEED=5301C0DE
G8=~/workspace/tools/solr-gradle8.sh
mkdir -p $OUT
exec 9>~/workspace/tools/.solr-test-queue.lock
flock 9
exec > >(tee -a $OUT/comparison.log) 2>&1
echo "comparison start UTC: $(date -u +%FT%TZ)"
pkill -f "Gradle[D]aemon" 2>/dev/null; sleep 2
rm -f ~/.gradle/caches/journal-1/journal-1.lock
cd $CMP || exit 1
git checkout -q -- . 2>/dev/null; git checkout -q $H3
python3 - <<'PYEOF'
p = 'solr/core/src/test/org/apache/solr/cloud/TestConnectionManagerReconnectStress.java'
s = open(p).read()
old = """      // Drop the client connection without rebinding the listener during reconnect.
      proxy.halfClose();"""
new = """      proxy.close();
      proxy.reopen();"""
assert s.count(old) == 1, "comparison anchor not found"
open(p, 'w').write(s.replace(old, new))
print("flap reverted to close/reopen")
PYEOF
echo "CMP HEAD: $(git rev-parse HEAD)"
git diff | tee $OUT/cmp-mutation.diff
sha256sum $ST | tee $OUT/cmp-hashes.txt
echo "=== comparison stress start UTC: $(date -u +%FT%TZ)"
$G8 :solr:core:cleanTest :solr:core:test --tests org.apache.solr.cloud.TestConnectionManagerReconnectStress -Ptests.nightly=true -Ptests.seed=$SEED --rerun-tasks 9>&- > $OUT/cmp-stress.log 2>&1
echo "comparison stress rc=$?"
mkdir -p $OUT/cmp-xml
find $CMP -path "*build/test-results/test/TEST-org.apache.solr.cloud.TestConnectionManagerReconnectStress.xml" -exec cp {} $OUT/cmp-xml/ \; 2>/dev/null
ls $OUT/cmp-xml/
git checkout -q -- $ST
echo "CMP restored; status lines: $(git status --porcelain | wc -l)"
echo "comparison end UTC: $(date -u +%FT%TZ)"
