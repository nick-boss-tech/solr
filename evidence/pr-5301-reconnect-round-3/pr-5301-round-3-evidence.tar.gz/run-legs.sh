#!/bin/bash
# PR 5301 round 3 positive legs at H3: EP tolerated compile, ordering suites, zkclient, stress x2, root check. Host lock held.
set -u
OUT=~/workspace/tools/gate-5301-r3
H3=dfde9bde0a348ad44e6f6ceec197d478ef11bfd0
POS=~/workspace/solr-clones/5301-pos
SEED=5301C0DE
G8=~/workspace/tools/solr-gradle8.sh
mkdir -p $OUT
exec 9>~/workspace/tools/.solr-test-queue.lock
flock 9
exec > >(tee -a $OUT/legs.log) 2>&1
echo "legs start UTC: $(date -u +%FT%TZ)"
pkill -f "Gradle[D]aemon" 2>/dev/null; sleep 2
rm -f ~/.gradle/caches/journal-1/journal-1.lock
copyxml() { mkdir -p $OUT/$2-xml; find $1 -path "*build/test-results/test/TEST-*.xml" -exec cp {} $OUT/$2-xml/ \; 2>/dev/null; ls $OUT/$2-xml/; }
cd $POS || exit 1
echo "POS HEAD: $(git rev-parse HEAD) (expect $H3)"
echo "=== EP compile (warning-tolerant) start UTC: $(date -u +%FT%TZ)"
$G8 :solr:solrj-zookeeper:compileJava :solr:core:compileTestJava -Pvalidation.errorprone=true -Pjavac.failOnWarnings=false 9>&- > $OUT/ep.log 2>&1
echo "EP rc=$?"
grep -E "warning: \[" $OUT/ep.log | sort | uniq -c | head
echo "=== ordering suites start UTC: $(date -u +%FT%TZ)"
$G8 :solr:core:cleanTest :solr:core:test --tests org.apache.solr.common.cloud.ConnectionManagerOrderingTest --tests org.apache.solr.cloud.ConnectionManagerTest -Ptests.seed=$SEED --rerun-tasks 9>&- > $OUT/ordering.log 2>&1
echo "ordering rc=$?"
copyxml $POS ordering
echo "=== zkclient start UTC: $(date -u +%FT%TZ)"
$G8 :solr:solrj-zookeeper:cleanTest :solr:solrj-zookeeper:test --tests org.apache.solr.common.cloud.SolrZkClientTest -Ptests.seed=$SEED --rerun-tasks 9>&- > $OUT/zkclient.log 2>&1
echo "zkclient rc=$?"
copyxml $POS zkclient
for i in 1 2; do
  echo "=== stress run $i start UTC: $(date -u +%FT%TZ)"
  $G8 :solr:core:cleanTest :solr:core:test --tests org.apache.solr.cloud.TestConnectionManagerReconnectStress -Ptests.nightly=true -Ptests.seed=$SEED --rerun-tasks 9>&- > $OUT/stress$i.log 2>&1
  echo "stress $i rc=$?"
  copyxml $POS stress$i
done
echo "=== root check start UTC: $(date -u +%FT%TZ)"
$G8 check -x test 9>&- > $OUT/rootcheck.log 2>&1
echo "root check rc=$?"
echo "POS final status lines: $(git status --porcelain | wc -l)"
echo "legs end UTC: $(date -u +%FT%TZ)"
