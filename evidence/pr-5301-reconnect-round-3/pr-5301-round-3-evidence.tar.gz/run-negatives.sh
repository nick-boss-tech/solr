#!/bin/bash
# PR 5301 round 3 negative legs at H3: A (H0 production blob), B (accept-all mutation). Host lock held.
set -u
OUT=~/workspace/tools/gate-5301-r3
H3=dfde9bde0a348ad44e6f6ceec197d478ef11bfd0
H0=01e820f0539cddc4697d26176d216614a776a99a
NEA=~/workspace/solr-clones/5301-nega
NEB=~/workspace/solr-clones/5301-negb
CM=solr/solrj-zookeeper/src/java/org/apache/solr/common/cloud/ConnectionManager.java
SEED=5301C0DE
G8=~/workspace/tools/solr-gradle8.sh
mkdir -p $OUT
exec 9>~/workspace/tools/.solr-test-queue.lock
flock 9
exec > >(tee -a $OUT/negatives.log) 2>&1
echo "negatives start UTC: $(date -u +%FT%TZ)"
pkill -f "Gradle[D]aemon" 2>/dev/null; sleep 2
rm -f ~/.gradle/caches/journal-1/journal-1.lock
copyxml() { mkdir -p $OUT/$2-xml; find $1 -path "*build/test-results/test/TEST-*.xml" -exec cp {} $OUT/$2-xml/ \; 2>/dev/null; ls $OUT/$2-xml/; }
# Negative A
cd $NEA || exit 1
git checkout -q -- . 2>/dev/null; git checkout -q $H3
git fetch -q https://github.com/apache/solr.git refs/pull/5301/head:refs/heads/pr5301h0 || echo "PR ref fetch failed"
git show pr5301h0:$CM > $CM
echo "NEA HEAD: $(git rev-parse HEAD)"
git diff --stat | tee $OUT/nega-diff.txt
sha256sum $CM solr/core/src/test/org/apache/solr/common/cloud/ConnectionManagerOrderingTest.java | tee $OUT/nega-hashes.txt
echo "=== negative A start UTC: $(date -u +%FT%TZ)"
$G8 :solr:core:cleanTest :solr:core:test --tests org.apache.solr.common.cloud.ConnectionManagerOrderingTest.testExpiredReplacementDoesNotBlockRecovery -Ptests.seed=$SEED --rerun-tasks 9>&- > $OUT/nega.log 2>&1
echo "negative A rc=$?"
copyxml $NEA nega
git checkout -q -- $CM
# Negative B
cd $NEB || exit 1
git checkout -q -- . 2>/dev/null; git checkout -q $H3
python3 - <<'PYEOF'
p = 'solr/solrj-zookeeper/src/java/org/apache/solr/common/cloud/ConnectionManager.java'
s = open(p).read()
old = """  private synchronized boolean acceptStateEvent(long sequence) {
    if (sequence < lastStateEventSequence) {
      return false;
    }
    lastStateEventSequence = sequence;
    return true;
  }"""
new = """  private synchronized boolean acceptStateEvent(long sequence) {
    return true;
  }"""
assert s.count(old) == 1, "mutation anchor not found"
open(p, 'w').write(s.replace(old, new))
print("mutation applied")
PYEOF
echo "NEB HEAD: $(git rev-parse HEAD)"
git diff | tee $OUT/negb-mutation.diff | head -20
sha256sum $CM solr/core/src/test/org/apache/solr/common/cloud/ConnectionManagerOrderingTest.java | tee $OUT/negb-hashes.txt
echo "=== negative B start UTC: $(date -u +%FT%TZ)"
$G8 :solr:core:cleanTest :solr:core:test --tests org.apache.solr.common.cloud.ConnectionManagerOrderingTest.testStaleDisconnectedDoesNotUndoConnectedState --tests org.apache.solr.common.cloud.ConnectionManagerOrderingTest.testStaleConnectedDoesNotUndoDisconnectedState --tests org.apache.solr.common.cloud.ConnectionManagerOrderingTest.testStaleConnectedDoesNotClearExpiredState -Ptests.seed=$SEED --rerun-tasks 9>&- > $OUT/negb.log 2>&1
echo "negative B rc=$?"
copyxml $NEB negb
git checkout -q -- $CM
echo "negatives end UTC: $(date -u +%FT%TZ)"
