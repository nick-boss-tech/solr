#!/bin/bash
# PR 5301 round 3 preflight at H3: root tidy, diff check, changelog generation, validateSourcePatterns. Host lock held.
set -u
OUT=~/workspace/tools/gate-5301-r3
H3=dfde9bde0a348ad44e6f6ceec197d478ef11bfd0
POS=~/workspace/solr-clones/5301-pos
G8=~/workspace/tools/solr-gradle8.sh
mkdir -p $OUT
exec 9>~/workspace/tools/.solr-test-queue.lock
flock 9
exec > >(tee -a $OUT/preflight.log) 2>&1
echo "preflight start UTC: $(date -u +%FT%TZ)"
df -h /home/hatch | tail -1
pkill -f "Gradle[D]aemon" 2>/dev/null; sleep 2
rm -f ~/.gradle/caches/journal-1/journal-1.lock
cd $POS || exit 1
echo "POS HEAD: $(git rev-parse HEAD) (expect $H3)"
git status --porcelain | head -3
echo "=== root tidy start UTC: $(date -u +%FT%TZ)"
$G8 tidy 9>&- > $OUT/tidy.log 2>&1
echo "tidy rc=$?"
git status --porcelain | tee $OUT/tidy-status.txt
if [ -s $OUT/tidy-status.txt ]; then echo "TIDY_DIRTY"; else echo "TIDY_CLEAN"; fi
git diff --check > $OUT/diffcheck.log 2>&1; echo "git diff --check rc=$?"
echo "=== logchangeGenerate start UTC: $(date -u +%FT%TZ)"
$G8 logchangeGenerate 9>&- > $OUT/logchange.log 2>&1
echo "logchangeGenerate rc=$?"
grep -c "SOLR-18623" CHANGELOG.md 2>/dev/null
grep -n "SOLR-18623" CHANGELOG.md 2>/dev/null | head -3
cp CHANGELOG.md $OUT/CHANGELOG-generated.md 2>/dev/null
git checkout -q -- CHANGELOG.md 2>/dev/null; rm -f changelog/unreleased/version-summary.md
echo "generated output restored; status lines: $(git status --porcelain | wc -l)"
echo "=== validateSourcePatterns start UTC: $(date -u +%FT%TZ)"
$G8 :solr:core:validateSourcePatterns 9>&- > $OUT/sourcepatterns.log 2>&1
echo "validateSourcePatterns rc=$?"
tail -3 $OUT/sourcepatterns.log
echo "preflight end UTC: $(date -u +%FT%TZ)"
