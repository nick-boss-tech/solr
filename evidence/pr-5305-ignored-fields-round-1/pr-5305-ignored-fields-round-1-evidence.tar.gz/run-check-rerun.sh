#!/bin/bash
# PR 5305 gate round 1: root check rerun after seeding the correct UI wasm zip
# (first attempt failed at :solr:webapp:verifyUiWasm on a relay-corrupted download).
set -u
OUT=~/workspace/tools/gate-5305
F=219fee78bf7cae5039e50fe885108a1d4937ccd3
POS=~/workspace/solr-clones/5305-pos
G=~/workspace/tools/solr-gradle.sh
mkdir -p $OUT
exec 9>~/workspace/tools/.solr-test-queue.lock
flock 9
exec > >(tee -a $OUT/check-rerun.log) 2>&1
echo "check rerun start UTC: $(date -u +%FT%TZ)"
pkill -f "Gradle[D]aemon" 2>/dev/null; sleep 2
rm -f ~/.gradle/caches/journal-1/journal-1.lock
cd $POS || exit 1
echo "HEAD: $(git rev-parse HEAD) tree: $(git rev-parse HEAD^{tree})"
[ "$(git rev-parse HEAD)" = "$F" ] || { echo "HEAD != F"; exit 1; }
sha256sum solr/webapp/build/ui-download/solr-ui-wasm-473a55ef64a9a1605e00eb6c1c386887d4cb7dac.zip
JAVA_TOOL_OPTIONS=-Djavax.net.ssl.trustStore=$HOME/workspace/tools/truststore-with-hatch-ca.jks $G check -x test 9>&- > $OUT/p5b-check.log 2>&1
echo "check rerun rc=$?"
tail -4 $OUT/p5b-check.log
git checkout -- gradle/libs.versions.toml 2>/dev/null; true
echo "final status (excl gradle.properties): $(git status --porcelain | grep -v gradle.properties | wc -l)"
echo "check rerun end UTC: $(date -u +%FT%TZ)"
