#!/bin/bash
# PR 5305 ignored-fields gate round 1: fail-before legs (O implementations, F tests). Host lock held.
set -u
OUT=~/workspace/tools/gate-5305
F=219fee78bf7cae5039e50fe885108a1d4937ccd3
O=00292cd3729126194235e939afe38e351d850c70
FB=~/workspace/solr-clones/5305-fb
G=~/workspace/tools/solr-gradle.sh
SEED=18627C0DE
mkdir -p $OUT
exec 9>~/workspace/tools/.solr-test-queue.lock
flock 9
exec > >(tee -a $OUT/failbefore.log) 2>&1
echo "fail-before start UTC: $(date -u +%FT%TZ)"
pkill -f "Gradle[D]aemon" 2>/dev/null; sleep 2
rm -f ~/.gradle/caches/journal-1/journal-1.lock
cd $FB || exit 1
git checkout -q -- . 2>/dev/null; git checkout -q $F
cp ~/workspace/solr/gradle.properties . 2>/dev/null; true
echo "HEAD: $(git rev-parse HEAD) tree: $(git rev-parse HEAD^{tree})"
SEVEN="solr/core/src/java/org/apache/solr/schema/BinaryField.java solr/core/src/java/org/apache/solr/schema/BoolField.java solr/core/src/java/org/apache/solr/schema/CollationField.java solr/core/src/java/org/apache/solr/schema/SortableTextField.java solr/core/src/java/org/apache/solr/schema/TrieField.java solr/modules/analysis-extras/src/java/org/apache/solr/schema/ICUCollationField.java solr/test-framework/src/java/org/apache/solr/schema/SortableBinaryField.java"
TESTS="solr/core/src/test/org/apache/solr/schema/PrimitiveFieldTypeTest.java solr/modules/analysis-extras/src/test/org/apache/solr/schema/TestICUCollationField.java"
echo "--- test files at F (sha256 of worktree file vs F blob) ---" | tee $OUT/fb-hashes.txt
for t in $TESTS; do
  echo "$t worktree $(sha256sum $t | cut -d' ' -f1) F-blob $(git show $F:$t | sha256sum | cut -d' ' -f1)" >> $OUT/fb-hashes.txt
done
cat $OUT/fb-hashes.txt
git restore --source=$O -- $SEVEN
echo "--- restored files: worktree sha256 vs O blob sha256 ---" >> $OUT/fb-hashes.txt
ok=1
for f in $SEVEN; do
  w=$(sha256sum $f | cut -d' ' -f1); b=$(git show $O:$f | sha256sum | cut -d' ' -f1)
  echo "$f worktree $w O-blob $b" >> $OUT/fb-hashes.txt
  [ "$w" = "$b" ] || ok=0
done
cat $OUT/fb-hashes.txt
echo "restored byte-identical to O: $ok"
git add -- $SEVEN
echo "overlay write-tree: $(git write-tree)" | tee $OUT/fb-overlay-tree.txt
git diff --cached > $OUT/fb-overlay.diff
echo "overlay diff files: $(git diff --cached --name-only | wc -l)"
for t in $TESTS; do
  w=$(sha256sum $t | cut -d' ' -f1); b=$(git show $F:$t | sha256sum | cut -d' ' -f1)
  echo "test unchanged after restore: $t $([ "$w" = "$b" ] && echo YES || echo NO)"
done

echo "=== FB1 core PrimitiveFieldTypeTest start UTC: $(date -u +%FT%TZ)"
$G :solr:core:cleanTest :solr:core:test --tests org.apache.solr.schema.PrimitiveFieldTypeTest -Ptests.seed=$SEED -Ptests.failfast=false -Ptests.maxfailures=100 9>&- > $OUT/fb1.log 2>&1
echo "FB1 rc=$?"
mkdir -p $OUT/xml-fb1 && find $FB/solr/core/build/test-results -name 'TEST-org.apache.solr.schema.PrimitiveFieldTypeTest.xml' -exec cp {} $OUT/xml-fb1/ \; 2>/dev/null; ls $OUT/xml-fb1/

echo "=== FB2 analysis-extras TestICUCollationField start UTC: $(date -u +%FT%TZ)"
$G :solr:modules:analysis-extras:cleanTest :solr:modules:analysis-extras:test --tests org.apache.solr.schema.TestICUCollationField -Ptests.seed=$SEED -Ptests.failfast=false -Ptests.maxfailures=100 9>&- > $OUT/fb2.log 2>&1
echo "FB2 rc=$?"
mkdir -p $OUT/xml-fb2 && find $FB/solr/modules/analysis-extras/build/test-results -name 'TEST-org.apache.solr.schema.TestICUCollationField.xml' -exec cp {} $OUT/xml-fb2/ \; 2>/dev/null; ls $OUT/xml-fb2/

echo "=== FB3 control BasicFunctionalityTest.testIgnoredFields start UTC: $(date -u +%FT%TZ)"
$G :solr:core:cleanTest :solr:core:test --tests org.apache.solr.BasicFunctionalityTest.testIgnoredFields -Ptests.seed=$SEED 9>&- > $OUT/fb3.log 2>&1
echo "FB3 rc=$?"
mkdir -p $OUT/xml-fb3 && find $FB/solr/core/build/test-results -name 'TEST-org.apache.solr.BasicFunctionalityTest.xml' -exec cp {} $OUT/xml-fb3/ \; 2>/dev/null; ls $OUT/xml-fb3/
echo "fail-before end UTC: $(date -u +%FT%TZ)"
