#!/bin/bash
# PR 5305 ignored-fields gate round 1: positive legs + root check at exact F. Host lock held.
set -u
OUT=~/workspace/tools/gate-5305
F=219fee78bf7cae5039e50fe885108a1d4937ccd3
POS=~/workspace/solr-clones/5305-pos
G=~/workspace/tools/solr-gradle.sh
SEED=18627C0DE
mkdir -p $OUT
exec 9>~/workspace/tools/.solr-test-queue.lock
flock 9
exec > >(tee -a $OUT/positive.log) 2>&1
echo "positive start UTC: $(date -u +%FT%TZ)"
pkill -f "Gradle[D]aemon" 2>/dev/null; sleep 2
rm -f ~/.gradle/caches/journal-1/journal-1.lock
cd $POS || exit 1
git checkout -q -- . 2>/dev/null; git checkout -q $F
cp ~/workspace/solr/gradle.properties . 2>/dev/null; true
echo "HEAD: $(git rev-parse HEAD) tree: $(git rev-parse HEAD^{tree})"
[ "$(git rev-parse HEAD)" = "$F" ] || { echo "HEAD != F"; exit 1; }

echo "=== P0 tidy at clean F start UTC: $(date -u +%FT%TZ)"
$G tidy 9>&- > $OUT/p0-tidy.log 2>&1
echo "tidy rc=$?"
git checkout -- gradle/libs.versions.toml 2>/dev/null; true
echo "tracked changes after tidy (excl gradle.properties): $(git status --porcelain | grep -v gradle.properties | wc -l)"
git diff --check > $OUT/p0-diffcheck.log 2>&1; echo "diff-check rc=$?"

echo "=== P1 core PrimitiveFieldTypeTest start UTC: $(date -u +%FT%TZ)"
$G :solr:core:cleanTest :solr:core:test --tests org.apache.solr.schema.PrimitiveFieldTypeTest -Ptests.seed=$SEED 9>&- > $OUT/p1.log 2>&1
echo "P1 rc=$?"
mkdir -p $OUT/xml-p1 && find $POS/solr/core/build/test-results -name 'TEST-org.apache.solr.schema.PrimitiveFieldTypeTest.xml' -exec cp {} $OUT/xml-p1/ \; 2>/dev/null; ls $OUT/xml-p1/

echo "=== P2 analysis-extras TestICUCollationField start UTC: $(date -u +%FT%TZ)"
$G :solr:modules:analysis-extras:cleanTest :solr:modules:analysis-extras:test --tests org.apache.solr.schema.TestICUCollationField -Ptests.seed=$SEED 9>&- > $OUT/p2.log 2>&1
echo "P2 rc=$?"
mkdir -p $OUT/xml-p2 && find $POS/solr/modules/analysis-extras/build/test-results -name 'TEST-org.apache.solr.schema.TestICUCollationField.xml' -exec cp {} $OUT/xml-p2/ \; 2>/dev/null; ls $OUT/xml-p2/

echo "=== P3 core neighboring suites start UTC: $(date -u +%FT%TZ)"
$G :solr:core:cleanTest :solr:core:test --tests org.apache.solr.BasicFunctionalityTest --tests org.apache.solr.schema.BooleanFieldTest --tests org.apache.solr.schema.TestBinaryField --tests org.apache.solr.schema.TestSortableTextField --tests org.apache.solr.TestTrie --tests org.apache.solr.schema.TestCollationField --tests org.apache.solr.schema.TestCollationFieldDocValues --tests org.apache.solr.schema.DocValuesTest --tests org.apache.solr.schema.DocValuesMultiTest --tests org.apache.solr.schema.TestUseDocValuesAsStored -Ptests.seed=$SEED 9>&- > $OUT/p3.log 2>&1
echo "P3 rc=$?"
mkdir -p $OUT/xml-p3 && find $POS/solr/core/build/test-results -name 'TEST-*.xml' -exec cp {} $OUT/xml-p3/ \; 2>/dev/null; ls $OUT/xml-p3/

echo "=== P4 analysis-extras TestICUCollationFieldDocValues start UTC: $(date -u +%FT%TZ)"
$G :solr:modules:analysis-extras:cleanTest :solr:modules:analysis-extras:test --tests org.apache.solr.schema.TestICUCollationFieldDocValues -Ptests.seed=$SEED 9>&- > $OUT/p4.log 2>&1
echo "P4 rc=$?"
mkdir -p $OUT/xml-p4 && find $POS/solr/modules/analysis-extras/build/test-results -name 'TEST-org.apache.solr.schema.TestICUCollationFieldDocValues.xml' -exec cp {} $OUT/xml-p4/ \; 2>/dev/null; ls $OUT/xml-p4/

echo "=== P5 root check -x test start UTC: $(date -u +%FT%TZ)"
pkill -f "Gradle[D]aemon" 2>/dev/null; sleep 2
rm -f ~/.gradle/caches/journal-1/journal-1.lock
JAVA_TOOL_OPTIONS=-Djavax.net.ssl.trustStore=$HOME/workspace/tools/truststore-with-hatch-ca.jks $G check -x test 9>&- > $OUT/p5-check.log 2>&1
echo "P5 rc=$?"
tail -5 $OUT/p5-check.log
git checkout -- gradle/libs.versions.toml 2>/dev/null; true
echo "final HEAD: $(git rev-parse HEAD) tree: $(git rev-parse HEAD^{tree})"
echo "final status (excl gradle.properties): $(git status --porcelain | grep -v gradle.properties | wc -l)"
git diff --check > $OUT/final-diffcheck.log 2>&1; echo "final diff-check rc=$?"
echo "positive end UTC: $(date -u +%FT%TZ)"
