#!/bin/bash
# PR 5305 ignored-fields gate round 1: detached tidy preflight at F. Host lock held.
set -u
OUT=~/workspace/tools/gate-5305
F=219fee78bf7cae5039e50fe885108a1d4937ccd3
POS=~/workspace/solr-clones/5305-pos
G=~/workspace/tools/solr-gradle.sh
mkdir -p $OUT
exec 9>~/workspace/tools/.solr-test-queue.lock
flock 9
exec > >(tee -a $OUT/preflight.log) 2>&1
echo "preflight start UTC: $(date -u +%FT%TZ)"
pkill -f "Gradle[D]aemon" 2>/dev/null; sleep 2
rm -f ~/.gradle/caches/journal-1/journal-1.lock
cd $POS || exit 1
echo "HEAD: $(git rev-parse HEAD) tree: $(git rev-parse HEAD^{tree})"
[ "$(git rev-parse HEAD)" = "$F" ] || { echo "HEAD != F"; exit 1; }
echo "=== root tidy start UTC: $(date -u +%FT%TZ)"
$G tidy 9>&- > $OUT/tidy.log 2>&1
echo "tidy rc=$?"
tail -3 $OUT/tidy.log
git status --porcelain | grep -v gradle.properties > $OUT/tidy-status.txt; true
echo "tracked changes after tidy (excl gradle.properties): $(wc -l < $OUT/tidy-status.txt)"
cat $OUT/tidy-status.txt
git diff --check > $OUT/diffcheck.log 2>&1
echo "diff-check rc=$?"
# Restore the vendored toml if tidy pruned it (known side effect, AGENTS.md)
git checkout -- gradle/libs.versions.toml 2>/dev/null; true
echo "final status (excl gradle.properties): $(git status --porcelain | grep -v gradle.properties | wc -l)"
echo "preflight end UTC: $(date -u +%FT%TZ)"
