#!/usr/bin/env python3
"""Run the approved unchanged-head documentation gate and save each result."""
import datetime
import fcntl
import hashlib
from html.parser import HTMLParser
import json
import os
from pathlib import Path
import socket
import subprocess
import sys
from urllib.parse import unquote, urlsplit

w = Path('/workspace/solr-consistency-item4-antora')
logs = Path('/workspace/phone-agent-2-logs/consistency-item4')
resume = '--resume-rendered-check' in sys.argv
logs.mkdir(parents=True, exist_ok=resume)
locks = []
for name in dict.fromkeys([socket.gethostname().split('.')[0], 'phone-agent-2']):
    lock = open('/workspace/tools/.gradle-' + name + '.lock', 'w')
    fcntl.flock(lock, fcntl.LOCK_EX | fcntl.LOCK_NB)
    locks.append(lock)
env = dict(os.environ, JAVA_HOME='/usr/lib/jvm/java-21-openjdk-amd64', GRADLE_USER_HOME='/home/ubuntu/.gradle', npm_config_include='dev')
env['PATH'] = env['JAVA_HOME'] + '/bin:' + env['PATH']
env.pop('NODE_ENV', None)
env.pop('NPM_CONFIG_PRODUCTION', None)
env.pop('npm_config_production', None)
head = subprocess.check_output(['git', 'rev-parse', 'HEAD'], cwd=w, text=True).strip()
assert head == '4b185504ef7dd5e4530664995719a0e743564382'
state = dict(item='consistency-docs-round-1-item4', head=head, steps={})
if resume:
    state = json.loads((logs/'state.json').read_text())
    assert state['head'] == head and state['steps']['1-antora']['rc'] == 0
def record(step, **values):
    state['steps'][step] = dict(timestamp=datetime.datetime.now(datetime.timezone.utc).isoformat(), **values)
    (logs/'state.json').write_text(json.dumps(state, indent=2)+'\n')
    print(step, values, flush=True)
def clean():
    assert not subprocess.check_output(['git', 'status', '--porcelain'], cwd=w, text=True).strip(), 'Tracked source changed'
def run(step, tasks):
    root = os.statvfs('/')
    assert root.f_bavail*root.f_frsize >= 2147483648 and root.f_favail/root.f_files >= .1, 'Disk/inode guard'
    args = ['./gradlew', '--no-daemon', '--max-workers=2', *tasks]
    print('Starting '+step, flush=True)
    with (logs/(step+'.log')).open('w') as out:
        rc = subprocess.run(args, cwd=w, env=env, stdout=out, stderr=subprocess.STDOUT).returncode
    record(step, rc=rc, command=args)
    clean()
    return rc
clean()
record('0-scope', rc=0, scope='Two existing documentation edits only; no product changes', environment='Standalone Git checkout; NODE_ENV unset; npm dev dependencies included')
if resume:
    record('1-antora-reused', rc=0, reason='Successful build retained; only harness straight-apostrophe assertion corrected for Asciidoctor smart typography')
    rc = 0
else:
    rc = run('1-antora', [':solr:solr-ref-guide:buildLocalAntoraSite'])
if rc:
    record('gate', result='BLOCKED', failed_step='1-antora')
    sys.exit(rc)
class Page(HTMLParser):
    def __init__(self, path):
        super().__init__()
        self.text, self.links, self.ids = [], [], set()
        self.feed(path.read_text())
    def handle_starttag(self, tag, attrs):
        attrs = dict(attrs)
        if 'id' in attrs:
            self.ids.add(attrs['id'])
        if tag == 'a' and 'href' in attrs:
            self.links.append(attrs['href'])
    def handle_data(self, data):
        self.text.append(data)
site = w/'solr/solr-ref-guide/build/site'
checks = []
for relative, target in [('configuration-guide/configuring-solr-xml.html', 'stream-source-reference.html'), ('query-guide/stream-source-reference.html', 'configuring-solr-xml.html#allow-urls')]:
    matches = list(site.glob('solr/*/'+relative))
    assert len(matches) == 1, matches
    path = matches[0]
    page = Page(path)
    text = ' '.join(' '.join(page.text).split())
    text = text.replace('\u2019', "'")
    assert text.count('The allow-list does not cover stream sources.' if relative.startswith('configuration') else 'The URL allow-list does not cover stream sources.') == 1
    assert 'operator\'s network controls' in text
    links = [link for link in page.links if link.endswith(target)]
    assert links, (relative, target)
    for link in links:
        url = urlsplit(link)
        dest = path.parent/unquote(url.path)
        assert dest.exists(), str(dest)
        if url.fragment:
            assert unquote(url.fragment) in Page(dest).ids, link
    (logs/path.name).write_bytes(path.read_bytes())
    checks.append(dict(page=str(path), sha256=hashlib.sha256(path.read_bytes()).hexdigest(), links=links))
record('2-rendered-notes', rc=0, pages=checks)
rc = run('3-checkSiteLinks', [':solr:solr-ref-guide:checkSiteLinks'])
record('gate', rc=rc, result='GREEN' if rc == 0 else 'ANTORA_GREEN_LINK_CHECK_FAILED', tree='clean', tests_run=0)
sys.exit(rc)
