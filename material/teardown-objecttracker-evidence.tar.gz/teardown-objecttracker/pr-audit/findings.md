# Solr teardown/ObjectTracker PR audit

**Scope and method.** Read-only audit of public `apache/solr` PR API metadata and patch diffs for PRs 5192, 5029, 5002, 5101, 5202, and requested PR 5206. Queried unauthenticated `api.github.com/repos/apache/solr/pulls/{number}` metadata, diff media type, and changed-file lists; no credentials or secrets were read. Local source checkout `/workspace/solr-teardown-main` is clean at baseline `498a09aea97aac86c2cc7ac114113b946d249942`. PR state/head/base below are the API values observed during this audit; all six were **open, unmerged, non-draft** (base ref `main`). The base SHAs vary and none should be confused with the local baseline SHA.

## PR identity (exact API values)

| PR | Title | State | Head SHA | Base SHA |
|---|---|---|---|---|
| [5192](https://github.com/apache/solr/pull/5192) | SOLR-18564: CoreContainer.shutdown: run the remaining closes when the client close pool times out | open, unmerged | `dd65b21b41dc1d008c51031b71f61964ee2ca169` | `78923482727b8530d26ad08db734712ab2dacb12` |
| [5029](https://github.com/apache/solr/pull/5029) | SOLR-18506: Fix TestThinCache.testSimple flakiness from evictions in the warming phase | open, unmerged | `77c019e1ff0e922e3c2350379dece841651b1d44` | `22a8cfebbbdb026437d10b0aa47bb66ffdb23a9a` |
| [5002](https://github.com/apache/solr/pull/5002) | SOLR-11431: Report 503 instead of 500 for a core that fails to initialize | open, unmerged | `968fad873c4b35fff0605ae88dbecca16d1dfa2f` | `cabedd1d968059215188f4e7563fb303241899ed` |
| [5101](https://github.com/apache/solr/pull/5101) | SOLR-18531: Reserve a stopped test runner's port until its next start | open, unmerged | `c8a67c7267d00e33ad8323c683c040b539989b0d` | `3f5d4c5bf8ac96fec3a3219398b0c52c5418d48c` |
| [5202](https://github.com/apache/solr/pull/5202) | SOLR-18446: Keep collection routing path-scoped in HttpSolrCall | open, unmerged | `7e0251ee029125152c4d1791660189ef1e9dea06` | `79b23df58daac14b92cc35f23b8b81f72098b4ba` |
| [5206](https://github.com/apache/solr/pull/5206) | SOLR-18576: Wait for the expired ZooKeeper session before indexing in BasicDistributedZk2Test | open, unmerged | `4c8f12f526f54e4e90a8ea49d46c1d28d899cb65` | `79b23df58daac14b92cc35f23b8b81f72098b4ba` |

## Teardown-path intersection

`Yes` means a change to the named class/path in the patch; `Test-only` means it is referenced or simulated by a new/changed test, not changed as production implementation. A `No` is based on the PR's complete changed-file list and patch, not merely the PR title.

| Named target | 5192 | 5029 | 5002 | 5101 | 5202 | 5206 |
|---|---|---|---|---|---|---|
| `CoreContainer.shutdown` | **Yes** | No | No  -  `CoreContainer.java` change is `getCore`, not shutdown | No | No | No |
| `HttpShardHandlerFactory` | **Test-only** | No | No | No | No | No |
| `HttpJettySolrClient` | No | No | No | No  -  used only to issue test requests | No | No |
| `CoreContainerProvider` | No | No | No | No | No | No |
| `JettySolrRunner` | No | No | No | **Yes** | No | No |
| `BaseDistributedSearchTestCase` | No | No | No | No | No | No |

### Relevant diff locations

- **PR 5192  -  direct shutdown-path change.** `solr/core/src/java/org/apache/solr/core/CoreContainer.java`, diff hunk `@@ -1312,7 +1312,17 @@` (patch lines 14-35): wraps `ExecutorUtil.shutdownAndAwaitTermination(customThreadPool)` in `catch (RuntimeException)` and logs/continues so trailing shutdown closes are not skipped when pool termination times out. The newly added `solr/core/src/test/org/apache/solr/core/CoreContainerShutdownTest.java` hunk `@@ -0,0 +1,163 @@` (patch lines 37-205) verifies root `SolrMetricsContext` release and handler closure after a deliberately blocked close. It imports/subclasses `HttpShardHandlerFactory` only in that test: `BlockingShardHandlerFactory` waits in `close()` then delegates (added test lines 169-195; installation at 119-120). The patch does **not** modify `HttpShardHandlerFactory` production code, `HttpJettySolrClient`, `CoreContainerProvider`, `JettySolrRunner`, or `BaseDistributedSearchTestCase`.
- **PR 5029  -  adjacent test only.** `solr/core/src/test/org/apache/solr/search/TestThinCache.java`, hunks `@@ -150,6 +150,13 @@` and `@@ -167,6 +174,8 @@` (patch lines 1-28): raises backing cache max size to 200 to prevent evictions during warming and retains a zero-evictions assertion. It does not change teardown or metrics-context closing.
- **PR 5002  -  same file, different method.** `solr/core/src/java/org/apache/solr/core/CoreContainer.java`, hunk `@@ -2215,7 +2215,7 @@` (patch lines 14-26): changes the failed-core comment from 500 to 503; `SolrCoreInitializationException` and `TestCoreContainer` assert that service-unavailable code. No shutdown hunk/change.
- **PR 5101  -  runner port lifecycle, not client/context teardown.** `solr/test-framework/src/java/org/apache/solr/embedded/JettySolrRunner.java`: `start` hunk `@@ -497,6 +512,10 @@` releases a port reservation (patch lines 88-98); `stop` hunk `@@ -660,6 +679,10 @@` reserves the port (lines 99-109); `close` hunk `@@ -887,5 +971,10 @@` releases it (lines 178-188). The new `MiniSolrCloudCluster.shutdown()` logic releases reservations (lines 16-45). This is production `JettySolrRunner` code, but concerns a held `ServerSocket`/port during restart, not `HttpJettySolrClient.close()` or metrics contexts. `TestJettySolrRunner` references `HttpJettySolrClient` in request-making test code (patch lines 189-329), without changing its close implementation.
- **PR 5202  -  routing changes.** Production changes are only `V2HttpCall.java` (hunk `@@ -132,9 +132,8 @@`, patch lines 14-29) and `HttpSolrCall.java` (hunk `@@ -277,11 +278,23 @@`, lines 30-69): constrain collection routing to URL-path destinations. Remaining files are routing tests/docs/changelog. No named teardown class or method appears in its changed-file list.
- **PR 5206  -  test synchronization only.** Sole changed file `solr/core/src/test/org/apache/solr/cloud/BasicDistributedZk2Test.java`, hunk `@@ -151,15 +154,26 @@` (patch lines 1-57): adds a ZooKeeper connection-state listener, waits for the expired-session callback, then waits for reconnection before indexing and removes the listener. No named teardown class/path is changed.

## Relevance, causation, and relation among these six PRs

- **5192 is the only direct proposed fix for skipped `CoreContainer.shutdown()` trailing closes and resulting `SolrMetricsContext` leakage.** Its change and regression test make the reported close-pool-timeout mechanism materially relevant. However, a PR diff - even one whose title and regression test match the suspected mechanism - is not proof that this caused any particular CI failure. The added test exercises a synthetic blocked shard-handler close and checks the container root metrics context/handler; it does not establish the exact runtime path or prove release of every leaked context in the reported jobs (nor directly test a real `HttpJettySolrClient.close()` failure).
- **5029 is independently relevant to the named `TestThinCache` flake**, but it fixes an eviction-count race by avoiding evictions; it neither changes the test's metrics-context release path nor establishes that its ObjectTracker report was caused by that race.
- **5002 shares the `CoreContainer.java` file with 5192 only; its hunk is in core lookup/error status, not shutdown.** No source-level overlap/dependency with 5192's shutdown hunk is shown.
- **5101 is lifecycle-adjacent only:** its runner port reservation/release can affect runner restart/port behavior, but the changes are not a fix for metrics/client close leaks. It has no hunk overlap with 5192.
- **5202 was associated with a reported test run in the assignment context, but its patch is collection-routing semantics; it does not edit the named teardown paths or the named CustomSort test.** Relevance as the PR under test is not evidence of teardown causation.
- **5206 is unrelated to the ObjectTracker leak mechanism:** it removes a race in a ZooKeeper session-expiration test by ordering the test after expiry and reconnect. It does not alter teardown checks, close behavior, or suppress a leak assertion; it is not evidence of, nor a fix for, a shared teardown defect.
- Within these six diffs, the only notable shared-file overlap is 5192/5002 on `CoreContainer.java`, in distinct methods/hunks. 5192's added regression test exercises a shard handler close, but no other PR changes that implementation. No direct dependency or coupled fix among the six is indicated by their file lists/diffs. PR 5202 and 5206 happen to have the same API base SHA; this alone does not imply dependency.

**Evidence caveat:** This audit did not access the three CI logs mentioned in the coordination assignment (one is on a different host). Conclusions above separate what the public PR patches change from causal proof about the reported runs.
