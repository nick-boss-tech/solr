#!/usr/bin/env python3
"""Run each assigned class at most once, preserving all evidence."""
import datetime
import fcntl
import json
import os
from pathlib import Path
import shutil
import socket
import subprocess
import xml.etree.ElementTree as ET
from inode_guard import check_inode_capacity

W = Path('/workspace/solr-teardown-main')
L = Path('/workspace/gates/logs/phone-agent-2/teardown-objecttracker')
RUNNER = Path('/workspace/pool-teardown-coordination/pool/bin/sweep-run.sh')
L.mkdir(parents=True, exist_ok=True)
lock = open('/workspace/tools/.gradle-' + socket.gethostname().split('.')[0] + '.lock', 'a')
fcntl.flock(lock, fcntl.LOCK_EX | fcntl.LOCK_NB)
head = subprocess.check_output(['git', 'rev-parse', 'HEAD'], cwd=W, text=True).strip()
assert head.startswith('498a09aea9'), head
assert not subprocess.check_output(['git', 'status', '--porcelain'], cwd=W, text=True).strip()
state = {'head': head, 'runs': [], 'policy': 'No source edits; no retries; stop on nonzero exit; class filters only.'}
classes = [
    ('custom-sort', 'core', 'org.apache.solr.handler.component.DistributedQueryComponentCustomSortTest', 'FFF5A3C3AAC69084'),
    ('cloud-http2', 'solrj', 'org.apache.solr.client.solrj.impl.CloudHttp2SolrClientTest', 'A35B8669BA78E261'),
    ('thin-cache', 'core', 'org.apache.solr.search.TestThinCache', '1668E8BD438E6830'),
]
for name, module, clazz, seed in classes:
    check_inode_capacity(W, '/home/ubuntu/.gradle')
    v = os.statvfs('/')
    assert v.f_bavail * v.f_frsize >= 2 * 1024**3, 'Disk byte safety guard'
    assert not (L / (name + '.log')).exists(), 'Refusing to overwrite evidence'
    cmd = ['bash', str(RUNNER), str(W), str(L), name, '--no-daemon', '--max-workers=2',
           f':solr:{module}:cleanTest', f':solr:{module}:test', '--tests', clazz,
           '-Ptests.jvms=1', '-Ptests.jvmargs=-XX:TieredStopAtLevel=1 -XX:+UseParallelGC -XX:ActiveProcessorCount=1 -XX:ReservedCodeCacheSize=120m',
           '-Ptests.timeoutSuite=600000!', '-Ptests.useSecurityManager=true',
           '-Ptests.file.encoding=ISO-8859-1', f'-Ptests.seed={seed}']
    started = datetime.datetime.now(datetime.timezone.utc).isoformat()
    print(f'Starting {name} at {started}; class={clazz}, seed={seed}', flush=True)
    result = dict(name=name, module=module, clazz=clazz, seed=seed, started=started, command=cmd, status='RUNNING')
    state['runs'].append(result)
    (L / 'reproduction-state.json').write_text(json.dumps(state, indent=2) + '\n')
    rc = subprocess.run(cmd, cwd=W, env={**os.environ, 'SWEEP_WAIT': '1'}).returncode
    source = W / f'solr/{module}/build/test-results'
    if source.exists():
        shutil.copytree(source, L / (name + '-test-results'))
    counts = dict(tests=0, skipped=0, failures=0, errors=0)
    suites = []
    for p in (L / (name + '.xml')).glob('TEST-*.xml'):
        root = ET.parse(p).getroot()
        suites.append(root.attrib)
        for k in counts:
            counts[k] += int(root.attrib.get(k, '0'))
    result.update(ended=datetime.datetime.now(datetime.timezone.utc).isoformat(), rc=rc, counts=counts, suites=suites, status='PASSED' if rc == 0 else 'STOPPED')
    (L / 'reproduction-state.json').write_text(json.dumps(state, indent=2) + '\n')
    print(json.dumps(result), flush=True)
    if rc != 0:
        print('Stopping without retry, per assignment. Later classes not launched.', flush=True)
        break
assert not subprocess.check_output(['git', 'status', '--porcelain'], cwd=W, text=True).strip()
print('Assignment reproductions finished; source clean.', flush=True)
