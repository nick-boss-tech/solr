# Live public PR facts for SOLR-18530 gate

Source: GitHub pull-request API, https://api.github.com/repos/apache/solr/pulls/5098, read 2026-11-06T17:04:21Z.

PR #5098 is open and not a draft. The base is `main` at `3f5d4c5bf8ac96fec3a3219398b0c52c5418d48c`; the head repository is `nick-boss-tech/solr`, branch `solr-18530-submit`, at `d822b88b1bd58c197e4ad09c53ffff0920b76190` (F). Public PR page: https://github.com/apache/solr/pull/5098.

The implementation report cites reviewer discussion https://github.com/apache/solr/pull/5098#discussion_r4489773547. No new PR comment or reply was posted as part of this gate.
