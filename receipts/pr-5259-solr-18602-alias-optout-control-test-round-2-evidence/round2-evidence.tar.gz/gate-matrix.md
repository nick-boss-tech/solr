# SOLR-18602 round-2 gate evidence matrix

Implementation F2: `2efbd9884eac22cc8ddd0bdad2f8715f800eebee` on `nick-boss-tech/solr:solr-18602-pr5259-alias-optout-test`. Baseline H: `ec8e706a41a0213dd924b286b1f5ebfc476f7cd0`, the unchanged public PR head. Fixed seed: `18602C0DE`. The public PR remains open on the separate `sarkaramrit1993/solr:deletereplica-count-alias-18602` ref at H; no PR, comment, merge, or Jira action was made.

| Leg | UTC interval | Result | Fresh test XML | Resource minimum |
|---|---|---|---|---|
| Detached exact-F2 `tidy` preflight | 06:05:25–06:06:58 | Exit 0; tidy clean; 62 actionable tasks | Not a test leg | 41.6620% free inodes; 45,666,197,504 disk bytes free |
| F2 standalone `./gradlew check -x test` | 06:11:45–06:16:28 | PASS; 556/556 actionable tasks; tests excluded by command | None expected | 37.0772% free inodes; 44,031,819,776 disk bytes free |
| Parent H focused `DeleteReplicaTest` | 06:17:16–06:19:29 | PASS; 8 tests, 0 failures/errors/skips; new control absent | 1 fresh XML | 36.4953% free inodes; 43,929,128,960 disk bytes free |
| Implementation F2 focused `DeleteReplicaTest` | 06:19:48–06:22:03 | PASS; 9 tests, 0 failures/errors/skips; new control present | 1 fresh XML | 35.9254% free inodes; 43,832,377,344 disk bytes free |
| F2 synthetic fail-before control test | 06:23:45–06:25:42 | Expected Gradle exit 1; exactly 1 test, 1 expected assertion failure, 0 errors/skips | 1 fresh XML | 35.3658% free inodes; 43,741,593,600 disk bytes free |

All Gradle legs were serial, used `/workspace/tools/.gradle-phone-agent-2.lock` through `pool/bin/sweep-run.sh`, and were wrapped by the live `inode-watch-run.py` monitor (3-second samples). The configured stop floors were <=15% free inodes or <2 GiB disk. Total recorded samples: 263; no stop marker. Overall minima during the gate: 35.3658% free inodes (660,667/1,868,096) and 43,741,593,600 disk bytes free. No test legs ran simultaneously.

The F1-to-F2 repair is the Nick-authored tidy-only commit `2efbd9884eac22cc8ddd0bdad2f8715f800eebee`, parent `b92dd3d7bdae76fd9fb2ac00adc26fcbcb3ba0a7`; it changes only the formatting of one `expectThrows` call. Candidate-vs-H source review found only the added test in `DeleteReplicaTest.java`; `git diff --check` passed and the implementation worktree was clean at F2. The test establishes opt-out control coverage only and does not identify a production false-branch defect.