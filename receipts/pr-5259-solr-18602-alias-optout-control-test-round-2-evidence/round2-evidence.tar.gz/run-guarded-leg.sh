#!/usr/bin/env bash
set -euo pipefail
name=${1:?run name required}
worktree=${2:?checkout path required}
logdir=${3:?log directory required}
shift 3
repo=/workspace/solr
watcher=/workspace/tools/inode-watch-run.py
runner="$repo/pool/bin/sweep-run.sh"
mkdir -p "$logdir"
head=$(git -C "$worktree" rev-parse HEAD 2>/dev/null || echo UNKNOWN)
start=$(date -u +%FT%TZ)
{
  printf 'start_utc=%s\n' "$start"
  printf 'worktree=%s\n' "$worktree"
  printf 'head=%s\n' "$head"
  printf 'git_status_before=%s\n' "$(git -C "$worktree" status --porcelain | tr '\n' ';')"
  printf 'runner=%s\nwatcher=%s\nlock=/workspace/tools/.gradle-phone-agent-2.lock\n' "$runner" "$watcher"
  printf 'env=NODE_ENV unset; SWEEP_WAIT=0\ncommand=./gradlew'
  printf ' %q' "$@"
  printf '\n'
} > "$logdir/$name.command.txt"
python3 "$watcher" "$logdir/$name.resource-watch.tsv" /usr/bin/env -u NODE_ENV SWEEP_WAIT=0 "$runner" "$worktree" "$logdir" "$name" "$@" > "$logdir/$name.resource-runner.log" 2>&1 &
child=$!
while :; do
  finished=0
  for _ in $(seq 1 30); do
    sleep 1
    state=$(ps -p "$child" -o stat= 2>/dev/null || true)
    if [[ -z "$state" || "$state" == Z* ]]; then finished=1; break; fi
  done
  if [[ "$finished" -eq 1 ]]; then break; fi
  printf 'progress_utc=%s run=%s | ' "$(date -u +%FT%TZ)" "$name"
  tail -n1 "$logdir/$name.resource-watch.tsv" 2>/dev/null || echo 'resource sample pending'
done
set +e
wait "$child"
rc=$?
set -e
end=$(date -u +%FT%TZ)
{
  printf 'exit_code=%s\nend_utc=%s\n' "$rc" "$end"
  printf 'head_after=%s\n' "$(git -C "$worktree" rev-parse HEAD 2>/dev/null || echo UNKNOWN)"
  printf 'git_status_after=%s\n' "$(git -C "$worktree" status --porcelain 2>/dev/null | tr '\n' ';')"
} > "$logdir/$name.status.txt"
printf '%s exit=%s start=%s end=%s\n' "$name" "$rc" "$start" "$end"
exit "$rc"
