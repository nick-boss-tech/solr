#!/usr/bin/env python3
"""Local (distrib=false) Luke pass: per-core enumeration and fq pair."""
import json
import os
import sys

sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
import probe


def main():
    shardmap = probe.cores()
    for shard, info in shardmap.items():
        for tag, extra in (("", ""), ("-fq", f"&fq={probe.FIXTURE['filter']}")):
            s, j = probe.call(f"luke-local-{shard}{tag}", "GET",
                              info["base"] + f"/{info['core']}/admin/luke?numTerms=0&distrib=false&wt=json{extra}")
            idx = (j or {}).get("index", {})
            fields = (j or {}).get("fields", {})
            print(shard, tag or "plain", "http", s, "index", idx,
                  "ghost docs", fields.get("ghost_s", {}).get("docs"),
                  "dynonly docs", fields.get("dynonly_s", {}).get("docs"),
                  "storedonly docs", fields.get("storedonly_s", {}).get("docs"),
                  "nfields", len(fields))


if __name__ == "__main__":
    main()
