#!/usr/bin/env python3
"""Create and load the measurement collections for the discovery probes.

discmeas1: 1 shard, discmeas2: 2 shards, both RF=1 on the built-in _default
configset. 120 docs each: ids m000..m119; m000..m099 carry cat_s=meas,
m100..m119 carry cat_s=other; every doc carries m0_s..m49_s and title_s.
Grid filters: cat_s:meas matches 100 docs, cat_s:other matches 20 docs.
"""
import json
import os
import sys

sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
import probe


def main():
    for coll, shards in (("discmeas1", 1), ("discmeas2", 2)):
        probe.call(f"create-{coll}", "GET",
                   probe.N1 + f"/solr/admin/collections?action=CREATE&name={coll}"
                              f"&numShards={shards}&replicationFactor=1"
                              f"&collection.configName=_default&wt=json")
    docs = []
    for i in range(120):
        d = {"id": f"m{i:03d}", "cat_s": "meas" if i < 100 else "other",
             "title_s": f"meas doc {i}"}
        for k in range(50):
            d[f"m{k}_s"] = f"v{k}"
        docs.append(d)
    for coll in ("discmeas1", "discmeas2"):
        probe.call(f"index-{coll}", "POST",
                   probe.N1 + f"/solr/{coll}/update?commit=true",
                   json.dumps(docs))
        s, j = probe.call(f"count-{coll}", "GET",
                          probe.N1 + f"/solr/{coll}/select?q=*:*&rows=0&wt=json")
        print(coll, "numFound", (j or {}).get("response", {}).get("numFound"))


if __name__ == "__main__":
    main()
