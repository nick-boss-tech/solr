#!/usr/bin/env python3
"""Bounded measurement grid for the discovery probes.

Cells: collection (discmeas1 = 1 shard, discmeas2 = 2 shards) x matching
docs (filter cat_s:meas = 100, cat_s:other = 20) x explicit facet fields
(1, 10, 50). Each cell: 2 warmup requests then 3 measured requests; client
wall-clock latency per request is saved raw. Process CPU and memory are
sampled by the shell wrapper around this script (method recorded there).
Descriptive only; not a safety bound.
"""
import json
import os
import sys
import time

sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
import probe


def main():
    cells = []
    for coll, shards in (("discmeas1", 1), ("discmeas2", 2)):
        for filt, matching in (("cat_s:meas", 100), ("cat_s:other", 20)):
            for nfields in (1, 10, 50):
                fields = [f"m{i}_s" for i in range(nfields)]
                facets = {f"f_{f}": {"type": "query", "q": f"{f}:*"}
                          for f in fields}
                body = {"query": "*:*", "filter": filt, "limit": 0,
                        "facet": facets}
                times = []
                counts = []
                for rep in range(5):
                    t0 = time.time()
                    s, j = probe.call(
                        f"measure-{coll}-{matching}-{nfields}-{rep}", "POST",
                        probe.N1 + f"/solr/{coll}/query", json.dumps(body))
                    dt = time.time() - t0
                    if rep >= 2:
                        times.append(round(dt, 4))
                        counts.append((j or {}).get("facets", {})
                                      .get("count"))
                cells.append({"collection": coll, "shards": shards,
                              "filter": filt, "matching_docs": matching,
                              "fields": nfields,
                              "domain_counts": counts,
                              "latency_s": times})
    probe.save("measurements.json", json.dumps(cells, indent=1))
    print(json.dumps(cells, indent=1))


if __name__ == "__main__":
    main()
