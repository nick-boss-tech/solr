#!/usr/bin/env python3
"""Partial-result attempt for the discovery probes.

Attempts a deterministic partial result on the distributed fixture query by
setting timeAllowed=1 (milliseconds) on the JSON facet request, with and
without shards.tolerant=true, five attempts each. Records the raw responses
and whether a partialResults flag appears. If no attempt yields the flag,
the caller classifies this sub-leg incomplete with this method recorded.
"""
import json
import os
import sys

sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
import probe


def main():
    body = probe.facet_request(probe.N1, probe.FIXTURE["filter"])
    seen = []
    for tolerant in ("false", "true"):
        for i in range(5):
            s, j = probe.call(
                f"partial-timeallowed-{tolerant}-{i}", "POST",
                probe.N1 + f"/solr/{probe.COLL}/query?timeAllowed=1"
                           f"&shards.tolerant={tolerant}",
                json.dumps(body))
            hdr = (j or {}).get("responseHeader", {})
            seen.append({"tolerant": tolerant, "attempt": i, "status": s,
                         "partialResults": hdr.get("partialResults")})
    probe.save("partial-attempts.json", json.dumps(seen, indent=1))
    print(json.dumps(seen, indent=1))


if __name__ == "__main__":
    main()
