#!/bin/bash
set -u
T=~/workspace/tools/disc-cov
RUNS=$T/runs; mkdir -p $RUNS
LOG=$RUNS/phase1.log; : > $LOG
{
  echo "date: $(date -Is)"
  echo "uname: $(uname -a)"
  echo "nproc: $(nproc)"
  free -m | head -2
  df -h /home/hatch | tail -1
} >> $LOG
# Build installDist under the test-queue flock
(
  exec 9>~/workspace/tools/.solr-test-queue.lock
  flock 9
  cd ~/workspace/solr-clones/disc-cov || exit 2
  echo "disc-cov HEAD=$(git rev-parse HEAD) tracked=$(git status --porcelain | wc -l)" >> $LOG
  UIC=473a55ef64a9a1605e00eb6c1c386887d4cb7dac
  mkdir -p solr/webapp/build/ui-download
  curl -sL "https://nightlies.apache.org/solr/ui/wasm/$UIC/solr-ui-wasm.zip" -o "solr/webapp/build/ui-download/solr-ui-wasm-$UIC.zip"
  echo "wasm seed sha256: $(sha256sum solr/webapp/build/ui-download/solr-ui-wasm-$UIC.zip | cut -d' ' -f1)" >> $LOG
  pkill -f 'Gradle[D]aemon' 2>/dev/null; sleep 2
  rm -f ~/.gradle/caches/journal-1/journal-1.lock
  ~/workspace/tools/solr-gradle.sh --no-daemon :solr:packaging:installDist >> $RUNS/build.log 2>&1 9>&-
  echo "installDist rc=$?" >> $LOG
)
INST=$(ls -d ~/workspace/solr-clones/disc-cov/solr/packaging/build/solr-11.0.0-SNAPSHOT 2>/dev/null)
echo "INST=$INST" >> $LOG
[ -n "$INST" ] || exit 3
$INST/bin/java -version >> $LOG 2>&1 || ~/workspace/tools/jdk21/jdk-21.0.12.1+1/bin/java -version >> $LOG 2>&1
export JAVA_HOME=~/workspace/tools/jdk21/jdk-21.0.12.1+1
export PATH=$JAVA_HOME/bin:$PATH
export JDK_JAVA_OPTIONS=-Djava.net.preferIPv4Stack=true
export SOLR_ULIMIT_CHECKS=false
# Node homes
for n in 1 2; do
  H=$T/node$n-home
  rm -rf $H; mkdir -p $H
  cp -r $INST/server/solr/. $H/
  mkdir -p $H/zoo_data $T/node$n-logs $T/node$n-pids
  sed -i "s|^dataDir=.*|dataDir=$H/zoo_data|" $H/zoo.cfg 2>/dev/null
  grep -H "dataDir" $H/zoo.cfg >> $LOG 2>/dev/null
done
SOLR_LOGS_DIR=$T/node1-logs SOLR_PID_DIR=$T/node1-pids $INST/bin/solr start --force -p 18983 -s $T/node1-home -h 127.0.0.1 >> $LOG 2>&1
echo "node1 start rc=$?" >> $LOG
for i in $(seq 1 40); do curl -sf http://127.0.0.1:18983/solr/admin/info/system?wt=json -o /dev/null && break; sleep 5; done
curl -s http://127.0.0.1:18983/solr/admin/info/system?wt=json > $RUNS/node1-system.json
echo "node1 live check rc=$?" >> $LOG
SOLR_LOGS_DIR=$T/node2-logs SOLR_PID_DIR=$T/node2-pids $INST/bin/solr start --force -p 18984 -s $T/node2-home -h 127.0.0.1 -z 127.0.0.1:19983 >> $LOG 2>&1
echo "node2 start rc=$?" >> $LOG
for i in $(seq 1 40); do curl -sf http://127.0.0.1:18984/solr/admin/info/system?wt=json -o /dev/null && break; sleep 5; done
curl -s http://127.0.0.1:18984/solr/admin/info/system?wt=json > $RUNS/node2-system.json
echo "node2 live check rc=$?" >> $LOG
ps aux | grep -i "[o]rg.apache.solr" | awk '{print $2, $12, $13, $14}' >> $LOG
cd $T
python3 probe.py setup >> $RUNS/probe-setup.log 2>&1; echo "probe setup rc=$?" >> $LOG
python3 probe.py facets >> $RUNS/probe-facets.log 2>&1; echo "probe facets rc=$?" >> $LOG
python3 probe.py luke >> $RUNS/probe-luke.log 2>&1; echo "probe luke rc=$?" >> $LOG
curl -s "http://127.0.0.1:18983/solr/admin/collections?action=CLUSTERSTATUS&collection=disccov&wt=json" > $RUNS/clusterstatus.json
echo "PHASE1 DONE" >> $LOG
cat $LOG
