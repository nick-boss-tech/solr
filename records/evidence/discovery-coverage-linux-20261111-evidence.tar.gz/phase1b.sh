#!/bin/bash
set -u
T=~/workspace/tools/disc-cov
RUNS=$T/runs; mkdir -p $RUNS
LOG=$RUNS/phase1b.log; : > $LOG
INST=$(ls -d ~/workspace/solr-clones/disc-cov/solr/packaging/build/solr-11.0.0-SNAPSHOT)
export JAVA_HOME=~/workspace/tools/jdk21/jdk-21.0.12.1+1
export PATH=$JAVA_HOME/bin:$PATH
export JDK_JAVA_OPTIONS=-Djava.net.preferIPv4Stack=true
export SOLR_ULIMIT_CHECKS=false
for n in 1 2; do
  H=$T/node$n-home
  rm -rf $H; mkdir -p $H
  cp -r $INST/server/solr/. $H/
  mkdir -p $H/zoo_data $T/node$n-logs $T/node$n-pids
done
SOLR_LOGS_DIR=$T/node1-logs SOLR_PID_DIR=$T/node1-pids $INST/bin/solr start --force -p 18983 --solr-home $T/node1-home --host 127.0.0.1 >> $LOG 2>&1
echo "node1 start rc=$?" >> $LOG
for i in $(seq 1 40); do curl -sf http://127.0.0.1:18983/solr/admin/info/system?wt=json -o /dev/null && break; sleep 5; done
curl -s http://127.0.0.1:18983/solr/admin/info/system?wt=json > $RUNS/node1-system.json; echo "node1 live rc=$?" >> $LOG
SOLR_LOGS_DIR=$T/node2-logs SOLR_PID_DIR=$T/node2-pids $INST/bin/solr start --force -p 18984 --solr-home $T/node2-home --host 127.0.0.1 -z 127.0.0.1:19983 >> $LOG 2>&1
echo "node2 start rc=$?" >> $LOG
for i in $(seq 1 40); do curl -sf http://127.0.0.1:18984/solr/admin/info/system?wt=json -o /dev/null && break; sleep 5; done
curl -s http://127.0.0.1:18984/solr/admin/info/system?wt=json > $RUNS/node2-system.json; echo "node2 live rc=$?" >> $LOG
ps aux | grep "[s]olr" | grep -v grep | awk '{print $2}' | head -5 >> $LOG
cd $T
python3 probe.py setup >> $RUNS/probe-setup.log 2>&1; echo "probe setup rc=$?" >> $LOG
python3 probe.py facets >> $RUNS/probe-facets.log 2>&1; echo "probe facets rc=$?" >> $LOG
python3 probe.py luke >> $RUNS/probe-luke.log 2>&1; echo "probe luke rc=$?" >> $LOG
curl -s "http://127.0.0.1:18983/solr/admin/collections?action=CLUSTERSTATUS&collection=disccov&wt=json" > $RUNS/clusterstatus.json
echo "PHASE1B DONE" >> $LOG
cat $LOG
