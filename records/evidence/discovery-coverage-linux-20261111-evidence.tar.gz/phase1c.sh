#!/bin/bash
set -u
T=~/workspace/tools/disc-cov
RUNS=$T/runs
LOG=$RUNS/phase1c.log; : > $LOG
cd $T
python3 probe.py setup >> $RUNS/probe-setup.log 2>&1; echo "probe setup rc=$?" >> $LOG
python3 probe.py facets >> $RUNS/probe-facets.log 2>&1; echo "probe facets rc=$?" >> $LOG
python3 probe.py luke >> $RUNS/probe-luke.log 2>&1; echo "probe luke rc=$?" >> $LOG
curl -s "http://127.0.0.1:18983/solr/admin/collections?action=CLUSTERSTATUS&collection=disccov&wt=json" > $RUNS/clusterstatus.json
cat $RUNS/facet-comparison.json >> $LOG 2>/dev/null
echo "PHASE1C DONE" >> $LOG
cat $LOG
