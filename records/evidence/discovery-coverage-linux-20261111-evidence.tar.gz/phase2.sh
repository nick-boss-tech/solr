#!/bin/bash
set -u
T=~/workspace/tools/disc-cov
RUNS=$T/runs; mkdir -p $RUNS
LOG=$RUNS/phase2.log; : > $LOG
INST=$(ls -d ~/workspace/solr-clones/disc-cov/solr/packaging/build/solr-11.0.0-SNAPSHOT)
export JAVA_HOME=~/workspace/tools/jdk21/jdk-21.0.12.1+1
export PATH=$JAVA_HOME/bin:$PATH
export JDK_JAVA_OPTIONS=-Djava.net.preferIPv4Stack=true
export SOLR_ULIMIT_CHECKS=false
cd $T
snap() {
  for p in $(pgrep -f "org.apache.solr.core.SolrCore" ; pgrep -f "start.jar" ; pgrep -f "solr" | head -20); do :; done
  for pidfile in $T/node1-pids/*.pid $T/node2-pids/*.pid; do
    [ -f "$pidfile" ] || continue
    pid=$(cat "$pidfile")
    echo "pid $pid stat: $(awk '{print "utime="$14" stime="$15}' /proc/$pid/stat 2>/dev/null) $(grep VmHWM /proc/$pid/status 2>/dev/null)"
  done
}
python3 meas-setup.py >> $RUNS/meas-setup.log 2>&1; echo "meas-setup rc=$?" >> $LOG
echo "cpu/mem sample method: /proc/<node-pid>/stat utime+stime ticks and VmHWM from /proc/<pid>/status, sampled before and after the measurement grid; process-level over the whole grid window, not per-request attribution." >> $RUNS/measurements-env.txt
echo "BEFORE:" >> $RUNS/measurements-env.txt; snap >> $RUNS/measurements-env.txt
python3 meas.py >> $RUNS/meas.log 2>&1; echo "measure rc=$?" >> $LOG
echo "AFTER:" >> $RUNS/measurements-env.txt; snap >> $RUNS/measurements-env.txt
# failure leg: stop node2, probe, restart
SOLR_LOGS_DIR=$T/node2-logs SOLR_PID_DIR=$T/node2-pids $INST/bin/solr stop -p 18984 >> $LOG 2>&1
echo "node2 stop rc=$?" >> $LOG
for i in $(seq 1 20); do curl -sf http://127.0.0.1:18984/solr/admin/info/system?wt=json -o /dev/null || break; sleep 3; done
curl -s -m 5 http://127.0.0.1:18984/solr/admin/info/system?wt=json > /dev/null; echo "node2 down check rc=$? (7=refused expected)" >> $LOG
sleep 5
python3 probe.py failure >> $RUNS/probe-failure.log 2>&1; echo "probe failure rc=$?" >> $LOG
SOLR_LOGS_DIR=$T/node2-logs SOLR_PID_DIR=$T/node2-pids $INST/bin/solr start --force -p 18984 --solr-home $T/node2-home --host 127.0.0.1 -z 127.0.0.1:19983 >> $LOG 2>&1
echo "node2 restart rc=$?" >> $LOG
for i in $(seq 1 40); do curl -sf http://127.0.0.1:18984/solr/admin/info/system?wt=json -o /dev/null && break; sleep 5; done
curl -s "http://127.0.0.1:18983/solr/admin/collections?action=CLUSTERSTATUS&collection=disccov&wt=json" > $RUNS/clusterstatus-after-failure.json
python3 partial.py >> $RUNS/partial.log 2>&1; echo "partial rc=$?" >> $LOG
# teardown: stop both nodes and verify
SOLR_LOGS_DIR=$T/node2-logs SOLR_PID_DIR=$T/node2-pids $INST/bin/solr stop -p 18984 >> $LOG 2>&1; echo "node2 final stop rc=$?" >> $LOG
SOLR_LOGS_DIR=$T/node1-logs SOLR_PID_DIR=$T/node1-pids $INST/bin/solr stop -p 18983 >> $LOG 2>&1; echo "node1 final stop rc=$?" >> $LOG
sleep 5
ps aux | grep -i "[s]olr" | grep -v "disc-cov" > $RUNS/teardown-ps.txt
echo "remaining solr-ish processes:" >> $LOG
cat $RUNS/teardown-ps.txt >> $LOG
echo "PHASE2 DONE" >> $LOG
cat $LOG
