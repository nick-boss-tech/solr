#!/bin/bash
set -u
T=~/workspace/tools/disc-cov
RUNS=$T/runs
LOG=$RUNS/phase3.log; : > $LOG
INST=$(ls -d ~/workspace/solr-clones/disc-cov/solr/packaging/build/solr-11.0.0-SNAPSHOT)
export JAVA_HOME=~/workspace/tools/jdk21/jdk-21.0.12.1+1
export PATH=$JAVA_HOME/bin:$PATH
export JDK_JAVA_OPTIONS=-Djava.net.preferIPv4Stack=true
export SOLR_ULIMIT_CHECKS=false
SOLR_LOGS_DIR=$T/node1-logs SOLR_PID_DIR=$T/node1-pids $INST/bin/solr start --force -p 18983 --solr-home $T/node1-home --host 127.0.0.1 >> $LOG 2>&1
echo "node1 start rc=$?" >> $LOG
for i in $(seq 1 40); do curl -sf http://127.0.0.1:18983/solr/admin/info/system?wt=json -o /dev/null && break; sleep 5; done
SOLR_LOGS_DIR=$T/node2-logs SOLR_PID_DIR=$T/node2-pids $INST/bin/solr start --force -p 18984 --solr-home $T/node2-home --host 127.0.0.1 -z 127.0.0.1:19983 >> $LOG 2>&1
echo "node2 start rc=$?" >> $LOG
for i in $(seq 1 40); do curl -sf http://127.0.0.1:18984/solr/admin/info/system?wt=json -o /dev/null && break; sleep 5; done
sleep 10
curl -s "http://127.0.0.1:18983/solr/admin/collections?action=CLUSTERSTATUS&collection=disccov&wt=json" > $RUNS/clusterstatus-luke-pass.json
cd $T
python3 luke-local.py >> $RUNS/luke-local.log 2>&1; echo "luke-local rc=$?" >> $LOG
cat $RUNS/luke-local.log >> $LOG
SOLR_LOGS_DIR=$T/node2-logs SOLR_PID_DIR=$T/node2-pids $INST/bin/solr stop -p 18984 >> $LOG 2>&1; echo "node2 stop rc=$?" >> $LOG
SOLR_LOGS_DIR=$T/node1-logs SOLR_PID_DIR=$T/node1-pids $INST/bin/solr stop -p 18983 >> $LOG 2>&1; echo "node1 stop rc=$?" >> $LOG
sleep 5
ps aux | grep "[s]olr" | grep -v grep > $RUNS/teardown-ps-final.txt; echo "remaining solr procs: $(wc -l < $RUNS/teardown-ps-final.txt)" >> $LOG
echo "PHASE3 DONE" >> $LOG
cat $LOG
