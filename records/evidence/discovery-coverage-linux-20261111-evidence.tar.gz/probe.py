#!/usr/bin/env python3
"""Discovery coverage probe driver (job discovery-coverage-linux-20261111).

Disposable research probes only. Every request/response is saved verbatim
under the runs directory. Expectations are enumerated from fixture.json plus
verified per-shard placement, never from facet or Luke output.

Usage:
  probe.py env                 record environment
  probe.py setup               upload configset, schema additions, create
                               collection, index fixture, verify placement,
                               delete ghost, capture segment state
  probe.py facets              distributed + per-shard existence facets vs
                               enumerated expectations
  probe.py luke                Luke numTerms=0 distributed + per shard, fq pair
  probe.py failure             queries while shard2 node is down (default and
                               shards.tolerant=true); run between stop/start
  probe.py measure             bounded latency grid on discmeas1/discmeas2
  probe.py teardown-check      confirm no probe processes remain
"""
import json
import os
import sys
import time
import urllib.request
import urllib.error

BASE = os.path.dirname(os.path.abspath(__file__))
RUNS = os.path.join(BASE, "runs")
FIXTURE = json.load(open(os.path.join(BASE, "fixture.json")))
N1 = "http://127.0.0.1:18983"
N2 = "http://127.0.0.1:18984"
COLL = FIXTURE["collection"]
os.makedirs(RUNS, exist_ok=True)
SEQ = [len([f for f in os.listdir(RUNS) if f[:3].isdigit() and f[3] == "-"])]


def save(name, text):
    SEQ[0] += 1
    path = os.path.join(RUNS, f"{SEQ[0]:03d}-{name}")
    with open(path, "w") as f:
        f.write(text)
    return path


def http(method, url, body=None, ctype="application/json"):
    data = None
    headers = {}
    if body is not None:
        data = body.encode() if isinstance(body, str) else body
        headers["Content-Type"] = ctype
    req = urllib.request.Request(url, data=data, headers=headers, method=method)
    try:
        with urllib.request.urlopen(req, timeout=120) as r:
            return r.status, dict(r.headers), r.read().decode("utf-8", "replace")
    except urllib.error.HTTPError as e:
        return e.code, dict(e.headers or {}), e.read().decode("utf-8", "replace")
    except Exception as e:  # connection refused etc: record, do not raise
        return -1, {}, f"TRANSPORT-ERROR: {type(e).__name__}: {e}"


def call(name, method, url, body=None, ctype="application/json"):
    status, headers, text = http(method, url, body, ctype)
    save(name + ".json", json.dumps(
        {"url": url, "method": method, "status": status,
         "headers": headers, "body": text}, indent=1))
    try:
        return status, json.loads(text)
    except Exception:
        return status, None


def wait_live():
    for i in range(60):
        s, _ = call("wait-live", "GET", N1 + "/solr/admin/info/system?wt=json")
        if s == 200:
            return True
        time.sleep(5)
    return False


def cores():
    """Return {shard_name: {"core": core_name, "base": base_url}} where
    base_url is the hosting node's /solr base (replicas may live on either
    node; per-shard requests must go to the hosting node)."""
    s, j = call("clusterstate", "GET",
                N1 + f"/solr/admin/collections?action=CLUSTERSTATUS&collection={COLL}&wt=json")
    shards = j["cluster"]["collections"][COLL]["shards"]
    out = {}
    for shard, info in shards.items():
        for rep in info["replicas"].values():
            out[shard] = {"core": rep["core"], "base": rep["base_url"]}
    return out


def setup():
    assert wait_live(), "node1 never came up"
    # upload configset as a zip built from configset/conf
    import io
    import zipfile
    buf = io.BytesIO()
    confdir = os.path.join(BASE, "configset", "conf")
    with zipfile.ZipFile(buf, "w") as z:
        for root, _, files in os.walk(confdir):
            for fn in files:
                p = os.path.join(root, fn)
                z.write(p, os.path.relpath(p, confdir))
    call("configset-upload", "POST",
         N1 + "/solr/admin/configs?action=UPLOAD&name=disccov-conf",
         buf.getvalue(), "application/octet-stream")
    call("create-collection", "GET",
         N1 + f"/solr/admin/collections?action=CREATE&name={COLL}"
              f"&numShards={FIXTURE['numShards']}"
              f"&replicationFactor={FIXTURE['replicationFactor']}"
              f"&collection.configName=disccov-conf&wt=json")
    for add in FIXTURE["schemaApiAdditions"]:
        call("schema-add", "POST", N1 + f"/solr/{COLL}/schema", json.dumps(add))
    shardmap = cores()
    shardnames = sorted(shardmap)
    # Resolve composite-id route prefixes: a doc id of the form
    # "<prefix>!<name>" is routed by the hash of <prefix>. Index one probe
    # doc per candidate prefix, read back per-shard placement, and keep the
    # first prefix observed on each shard.
    candidates = [f"r{i}" for i in range(40)]
    probe_docs = [{"id": f"{c}!probe"} for c in candidates]
    call("route-probe-index", "POST", N1 + f"/solr/{COLL}/update?commit=true",
         json.dumps(probe_docs))
    cand_shard = {}
    for shard, info in shardmap.items():
        s2, j = call(f"route-probe-{shard}", "GET",
                     info["base"] + f"/{info['core']}/select?q=*:*&distrib=false&fl=id&rows=100&wt=json")
        if not j or "response" not in j:
            raise RuntimeError(f"route-probe select failed on {shard}: status {s2}")
        for d in j["response"]["docs"]:
            cand_shard[d["id"].split("!")[0]] = shard
    prefix_for = {}
    for cand in candidates:
        sh = cand_shard.get(cand)
        if sh and sh not in prefix_for:
            prefix_for[sh] = cand
    assert len(prefix_for) == len(shardnames), f"prefix resolution failed: {prefix_for} vs {cand_shard}"
    call("route-probe-delete", "POST", N1 + f"/solr/{COLL}/update?commit=true",
         json.dumps({"delete": [f"{c}!probe" for c in candidates]}))
    label2shard = {}
    label2prefix = {}
    labels = sorted({d["shard"] for d in FIXTURE["docs"]})
    for i, label in enumerate(labels):
        shard = shardnames[i]
        label2shard[label] = shard
        label2prefix[label] = prefix_for[shard]
    docs = []
    ids = {}
    for d in FIXTURE["docs"]:
        d = dict(d)
        label = d.pop("shard")
        d.pop("deleted", None)
        full = f"{label2prefix[label]}!{d['id']}"
        ids[d["id"]] = full
        d["id"] = full
        docs.append(d)
    call("fixture-index", "POST", N1 + f"/solr/{COLL}/update?commit=true",
         json.dumps(docs))
    # verify placement per shard
    observed = {}
    for shard, info in shardmap.items():
        s2, j = call(f"placement-{shard}", "GET",
                     info["base"] + f"/{info['core']}/select?q=*:*&distrib=false&fl=id&rows=100&wt=json")
        observed[shard] = sorted(d["id"] for d in j["response"]["docs"])
    save("placement.json", json.dumps(
        {"label2shard": label2shard, "label2prefix": label2prefix,
         "ids": ids, "observed": observed}, indent=1))
    # ghost delete, hard commit, no merge
    call("ghost-delete", "POST", N1 + f"/solr/{COLL}/update?commit=true",
         json.dumps({"delete": {"id": ids["ghost1"]}}))
    for shard, info in shardmap.items():
        call(f"segments-{shard}", "GET",
             info["base"] + f"/{info['core']}/admin/segments?wt=json")
    print(json.dumps({"label2shard": label2shard, "observed": observed}, indent=1))


def expected_counts():
    """Enumerate expected live-doc existence counts from the fixture manifest
    and the verified per-shard placement recorded by setup(). A document
    matches the gate filter only on its own fields (a nested child does not
    inherit the parent's filter field). Scopes: distributed,
    distributed-nofilter, shard:<name>, shard:<name>-nofilter."""
    import glob as _glob
    _pf = sorted(_glob.glob(os.path.join(RUNS, "*-placement.json")))
    placement = json.load(open(_pf[-1])) if _pf else None
    ids = placement["ids"]
    doc_shard = {}
    for shard, idlist in placement["observed"].items():
        for full in idlist:
            doc_shard[full] = shard
    shardmap = cores()
    filt = FIXTURE["filter"]
    ffield, fval = filt.split(":")
    scopes = {"distributed": {}, "distributed-nofilter": {}}
    for shard in shardmap:
        scopes[f"shard:{shard}"] = {}
        scopes[f"shard:{shard}-nofilter"] = {}
    for d in FIXTURE["docs"]:
        if d.get("deleted"):
            continue
        entries = [(d, ids[d["id"]])]
        for ch in d.get("_childDocuments_", []):
            entries.append((ch, ch["id"]))
        for doc, full in entries:
            sh = doc_shard.get(full)
            fields = set(doc) - {"shard", "_childDocuments_"}
            in_filter = str(doc.get(ffield)) == fval
            for scope_map, active in (
                    (scopes["distributed"], in_filter),
                    (scopes["distributed-nofilter"], True),
                    (scopes[f"shard:{sh}"], in_filter),
                    (scopes[f"shard:{sh}-nofilter"], True)):
                if active:
                    for f in fields:
                        scope_map[f] = scope_map.get(f, 0) + 1
    return scopes


def facet_request(base_url, fq):
    facets = {f"f_{f}": {"type": "query", "q": f"{f}:*"}
              for f in FIXTURE["facetFields"]}
    body = {"query": "*:*", "filter": fq, "limit": 0, "facet": facets}
    return body


def facets():
    scopes = expected_counts()
    shardmap = cores()
    # combined request (all fields in one facet block), saved verbatim
    call("facets-combined-distributed", "POST", N1 + f"/solr/{COLL}/query",
         json.dumps(facet_request(N1, FIXTURE["filter"])))
    for shard, info in shardmap.items():
        call(f"facets-combined-{shard}", "POST",
             info["base"] + f"/{info['core']}/query?distrib=false",
             json.dumps(facet_request(N1, FIXTURE["filter"])))
    # individual requests, one field per facet block, so a field whose
    # existence query is unsupported cannot mask the others
    results = {"distributed": {}}
    for shard in shardmap:
        results[f"shard:{shard}"] = {}
    for f in FIXTURE["facetFields"]:
        body = {"query": "*:*", "filter": FIXTURE["filter"], "limit": 0,
                "facet": {f"f_{f}": {"type": "query", "q": f"{f}:*"}}}
        s2, j = call(f"facets-ind-distributed-{f}", "POST",
                     N1 + f"/solr/{COLL}/query", json.dumps(body))
        results["distributed"][f] = (
            (j or {}).get("facets", {}).get(f"f_{f}", {}).get("count")
            if s2 == 200 else f"HTTP {s2}")
        for shard, info in shardmap.items():
            s2, j = call(f"facets-ind-{shard}-{f}", "POST",
                         info["base"] + f"/{info['core']}/query?distrib=false",
                         json.dumps(body))
            results[f"shard:{shard}"][f] = (
                (j or {}).get("facets", {}).get(f"f_{f}", {}).get("count")
                if s2 == 200 else f"HTTP {s2}")
    table = {}
    for scope, observed in results.items():
        table[scope] = {}
        for f in FIXTURE["facetFields"]:
            exp = scopes[scope].get(f, 0)
            obs = observed.get(f)
            table[scope][f] = {"expected": exp, "observed": obs,
                               "match": exp == obs}
    save("facet-comparison.json", json.dumps(table, indent=1))
    print(json.dumps(table, indent=1))


def luke():
    shardmap = cores()
    call("luke-distributed", "GET",
         N1 + f"/solr/{COLL}/admin/luke?numTerms=0&wt=json")
    call("luke-distributed-fq", "GET",
         N1 + f"/solr/{COLL}/admin/luke?numTerms=0&wt=json&fq={FIXTURE['filter']}")
    for shard, info in shardmap.items():
        call(f"luke-{shard}", "GET",
             info["base"] + f"/{info['core']}/admin/luke?numTerms=0&wt=json")
        call(f"luke-{shard}-fq", "GET",
             info["base"] + f"/{info['core']}/admin/luke?numTerms=0&wt=json&fq={FIXTURE['filter']}")


def failure():
    body = facet_request(N1, FIXTURE["filter"])
    call("failure-default", "POST", N1 + f"/solr/{COLL}/query", json.dumps(body))
    call("failure-tolerant", "POST",
         N1 + f"/solr/{COLL}/query?shards.tolerant=true", json.dumps(body))
    call("failure-select-default", "GET",
         N1 + f"/solr/{COLL}/select?q=*:*&rows=0&wt=json")
    call("failure-select-tolerant", "GET",
         N1 + f"/solr/{COLL}/select?q=*:*&rows=0&wt=json&shards.tolerant=true")


def measure():
    # synthetic measurement collections are created by the shell wrapper if
    # missing; here we just run the grid against both and the fixture coll.
    grids = []
    for coll, shards in (("discmeas1", 1), ("discmeas2", 2), (COLL, 2)):
        for nfields in (1, 10, 50):
            fields = [f"m{i}_s" for i in range(nfields)]
            facets = {f"f_{f}": {"type": "query", "q": f"{f}:*"}
                      for f in fields}
            body = {"query": "cat_s:meas", "limit": 0, "facet": facets}
            times = []
            for rep in range(5):  # 2 warmup + 3 measured
                t0 = time.time()
                s, j = call(f"measure-{coll}-{nfields}-{rep}", "POST",
                            N1 + f"/solr/{coll}/query", json.dumps(body))
                dt = time.time() - t0
                if rep >= 2:
                    times.append(round(dt, 4))
            grids.append({"collection": coll, "shards": shards,
                          "fields": nfields, "times_s": times})
    save("measurements.json", json.dumps(grids, indent=1))
    print(json.dumps(grids, indent=1))


if __name__ == "__main__":
    cmd = sys.argv[1]
    {"setup": setup, "facets": facets, "luke": luke,
     "failure": failure, "measure": measure}[cmd]()
