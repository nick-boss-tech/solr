#!/usr/bin/env bash
set -u
E=/workspace/evidence/discovery-field-glob-linux-20261117
W=/workspace/worktrees/discovery-field-glob-linux-20261117/solr
name=$1
shift
mkdir -p "$E/results"
{
  printf 'started=%s\n' "$(date --iso-8601=seconds)"
  printf 'worktree=%s\n' "$W"
  printf 'head=%s\n' "$(git -C "$W" rev-parse HEAD)"
  printf 'command='; printf '%q ' "$@"; printf '\n'
  printf 'timeout_default_seconds=3600\nheartbeat_default_seconds=30\nresource_interval_seconds=5\n'
  printf 'locks=%s,%s\n' /workspace/tools/.gradle-phone-agent-2.lock /workspace/tools/.gradle-0609f7968656.lock
} > "$E/results/$name.command.txt"
export JAVA_HOME=/usr/lib/jvm/java-21-openjdk-amd64
export GRADLE_USER_HOME=/workspace/gradle-home
export PATH="$JAVA_HOME/bin:$PATH"
flock -n /workspace/tools/.gradle-phone-agent-2.lock \
  flock -n /workspace/tools/.gradle-0609f7968656.lock \
  python3 /workspace/tools/solr-live-build.py \
    --worktree "$W" \
    --logdir "$E/results" \
    --name "$name" \
    --interval 5 \
    -- "$@"
rc=$?
printf 'exit_code=%s\nfinished=%s\n' "$rc" "$(date --iso-8601=seconds)" > "$E/results/$name.exit.txt"
printf '%s exit_code=%s\n' "$name" "$rc"
exit 0
