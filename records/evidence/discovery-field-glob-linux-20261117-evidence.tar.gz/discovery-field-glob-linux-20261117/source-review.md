# Source review: discovery field glob gate

Pinned source: `nick-boss-tech/solr` branch `discovery-fields-prototype`, commit `9db4daca489dcca3a8441268316462111752bd35`. The detached checkout was clean before testing.

## Bounded matching and selection

`DiscoveryFieldsRequestHandler` defaults `fieldGlob` to `*`, rejects patterns longer than 256 characters, and uses an iterative dynamic-programming matcher for `*` and `?` rather than a backtracking regex. It checks query limits during long field-name matching (every 128 characters) and while traversing indexed fields and rank terms. It gathers matching field names into a sorted set, excludes the internal rank field from the indexed-field pass, then applies the 256-field cap to the selected set before counting/document output.

## Focused test coverage reviewed

`DiscoveryFieldsRequestHandlerTest.testFieldGlobAndFilteredCounts` makes the default request and verifies the returned `alpha_s` count is filtered by `fq`; checks `?eta_*` and `*a*ha_?`; verifies `missing*` returns no fields; rejects a 257-character pattern; adds 257 candidate fields, verifies the default selection exceeds the limit, then narrows to `wide1_s` and verifies one selected field with count 1. The focused test does not establish rank-field behavior, SolrCloud routing, unavailable-count cases, or full endpoint behavior; those remain outside this proof.

## Review limits

This is source/test inspection plus the assigned focused test and Gradle checks only. It is not a review of unrelated endpoint semantics or deployment behavior.
