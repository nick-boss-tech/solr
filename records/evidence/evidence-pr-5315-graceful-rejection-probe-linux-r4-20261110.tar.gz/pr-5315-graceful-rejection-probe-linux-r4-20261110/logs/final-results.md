# PR #5315 graceful-rejection probe r4 — final results

**Verdict: incomplete.** All findings below are for disposable prototype work against the assigned source head, not production-ready code.

## Source and execution

The disposable Solr checkout was based on `d88ae0c6269e067602a90ed8e655df275f6f42f7`, matching the live `nick-boss-tech/solr` `solr-17764-submit` branch. The public upstream PR is [apache/solr#5315](https://github.com/apache/solr/pull/5315), open and non-draft at `dfde089fd9dd0e5e79774593e66dd030e1b7dd22`. Environment: Linux, JDK 21; all Gradle work was serialized under both designated phone-agent-2 locks with a 15% free-inode stop threshold. No Docker was installed or used. No production source branch was pushed and no public comment was posted.

## Gate outcomes

- **Unchanged-head baseline:** `./gradlew --no-daemon :solr:solrj:test --tests org.apache.solr.client.solrj.impl.CloudSolrClientCacheTest -Ptests.seed=17764C0DE --rerun-tasks` — run 10, exit 0, 12/12 passed. Fresh XML: `xml/10-baseline-cachetest.xml`.
- **Real fail-before reproduction:** before the r4 CloudSolrClient retry correction, run 46 executed `./gradlew --no-daemon :solr:core:test --tests org.apache.solr.cloud.ProbeGracefulMultiShardTest -Ptests.seed=17764C0DE --rerun-tasks` — exit 1, one test with the intended assertion failure. In RF=1 parallel exhaustion, a genuine pre-handler marked rejection was held until the other shard's atomic increment was persisted. The healthy shard was then sent six times and persisted `count_i=6` instead of 1; the rejected shard saw six marked rejects and stayed at 0. Overall request failed with `CloudSolrClient$RouteException: No live SolrServers available to handle this request`. JUnit states `expected:<1> but was:<6>`. Sequential exhaustion did not replay the completed shard in that run. Fresh XML: `xml/46-directupdate-before.xml`; the full patch-before and output are preserved.
- **Final corrected multi-shard run:** after the narrow disposable correction and final tidy/test cleanup, run 60 executed `./gradlew --no-daemon :solr:core:test --tests org.apache.solr.cloud.ProbeGracefulMultiShardTest -Ptests.seed=17764C0DE --rerun-tasks` — exit 0, 1/1 passed. On the RF=2 success leg, the completed shard's two replica cores each saw one passed request; the marked target core saw five pre-handler rejects; its alternate leader saw one passed request. Both persisted atomic increments were exactly 1 and the request succeeded. Delete-by-query and commit succeeded and the deleted document was absent. In RF=1 exhaustion, both parallel and sequential legs confirmed the first shard had persisted 1 before releasing the rejection; after rejection, the completed shard still had exactly one request and value 1, the rejected shard had one rejection and value 0, and the overall request failed. Fresh XML: `xml/60-multishard-final.xml`; per-core counters and persisted values are in `logs/60-multishard-final-test-output.txt`.
- **Final client/repeatability/trust/async run:** run 61 executed `./gradlew --no-daemon :solr:solrj:test --tests org.apache.solr.client.solrj.impl.ProbeGracefulRejectionClientTest -Ptests.seed=17764C0DE --rerun-tasks` — exit 0, 12/12 passed. Coverage includes one-shot iterator and custom payload/writer fail-closed paths, unmarked application 503s, unmarked mixed-version-style rejections, no-alternate behavior, V2/unspecified requests, marked async UPDATE non-replay for both JDK and Jetty transports, and a forged marker. The forged-marker case deliberately demonstrates the trust defect: an application handler is reached, emits a marked 503, and the client retries to the healthy endpoint. Fresh XML: `xml/61-client-final.xml`.
- **Final Jetty body-close run:** run 62 executed `./gradlew --no-daemon :solr:solrj-jetty:test --tests org.apache.solr.client.solrj.jetty.ProbeGracefulRejectionJettyBodyCloseTest -Ptests.seed=17764C0DE --rerun-tasks` — exit 0, 1/1 passed. Fresh XML: `xml/62-jetty-final.xml`. The client suite separately verifies JDK marked-response stream closure.
- `./gradlew --no-daemon tidy` completed successfully in runs 57 and 59. The final multi-shard, client and Jetty tests above were run after those formatting passes and after the final multi-shard test corrections. Earlier setup/invocation attempts (runs 42–45) are preserved but are not treated as behavioral proof; run 46 is the valid fail-before reproduction.

## Disposable prototype changes

The exact patch is `review/r4-final-disposable.patch` (10 files; SHA-256 recorded in the package manifest). It adds a test-only `JettySolrRunner` graceful-rejection marker handler, a `GracefulShutdownRejectionException`, marker handling and body closure in the JDK/Jetty response processors, a guarded synchronous `LBSolrClient` retry restricted to a materialized base V1 `UpdateRequest` with stock JavaBin/XML serialization, and a `CloudSolrClient` guard that prevents whole-batch 503 retry when a parallel `RouteException` contains the marker exception. The new four-node/two-shard probe verifies counts and persisted values; client tests cover async UPDATE non-replay and failure cases.

## Why the verdict remains incomplete

1. **Marker origin is not authenticated.** The client accepts any HTTP 503 carrying `X-Solr-Graceful-Shutdown`; the forged-marker test proves an application response can authorize a duplicate retry. No header-modifying proxy was run and no direct-node integrity boundary is enforced.
2. **Repeatability is not a snapshot guarantee.** Unknown request types, subclasses, V2, iterator-backed updates, request-level content writers and non-stock client writers fail closed. However, the allowed materialized `UpdateRequest` retains mutable documents/params; the guard assumes the caller does not mutate them during the synchronous request and does not snapshot them.
3. **Production packaging is unverified.** The marker emitter is only the property-gated test-framework handler in `JettySolrRunner`; no production packaged server build/start was performed. Production runtime marker emission remains an explicit gap.
4. **Mixed-version evidence is a fake endpoint, not an older Solr distribution.** Unmarked rejection behavior is tested, but a real old-version server was not deployed.
5. **Async UPDATE no-replay is demonstrated for both transports, but async response-body closure and all async query/failover behavior are not comprehensively tested.** The new retry design is synchronous only.
6. **The original in-flight indexing 503 remains unresolved.** The marker describes a pre-handler rejection; it does not resolve requests already executing inside the update handler.

## Executor stop

The last Gradle run (run 62) ended 2026-11-10 18:39:55 -07:00 with exit 0 and `inode_threshold_stop=no`. Immediately afterward, both required lock files were acquired non-blockingly, no Gradle/Solr executor remained (only the inspection `grep` process was visible), the assigned head was rechecked, and free inodes were 39%. Raw run metadata, fresh XML, full test outputs and the source patch are preserved alongside this note.


## Patch verification

`review/r4-final-disposable.patch` contains 10 repository-relative diff sections; SHA-256 `79fe67b64846949b497bad9ab3f5f7d29167e454163d0f2f5afa40ac0835d013`. `git apply --check` passed in a clean detached worktree at the assigned head, and the temporary verification worktree was removed. The primary disposable source checkout remains at the assigned SHA with the probe changes uncommitted and unpublished.


## Predecessor verification

Before using the r3 prototype, its live coordination-v2 evidence archive hash was checked against the r3 receipt: both are `190620078e30d04e5c7db9fd0779572b83edf04eb192d33782dbfc95be1857ed`. The extracted `prototype.patch` SHA-256 is `ecc496789bcec490c3002ba4763d79f61e52f47563cd653dec00425fd9c78a05`. Before r4-specific changes, the unchanged r3 client test passed 6/6 (run 20; `:solr:solrj:test --tests org.apache.solr.client.solrj.impl.ProbeGracefulRejectionClientTest -Ptests.seed=17764C0DE --rerun-tasks`, exit 0, `xml/20-r3-client-probe.xml`), and its real-node probe passed 3/3 (run 30; `:solr:core:test --tests org.apache.solr.cloud.ProbeGracefulRejectionTest -Ptests.seed=17764C0DE --rerun-tasks`, exit 0, `xml/30-r3-real-node-probe.xml`).
