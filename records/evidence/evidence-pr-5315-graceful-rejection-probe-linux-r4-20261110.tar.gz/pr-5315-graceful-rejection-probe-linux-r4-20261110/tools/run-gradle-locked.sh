#!/usr/bin/env bash
set -uo pipefail

LOCK1=/workspace/tools/.gradle-phone-agent-2.lock
LOCK2=/workspace/tools/.gradle-0609f7968656.lock
ROOT=/workspace/worktrees/pr-5315-graceful-rejection-probe-linux-r4-20261110
EVIDENCE=/workspace/gates/logs/phone-agent-2/pr-5315-graceful-rejection-probe-linux-r4-20261110

if [[ "${1:-}" != "--locked" ]]; then
  exec flock -x "$LOCK1" flock -x "$LOCK2" "$0" --locked "$@"
fi
shift

if [[ $# -lt 1 ]]; then
  echo 'usage: run-gradle-locked.sh RUN_ID TASK_AND_ARGS...' >&2
  exit 64
fi
run_id=$1
shift
if [[ ! "$run_id" =~ ^[A-Za-z0-9._-]+$ ]]; then
  echo "invalid run id: $run_id" >&2
  exit 64
fi
log="$EVIDENCE/logs/$run_id.log"
meta="$EVIDENCE/logs/$run_id.meta"
monitor="$EVIDENCE/logs/$run_id.inodes.csv"
stopflag="$EVIDENCE/logs/$run_id.inode-stop"
if [[ -e "$log" || -e "$meta" || -e "$monitor" || -e "$stopflag" ]]; then
  echo "refusing to overwrite evidence for $run_id" >&2
  exit 73
fi
mkdir -p "$EVIDENCE/logs"
cd "$ROOT"
export JAVA_HOME=/usr/lib/jvm/java-21-openjdk-amd64
export GRADLE_USER_HOME=/workspace/gradle-home
export PATH="$JAVA_HOME/bin:$PATH"

command_text='./gradlew --no-daemon'
for arg in "$@"; do
  printf -v quoted ' %q' "$arg"
  command_text+="$quoted"
done

inode_snapshot() {
  df -Pi /workspace | awk 'NR==2 {print $2, $3, $4, $5}'
}
read -r total used free pct < <(inode_snapshot)
if [[ -z "${total:-}" || "$total" -le 0 ]]; then
  echo 'cannot read inode availability; refusing to start' >&2
  exit 75
fi
if (( free * 100 <= total * 15 )); then
  printf '%s\n' "run_id=$run_id" "command=$command_text" 'started=no' 'reason=free inode reserve is at or below 15%' > "$meta"
  echo "refusing to start: inode free=$free/$total ($pct)" >&2
  exit 75
fi

start_epoch=$(date +%s)
{
  printf 'run_id=%s\n' "$run_id"
  printf 'host=%s\n' "$(hostname)"
  printf 'head=%s\n' "$(git rev-parse HEAD)"
  printf 'started_at=%s\n' "$(date -Is)"
  printf 'start_epoch=%s\n' "$start_epoch"
  printf 'JAVA_HOME=%s\n' "$JAVA_HOME"
  printf 'GRADLE_USER_HOME=%s\n' "$GRADLE_USER_HOME"
  printf 'lock1=%s\nlock2=%s\n' "$LOCK1" "$LOCK2"
  printf 'command=%s\n' "$command_text"
  printf 'inode_start=%s %s %s %s\n' "$total" "$used" "$free" "$pct"
} > "$meta"
printf 'timestamp,total,used,free,pct\n' > "$monitor"
rm -f "$stopflag"

./gradlew --no-daemon "$@" > "$log" 2>&1 &
gradle_pid=$!
printf 'gradle_pid=%s\n' "$gradle_pid" >> "$meta"

kill_tree() {
  local pid=$1 sig=${2:-TERM} child
  for child in $(pgrep -P "$pid" 2>/dev/null || true); do
    kill_tree "$child" "$sig"
  done
  kill -"$sig" "$pid" 2>/dev/null || true
}

watch_inodes() {
  local total used free pct state tick=0
  while :; do
    state=$(ps -o stat= -p "$gradle_pid" 2>/dev/null | tr -d ' ' || true)
    if [[ -z "$state" || "$state" == Z* ]]; then
      break
    fi
    read -r total used free pct < <(inode_snapshot)
    if [[ -z "${total:-}" || "$total" -le 0 ]]; then
      echo "$(date -Is),unknown,unknown,unknown,unknown" >> "$monitor"
      printf 'inode-monitor-error_at=%s\n' "$(date -Is)" >> "$meta"
      touch "$stopflag"
      kill_tree "$gradle_pid" TERM
      sleep 10
      kill -0 "$gradle_pid" 2>/dev/null && kill_tree "$gradle_pid" KILL
      break
    fi
    echo "$(date -Is),$total,$used,$free,$pct" >> "$monitor"
    if (( free * 100 <= total * 15 )); then
      printf 'inode-threshold-stop_at=%s free=%s/%s pct=%s\n' "$(date -Is)" "$free" "$total" "$pct" | tee -a "$meta"
      touch "$stopflag"
      kill_tree "$gradle_pid" TERM
      for _ in $(seq 1 15); do
        state=$(ps -o stat= -p "$gradle_pid" 2>/dev/null | tr -d ' ' || true)
        [[ -z "$state" || "$state" == Z* ]] && break
        sleep 1
      done
      state=$(ps -o stat= -p "$gradle_pid" 2>/dev/null | tr -d ' ' || true)
      [[ -z "$state" || "$state" == Z* ]] || kill_tree "$gradle_pid" KILL
      break
    fi
    tick=$((tick + 15))
    if (( tick >= 60 )); then
      printf 'monitor_heartbeat=%s inode_free=%s/%s (%s)\n' "$(date -Is)" "$free" "$total" "$pct"
      tick=0
    fi
    sleep 15
  done
}
watch_inodes &
monitor_pid=$!
set +e
wait "$gradle_pid"
rc=$?
wait "$monitor_pid"
set -u
end_epoch=$(date +%s)
{
  printf 'ended_at=%s\n' "$(date -Is)"
  printf 'end_epoch=%s\n' "$end_epoch"
  printf 'exit_code=%s\n' "$rc"
  if [[ -e "$stopflag" ]]; then printf 'inode_threshold_stop=yes\n'; else printf 'inode_threshold_stop=no\n'; fi
  read -r total used free pct < <(inode_snapshot)
  printf 'inode_end=%s %s %s %s\n' "$total" "$used" "$free" "$pct"
} >> "$meta"
echo "run_id=$run_id exit_code=$rc inode_threshold_stop=$([[ -e "$stopflag" ]] && echo yes || echo no)"
tail -n 24 "$log" || true
exit "$rc"
