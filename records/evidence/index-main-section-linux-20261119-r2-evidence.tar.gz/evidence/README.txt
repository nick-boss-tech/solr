index-main-section-linux-20261119-r2 evidence
head c5955f3d47ffc8ff21bd59f77ae6846263ced4c6 (branch index-query-main-section)
host vm2, Linux, JDK 21

Files
  ui-check-executed.log   ./gradlew -p ui check --no-build-cache --rerun-tasks (fresh execution)
  ui-check.log            earlier UI run at the same head (UP-TO-DATE only; not the recorded run)
  root-check.log          ./gradlew check -x test -Prefguide.include=false
  failbefore.log          base state holder 90d4efb + candidate assertion; expected </select> but was <null>
  live-ui-build.log       :solr:packaging:assemble and :webApp:wasmJsBrowserDistribution
  live-api-checks.txt     live Solr 8983: collections, handler endpoint/wire format, invalid collection 404
  ui/*.png                live browser exercise screenshots (see names)

Live UI sequence (screenshots)
  01-connect.png                 connect to http://127.0.0.1:8983/
  02-films-handlers-loaded.png   Index & Query: collections books/films/no_select, films handlers from Solr
  03-films-select-chosen.png     films + /select (solr.SearchHandler)
  04-books-select-preserved.png  switch to books; /select preserved
  05-no_select-handler-cleared.png switch to no_select (no /select); handler cleared
  06-configsets.png              sidebar Configsets, selected item
  07-configset-list.png          configsets _default/books/films/no-select from Solr
  08-return-indexquery-state-kept.png  back to Index & Query; no_select kept, handler empty

Environment
  CHROME_BIN=/opt/playwright-browsers/chromium-current
  LD_LIBRARY_PATH=/tmp/ui-egl-stub (three-symbol EGL stub)
  JAVA_TOOL_OPTIONS=-Dskiko.renderApi=SOFTWARE_FAST
  Collections: films, books (default configset), no_select (configset with /select renamed /select_hidden)
