#!/bin/bash
set -u
T=~/workspace/tools/5075-rf; R=$T/runs2; SUM=$R/summary.txt
C=~/workspace/solr-clones/5075-regate; cd $C
echo "check-rerun HEAD=$(git rev-parse HEAD) modified=$(git status --porcelain | grep -v '^??' | wc -l)" | tee -a $SUM
ls solr/webapp/build/ui-download/ 2>/dev/null | tee -a $SUM
if [ ! -f solr/webapp/build/ui-download/solr-ui-wasm-473a55ef64a9a1605e00eb6c1c386887d4cb7dac.zip ]; then
  mkdir -p solr/webapp/build/ui-download
  curl -sL --max-time 300 -o solr/webapp/build/ui-download/solr-ui-wasm-473a55ef64a9a1605e00eb6c1c386887d4cb7dac.zip https://nightlies.apache.org/solr/ui/wasm/473a55ef64a9a1605e00eb6c1c386887d4cb7dac/solr-ui-wasm.zip
  echo "wasm re-seeded sha: $(sha256sum solr/webapp/build/ui-download/solr-ui-wasm-473a55ef64a9a1605e00eb6c1c386887d4cb7dac.zip | cut -d' ' -f1)" | tee -a $SUM
fi
{
  flock 9
  pkill -f "Gradle[Daemon]" 2>/dev/null; sleep 1; rm -f ~/.gradle/caches/journal-1/journal-1.lock
  timeout 3600 ~/workspace/tools/solr-gradle.sh check -x test --console=plain 9>&- > $R/check-rerun.log 2>&1
  echo "check rerun rc=$?" | tee -a $SUM
  grep -E "BUILD (SUCCESSFUL|FAILED)" $R/check-rerun.log | tail -1 | tee -a $SUM
} 9>~/workspace/tools/.solr-test-queue.lock
echo "CHECK RERUN DONE $(date -Is)" | tee -a $SUM
