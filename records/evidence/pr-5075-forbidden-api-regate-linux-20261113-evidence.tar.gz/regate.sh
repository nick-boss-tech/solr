#!/bin/bash
set -u
T=~/workspace/tools/5075-rf; R=$T/runs2; mkdir -p $R; SUM=$R/summary.txt; : > $SUM
G=~/workspace/tools/solr-gradle.sh
C=~/workspace/solr-clones/5075-regate
rm -rf "$C"; mkdir -p "$C"; cd "$C"
git init -q .; git remote add origin https://github.com/nick-boss-tech/solr.git
for attempt in 1 2 3 4 5; do git fetch -q --depth 30 origin solr-5939-submit && break; sleep 5; done
git checkout -q 5b3693c44ca057dc42addb43af97c168634d6301
echo "HEAD=$(git rev-parse HEAD) modified=$(git status --porcelain | wc -l)" | tee -a $SUM
echo "--- full diff vs dc825f9a" | tee -a $SUM
git diff dc825f9af929a7ad8d08f8eb51e969e72582acb2 HEAD | tee $R/diff.txt | tee -a $SUM
cp ~/workspace/solr/gradle.properties .
grep "solr.ui" gradle.properties | tee -a $SUM
mkdir -p solr/webapp/build/ui-download
curl -sL --max-time 300 -o solr/webapp/build/ui-download/solr-ui-wasm-473a55ef64a9a1605e00eb6c1c386887d4cb7dac.zip https://nightlies.apache.org/solr/ui/wasm/473a55ef64a9a1605e00eb6c1c386887d4cb7dac/solr-ui-wasm.zip
echo "wasm sha: $(sha256sum solr/webapp/build/ui-download/solr-ui-wasm-473a55ef64a9a1605e00eb6c1c386887d4cb7dac.zip | cut -d' ' -f1)" | tee -a $SUM
{
  flock 9
  pkill -f "Gradle[Daemon]" 2>/dev/null; sleep 1; rm -f ~/.gradle/caches/journal-1/journal-1.lock
  timeout 1800 $G :solr:core:forbiddenApisTest --console=plain 9>&- > $R/forbidden.log 2>&1
  echo "forbiddenApisTest rc=$?" | tee -a $SUM
  find solr -path "*build/test-results/test" -name "TEST-*.xml" -delete 2>/dev/null
  timeout 2400 $G :solr:core:test --tests org.apache.solr.update.StreamingSolrClientsErrorAttributionTest --tests org.apache.solr.update.SolrCmdDistributorTest -Ptests.seed=5075C0DE --console=plain 9>&- > $R/core.log 2>&1
  echo "core rc=$?" | tee -a $SUM
  mkdir -p $R/core-xml; cp solr/core/build/test-results/test/TEST-org.apache.solr.update.StreamingSolrClientsErrorAttributionTest.xml solr/core/build/test-results/test/TEST-org.apache.solr.update.SolrCmdDistributorTest.xml $R/core-xml/ 2>/dev/null || echo "core XML MISSING" | tee -a $SUM
  find solr -path "*build/test-results/test" -name "TEST-*.xml" -delete 2>/dev/null
  timeout 2400 $G :solr:solrj-jetty:test --tests org.apache.solr.client.solrj.jetty.ConcurrentUpdateJettySolrClientTest --tests org.apache.solr.client.solrj.jetty.ConcurrentUpdateJettySolrClientBadInputTest -Ptests.seed=5075C0DE --console=plain 9>&- > $R/jetty.log 2>&1
  echo "jetty rc=$?" | tee -a $SUM
  mkdir -p $R/jetty-xml; cp solr/solrj-jetty/build/test-results/test/TEST-*.xml $R/jetty-xml/ 2>/dev/null || echo "jetty XML MISSING" | tee -a $SUM
  timeout 1200 $G tidy --console=plain 9>&- > $R/tidy.log 2>&1
  echo "tidy rc=$? tracked changes: $(git status --porcelain | grep -v '^??' | wc -l)" | tee -a $SUM
  git status --porcelain | grep -v '^??' >> $SUM
  pkill -f "Gradle[Daemon]" 2>/dev/null; sleep 1; rm -f ~/.gradle/caches/journal-1/journal-1.lock
  timeout 3600 $G check -x test --console=plain 9>&- > $R/check.log 2>&1
  echo "check rc=$?" | tee -a $SUM
  grep -E "BUILD (SUCCESSFUL|FAILED)" $R/check.log | tail -1 | tee -a $SUM
} 9>~/workspace/tools/.solr-test-queue.lock
echo "REGATE LEGS DONE $(date -Is)" | tee -a $SUM
