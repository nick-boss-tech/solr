#!/bin/bash
set -u
T=~/workspace/tools/5075-rf; SUM=$T/runs/summary.txt
C=~/workspace/solr-clones/5075-rf-fb
rm -rf "$C"; mkdir -p "$C"; cd "$C"
git init -q .; git remote add origin https://github.com/nick-boss-tech/solr.git
for attempt in 1 2 3 4 5; do git fetch -q --depth 30 origin f8d4bdbea518901e255ae119f3e5c43e7804a9bf && break; sleep 5; done
git checkout -q f8d4bdbea518901e255ae119f3e5c43e7804a9bf
echo "FB HEAD=$(git rev-parse HEAD)" | tee -a $SUM
git --git-dir=/home/hatch/workspace/solr-clones/5075-rf/.git show dc825f9af929a7ad8d08f8eb51e969e72582acb2:solr/core/src/test/org/apache/solr/update/StreamingSolrClientsErrorAttributionTest.java > solr/core/src/test/org/apache/solr/update/StreamingSolrClientsErrorAttributionTest.java
echo "overlay status (expect exactly 1 modified file):" | tee -a $SUM; git status --porcelain | tee -a $SUM
cp ~/workspace/solr/gradle.properties .
{
  flock 9
  pkill -f "Gradle[Daemon]" 2>/dev/null; sleep 1; rm -f ~/.gradle/caches/journal-1/journal-1.lock
  find solr -path "*build/test-results/test" -name "TEST-*.xml" -delete 2>/dev/null
  timeout 2400 ~/workspace/tools/solr-gradle.sh :solr:core:test --tests "org.apache.solr.update.StreamingSolrClientsErrorAttributionTest.testDeleteByQueryRetryRuleIsJudgedOnItsOwnRequest" -Ptests.seed=5075C0DE --console=plain 9>&- > $T/runs/failbefore.log 2>&1
  echo "failbefore rc=$?" | tee -a $SUM
  cp solr/core/build/test-results/test/TEST-org.apache.solr.update.StreamingSolrClientsErrorAttributionTest.xml $T/runs/failbefore.xml 2>/dev/null || echo "FB XML MISSING" | tee -a $SUM
} 9>~/workspace/tools/.solr-test-queue.lock
echo "FAILBEFORE DONE $(date -Is)" | tee -a $SUM
