import json, time, sys, urllib.request, base64
from selenium import webdriver
from selenium.webdriver.chrome.service import Service
from selenium.webdriver.common.by import By
from selenium.webdriver.support.ui import WebDriverWait
from selenium.webdriver.support import expected_conditions as EC

BASE = "http://127.0.0.1:18993/solr"
USER, OLD_PASS, NEW_PASS = "solr", "SolrRocks", "RotatedPass1"
LOG = []
def log(step, **kw):
    LOG.append({"step": step, **kw}); print(step, kw, flush=True)
def wait(d, cond, t=30): return WebDriverWait(d, t).until(cond)

opts = webdriver.ChromeOptions()
opts.binary_location = "/home/hatch/workspace/tools/cft157/chrome-linux64/chrome"
opts.add_argument("--headless=new"); opts.add_argument("--no-sandbox"); opts.add_argument("--disable-dev-shm-usage"); opts.add_argument("--window-size=1920,1200")
d = webdriver.Chrome(service=Service("/home/hatch/.cache/selenium/chromedriver/linux64/157.0.8103.50/chromedriver"), options=opts)
d.set_page_load_timeout(60)
HOOK = ("const original = window.fetch;"
 " window.fetch = async function(input, init) {"
 " const request = input instanceof Request ? input : new Request(input, init);"
 " const response = await original.call(this, input, init);"
 " if (new URL(request.url).pathname.endsWith('/api/collections') && request.method === 'GET') {"
 " let collections = false;"
 " try { collections = Array.isArray((await response.clone().json()).collections); } catch (ignored) {}"
 " const auth = sessionStorage.getItem('auth.header');"
 " window.explorerResult = {status: response.status, collections: collections,"
 " authenticated: !!auth && request.headers.get('Authorization') === auth,"
 " sentAuthorization: request.headers.get('Authorization') !== null,"
 " requestedWith: request.headers.get('X-Requested-With')};"
 " } return response; };")

def click_poll(xpath, t=40):
    end = time.time() + t
    last = None
    while time.time() < end:
        try:
            el = d.find_element(By.XPATH, xpath)
            if el.is_displayed():
                el.click(); return
        except Exception as e:
            last = e
        time.sleep(0.4)
    raise TimeoutError("click_poll failed for " + xpath + " last=" + str(last)[:120])
def login(user, pw):
    d.get(BASE + "/index.html#/")
    d.execute_script("sessionStorage.clear();")
    d.get(BASE + "/index.html")
    wait(d, EC.presence_of_element_located((By.ID, "username"))).send_keys(user)
    d.find_element(By.ID, "password").send_keys(pw)
    d.find_element(By.XPATH, "//div[@id='login']//button[@type='submit']").click()
    wait(d, EC.presence_of_element_located((By.ID, "index")))
def open_explorer_and_send():
    d.get(BASE + "/index.html#/~api-explorer")
    frame = wait(d, EC.presence_of_element_located((By.CSS_SELECTOR, "#content #api-explorer iframe")))
    d.switch_to.frame(frame)
    grp = wait(d, EC.presence_of_element_located((By.XPATH, "//button[@aria-expanded and .//div[contains(@class,'group/button-label') and normalize-space(.)='collections']]")))
    if grp.get_attribute("aria-expanded") == "false":
        click_poll("//button[@aria-expanded and .//div[contains(@class,'group/button-label') and normalize-space(.)='collections']]")
    click_poll("//button[.//div[contains(@class,'group/button-label') and contains(., 'List all collections in this Solr cluster')]]")
    d.execute_script(HOOK)
    click_poll("//button[contains(@class,'show-api-client-button') and @method='get' and contains(., '(get /collections)')]")
    click_poll("//div[contains(@class,'scalar-address-bar')]//button[.//span[contains(., 'Send get request')]]")
    wait(d, lambda dr: dr.execute_script("return !!window.explorerResult;"))
    return d.execute_script("return window.explorerResult;")
def send_again():
    d.execute_script("window.explorerResult = undefined;")
    click_poll("//div[contains(@class,'scalar-address-bar')]//button[.//span[contains(., 'Send get request')]]")
    wait(d, lambda dr: dr.execute_script("return !!window.explorerResult;"))
    return d.execute_script("return window.explorerResult;")
def api_post(path, payload, user, pw):
    req = urllib.request.Request(BASE.replace('/solr','') + path, data=json.dumps(payload).encode(), method='POST')
    req.add_header('Content-Type', 'application/json')
    req.add_header('Authorization', 'Basic ' + base64.b64encode(f"{user}:{pw}".encode()).decode())
    try:
        with urllib.request.urlopen(req, timeout=15) as r: return r.status
    except urllib.error.HTTPError as e: return e.code

try:
    login(USER, OLD_PASS); log("phase1-login", ok=True)
    r1 = open_explorer_and_send(); log("phase1-explorer", result=r1)
    d.execute_script("window.__probeMark = 4242;")
    log("phase2-rotate-api", status=api_post("/solr/admin/authentication", {"set-user": {USER: NEW_PASS}}, USER, OLD_PASS))
    time.sleep(1)
    r2 = send_again(); log("phase2-explorer-after-revoke", result=r2,
                             storedHeaderStillPresent=bool(d.execute_script("return sessionStorage.getItem('auth.header') !== null;")))
    d.switch_to.default_content()
    d.get(BASE + "/index.html#/")
    time.sleep(4)
    state = d.execute_script("return {header: sessionStorage.getItem('auth.header') !== null, loginVisible: !!document.querySelector('#login #username') || location.hash.includes('login')};")
    log("phase2-ui-after-401", state=state)
    login(USER, NEW_PASS); log("phase2-relogin-new-password", ok=True)
    r3 = open_explorer_and_send(); log("phase2-explorer-recovered", result=r3)
    log("phase3-create-guest", s1=api_post("/solr/admin/authentication", {"set-user": {"guest2": "GuestPass1"}}, USER, NEW_PASS),
        s2=api_post("/solr/admin/authorization", {"set-user-role": {"guest2": []}}, USER, NEW_PASS))
    d.execute_script("sessionStorage.clear();")
    try:
        login("guest2", "GuestPass1"); log("phase3-guest-login", ok=True)
        r4 = open_explorer_and_send(); log("phase3-guest-explorer", result=r4)
    except Exception as e:
        log("phase3-guest", error=type(e).__name__ + ": " + str(e)[:200])
except Exception as e:
    log("fatal", error=type(e).__name__ + ": " + str(e)[:300])
finally:
    json.dump(LOG, open("/home/hatch/workspace/tools/gate-5201-r3/drive-results.json", "w"), indent=1)
    d.quit()
