pr-5298-glob-prefetch-review-linux-20261120-r2 evidence
head 8a45fcf229db7eaca1e32cf1d7f46ac36a96adda
base 78404ec851c433a844152fbb55e6b7ca460615a4
seed 5298C0DE
host vm2 Linux JDK 21

heads.txt                     refs and worktree cleanliness before/after
failbefore-base-committed.log base + candidate test, committed iteration only ({true})
failbefore-base-uncommitted.log base + candidate test, uncommitted iteration only ({false})
passafter.log                 candidate both iterations
suites.log                    six suites
xml/                          JUnit XML for the six suites (archived before further cleanTest)
tidy.log                      ./gradlew tidy (exit 0, tree stayed clean)
tidy-tree-status.txt          git status after tidy (empty)
errorprone.log                ./gradlew :solr:core:compileJava :solr:core:compileTestJava -Pvalidation.errorprone=true (FAILED)
root-check.log                ./gradlew check -x test -Prefguide.include=false

Key finding: Error Prone fails the candidate at
  RealTimeGetComponent.java:356  if (docFetcher == null || searcher != fieldSelectionSearcher)
  warning: [ReferenceEquality], escalated by -Werror
The identifier fieldSelectionSearcher does not exist at the base, so the warning is introduced by this head.
The file already suppresses ReferenceEquality where identity is intentional (lines 662, 776).
