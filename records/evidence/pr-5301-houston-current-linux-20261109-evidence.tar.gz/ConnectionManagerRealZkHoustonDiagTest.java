/*
 * Licensed to the Apache Software Foundation (ASF) under one or more
 * contributor license agreements.  See the NOTICE file distributed with
 * this work for additional information regarding copyright ownership.
 * The ASF licenses this file to You under the Apache License, Version 2.0
 * (the "License"); you may not use this file except in compliance with
 * the License.  You may obtain a copy of the License at
 *
 *     http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
package org.apache.solr.cloud;

import java.io.IOException;
import java.net.URI;
import java.util.ArrayList;
import java.util.Collections;
import java.util.List;
import java.util.concurrent.CountDownLatch;
import java.util.concurrent.TimeUnit;
import java.util.concurrent.atomic.AtomicBoolean;
import java.util.concurrent.atomic.AtomicInteger;
import java.util.concurrent.atomic.AtomicReference;
import org.apache.logging.log4j.Level;
import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.core.LogEvent;
import org.apache.logging.log4j.core.LoggerContext;
import org.apache.logging.log4j.core.appender.AbstractAppender;
import org.apache.logging.log4j.core.config.Configuration;
import org.apache.logging.log4j.core.config.LoggerConfig;
import org.apache.logging.log4j.core.config.Property;
import org.apache.solr.SolrTestCase;
import org.apache.solr.client.solrj.cloud.SocketProxy;
import org.apache.solr.common.cloud.ConnectionManager;
import org.apache.solr.common.cloud.DefaultConnectionStrategy;
import org.apache.solr.common.cloud.SolrZkClient;
import org.apache.solr.common.util.SuppressForbidden;
import org.apache.solr.common.util.TimeSource;
import org.apache.solr.util.TimeOut;
import org.apache.zookeeper.Watcher;
import org.apache.zookeeper.ZooKeeper;
import org.junit.Test;

/**
 * Disposable diagnostic for PR 5301 at Houston head 684354d2. Records an ordered trace of real
 * ZooKeeper session events, keeper creations, installs, and reconnect callbacks. Diagnostic only;
 * never committed.
 */
@SuppressForbidden(reason = "needs a log4j appender to delay a connection callback")
public class ConnectionManagerRealZkHoustonDiagTest extends SolrTestCase {
  private static final int WAIT_SECONDS = 20;
  private static final List<String> TRACE = Collections.synchronizedList(new ArrayList<>());
  private static final long T0 = System.nanoTime();

  private static void trace(String what) {
    long ms = TimeUnit.NANOSECONDS.toMillis(System.nanoTime() - T0);
    String line = "DIAG t=" + ms + "ms " + what;
    TRACE.add(line);
    System.out.println(line);
  }

  @Test
  public void testScheduleObservations() throws Exception {
    TRACE.clear();
    ZkTestServer server = new ZkTestServer(createTempDir("zk-diag-schedule"));
    SocketProxy proxy = new SocketProxy();
    RecordingStrategy strategy = new RecordingStrategy(true);
    CallbackAppender appender = new CallbackAppender(proxy, true);
    LoggerContext context = (LoggerContext) LogManager.getContext(false);
    Configuration config = context.getConfiguration();
    String loggerName = ConnectionManager.class.getName();
    LoggerConfig logger = new LoggerConfig(loggerName, Level.DEBUG, true);
    boolean serverStarted = false;
    boolean proxyStarted = false;
    appender.start();
    logger.addAppender(appender, Level.DEBUG, null);
    config.addLogger(loggerName, logger);
    context.updateLoggers();
    try {
      server.run();
      serverStarted = true;
      proxy.open(new URI("http://127.0.0.1:" + server.getPort()));
      proxyStarted = true;
      AtomicInteger reconnectCallbacks = new AtomicInteger();
      CountDownLatch reconnected = new CountDownLatch(1);
      try (SolrZkClient client =
          new SolrZkClient.Builder()
              .withUrl("127.0.0.1:" + proxy.getListenPort())
              .withTimeout(20, TimeUnit.SECONDS)
              .withConnTimeOut(10, TimeUnit.SECONDS)
              .withConnStrategy(strategy)
              .withReconnectListener(
                  () -> {
                    int n = reconnectCallbacks.incrementAndGet();
                    trace("onReconnect invoked count=" + n);
                    reconnected.countDown();
                  })
              .build()) {
        try {
          ConnectionManager manager = client.getConnectionManager();
          long sessionA = client.getZooKeeper().getSessionId();
          trace("session A=" + Long.toHexString(sessionA) + " installed");
          appender.arm(manager.toString());
          server.expire(sessionA);
          trace("server.expire(A) issued");
          assertTrue(
              "replacement session was not created",
              strategy.replacementCreated.await(WAIT_SECONDS, TimeUnit.SECONDS));
          assertTrue(
              "replacement connected callback was not held",
              appender.connectedHeld.await(WAIT_SECONDS, TimeUnit.SECONDS));
          ZooKeeper replacement = strategy.replacement.get();
          assertTrue(
              "replacement must have a real connected session",
              replacement.getState().isConnected());
          long sessionB = replacement.getSessionId();
          trace("session B=" + Long.toHexString(sessionB) + " created; SyncConnected held");
          assertNotEquals(sessionA, sessionB);

          proxy.halfClose();
          assertTrue(
              "replacement disconnect was not delivered",
              strategy.replacementDisconnected.await(WAIT_SECONDS, TimeUnit.SECONDS));
          assertTrue(
              "replacement disconnect was not applied",
              appender.disconnected.await(WAIT_SECONDS, TimeUnit.SECONDS));
          assertFalse(manager.isConnected());
          trace("B Disconnected applied; manager.isConnected=false");
          server.expire(sessionB);
          trace("server.expire(B) issued");
          try (SolrZkClient control =
              new SolrZkClient.Builder()
                  .withUrl(server.getZkAddress())
                  .withTimeout(20, TimeUnit.SECONDS)
                  .withConnTimeOut(10, TimeUnit.SECONDS)
                  .build()) {
            assertTrue(control.getZooKeeper().getState().isConnected());
            trace("control client connected to real server while B expired");
          }
          proxy.goOn();
          assertTrue(
              "replacement expiry was not delivered",
              strategy.replacementExpired.await(WAIT_SECONDS, TimeUnit.SECONDS));
          new TimeOut(WAIT_SECONDS, TimeUnit.SECONDS, TimeSource.NANO_TIME)
              .waitFor("replacement was not terminal", () -> !replacement.getState().isAlive());
          trace("B Expired delivered and B terminal");

          boolean cRequestedBeforeRelease =
              strategy.thirdCreationRequested.await(10, TimeUnit.SECONDS);
          trace(
              "OBSERVE thirdKeeperCreationRequestedBeforeHeldCallbackRelease="
                  + cRequestedBeforeRelease);
          trace(
              "OBSERVE expiredPathEntriesBeforeRelease=" + appender.expiredPathEntries.get());
          appender.releaseConnected.countDown();
          trace("held B SyncConnected released");
          boolean staleRejected =
              appender.staleConnected.await(WAIT_SECONDS, TimeUnit.SECONDS);
          trace("OBSERVE staleConnectedRejected=" + staleRejected);
          assertFalse("connected callback hold timed out", appender.holdTimedOut.get());
          strategy.allowThirdCreation.countDown();
          boolean recovered = reconnected.await(WAIT_SECONDS, TimeUnit.SECONDS);
          trace("OBSERVE recovered=" + recovered);
          assertTrue("connection manager did not recover", recovered);
          long finalSession = client.getZooKeeper().getSessionId();
          trace(
              "OBSERVE finalInstalledSession="
                  + Long.toHexString(finalSession)
                  + " keeperCreations="
                  + strategy.attempts.get()
                  + " reconnectCallbacks="
                  + reconnectCallbacks.get()
                  + " expiredPathEntries="
                  + appender.expiredPathEntries.get()
                  + " managerConnected="
                  + manager.isConnected()
                  + " managerLikelyExpired="
                  + manager.isLikelyExpired()
                  + " clientKeeperState="
                  + client.getZooKeeper().getState());
          assertNotEquals(sessionB, finalSession);
          assertTrue(client.getZooKeeper().getState().isConnected());
          trace(
              "OBSERVE managerIsConnectedAndNotClosed=" + manager.isConnectedAndNotClosed());
          // Observation window for any extra keeper creation (a "D") after recovery.
          Thread.sleep(5000);
          trace(
              "OBSERVE keeperCreationsAfter5sWindow="
                  + strategy.attempts.get()
                  + " finalSessionStillInstalled="
                  + (client.getZooKeeper().getSessionId() == finalSession)
                  + " finalKeeperAlive="
                  + client.getZooKeeper().getState().isAlive()
                  + " managerConnectedAfterWindow="
                  + manager.isConnected()
                  + " managerLikelyExpiredAfterWindow="
                  + manager.isLikelyExpired());
        } finally {
          appender.releaseConnected.countDown();
          strategy.allowThirdCreation.countDown();
          proxy.goOn();
        }
      }
    } finally {
      appender.releaseConnected.countDown();
      strategy.allowThirdCreation.countDown();
      config.removeLogger(loggerName);
      context.updateLoggers();
      appender.stop();
      if (proxyStarted) {
        proxy.close();
      }
      if (serverStarted) {
        server.shutdown();
      }
    }
  }

  @Test
  public void testDisconnectedReplacementIsRetained() throws Exception {
    TRACE.clear();
    ZkTestServer server = new ZkTestServer(createTempDir("zk-diag-liveness"));
    SocketProxy proxy = new SocketProxy();
    RecordingStrategy strategy = new RecordingStrategy(false);
    boolean serverStarted = false;
    boolean proxyStarted = false;
    try {
      server.run();
      serverStarted = true;
      proxy.open(new URI("http://127.0.0.1:" + server.getPort()));
      proxyStarted = true;
      AtomicInteger reconnectCallbacks = new AtomicInteger();
      try (SolrZkClient client =
          new SolrZkClient.Builder()
              .withUrl("127.0.0.1:" + proxy.getListenPort())
              .withTimeout(20, TimeUnit.SECONDS)
              .withConnTimeOut(10, TimeUnit.SECONDS)
              .withConnStrategy(strategy)
              .withReconnectListener(reconnectCallbacks::incrementAndGet)
              .build()) {
        ConnectionManager manager = client.getConnectionManager();
        long sessionA = client.getZooKeeper().getSessionId();
        trace("liveness session A=" + Long.toHexString(sessionA));
        server.expire(sessionA);
        assertTrue(
            "replacement session was not created",
            strategy.replacementCreated.await(WAIT_SECONDS, TimeUnit.SECONDS));
        ZooKeeper replacement = strategy.replacement.get();
        new TimeOut(WAIT_SECONDS, TimeUnit.SECONDS, TimeSource.NANO_TIME)
            .waitFor("replacement did not connect", () -> replacement.getState().isConnected());
        new TimeOut(WAIT_SECONDS, TimeUnit.SECONDS, TimeSource.NANO_TIME)
            .waitFor("manager did not install replacement", manager::isConnected);
        long sessionB = replacement.getSessionId();
        trace(
            "liveness session B="
                + Long.toHexString(sessionB)
                + " installed session="
                + Long.toHexString(client.getZooKeeper().getSessionId()));
        assertEquals(sessionB, client.getZooKeeper().getSessionId());

        proxy.halfClose();
        assertTrue(
            "replacement disconnect was not delivered",
            strategy.replacementDisconnected.await(WAIT_SECONDS, TimeUnit.SECONDS));
        new TimeOut(WAIT_SECONDS, TimeUnit.SECONDS, TimeSource.NANO_TIME)
            .waitFor("manager did not apply disconnect", () -> !manager.isConnected());
        Thread.sleep(3000);
        trace(
            "OBSERVE duringDisconnect keeperCreations="
                + strategy.attempts.get()
                + " installedSession="
                + Long.toHexString(client.getZooKeeper().getSessionId())
                + " keeperIsB="
                + (client.getZooKeeper() == replacement)
                + " managerConnected="
                + manager.isConnected());
        assertEquals("no new keeper may be created while B is merely disconnected", 2, strategy.attempts.get());
        assertEquals(sessionB, client.getZooKeeper().getSessionId());

        proxy.goOn();
        new TimeOut(WAIT_SECONDS, TimeUnit.SECONDS, TimeSource.NANO_TIME)
            .waitFor("replacement did not reconnect", () -> replacement.getState().isConnected());
        new TimeOut(WAIT_SECONDS, TimeUnit.SECONDS, TimeSource.NANO_TIME)
            .waitFor("manager did not reconnect with B", manager::isConnected);
        trace(
            "OBSERVE afterReconnect keeperCreations="
                + strategy.attempts.get()
                + " installedSession="
                + Long.toHexString(client.getZooKeeper().getSessionId())
                + " sameSessionRetained="
                + (client.getZooKeeper().getSessionId() == sessionB)
                + " reconnectCallbacks="
                + reconnectCallbacks.get());
        assertEquals(2, strategy.attempts.get());
        assertEquals(sessionB, client.getZooKeeper().getSessionId());
        assertTrue(manager.isConnectedAndNotClosed());
      }
    } finally {
      if (proxyStarted) {
        proxy.close();
      }
      if (serverStarted) {
        server.shutdown();
      }
    }
  }

  private static class RecordingStrategy extends DefaultConnectionStrategy {
    private final boolean gateThird;
    private final AtomicInteger attempts = new AtomicInteger();
    private final AtomicReference<ZooKeeper> replacement = new AtomicReference<>();
    private final CountDownLatch replacementCreated = new CountDownLatch(1);
    private final CountDownLatch replacementDisconnected = new CountDownLatch(1);
    private final CountDownLatch replacementExpired = new CountDownLatch(1);
    private final CountDownLatch thirdCreationRequested = new CountDownLatch(1);
    private final CountDownLatch allowThirdCreation = new CountDownLatch(1);

    RecordingStrategy(boolean gateThird) {
      this.gateThird = gateThird;
    }

    @Override
    protected ZooKeeper newZooKeeperInstance(String address, int timeout, Watcher watcher)
        throws IOException {
      int attempt = attempts.incrementAndGet();
      trace("keeper creation requested attempt=" + attempt);
      if (attempt == 3 && gateThird) {
        thirdCreationRequested.countDown();
        try {
          if (!allowThirdCreation.await(30, TimeUnit.SECONDS)) {
            throw new IOException("timed out waiting to create the next session");
          }
        } catch (InterruptedException e) {
          Thread.currentThread().interrupt();
          throw new IOException(e);
        }
      }
      Watcher observingWatcher =
          event -> {
            trace(
                "watcher event attempt="
                    + attempt
                    + " state="
                    + event.getState()
                    + " type="
                    + event.getType());
            watcher.process(event);
            if (attempt == 2 && event.getState() == Watcher.Event.KeeperState.Disconnected) {
              replacementDisconnected.countDown();
            }
            if (attempt == 2 && event.getState() == Watcher.Event.KeeperState.Expired) {
              replacementExpired.countDown();
            }
          };
      ZooKeeper keeper = super.newZooKeeperInstance(address, timeout, observingWatcher);
      if (attempt == 2) {
        replacement.set(keeper);
        replacementCreated.countDown();
      }
      trace("keeper created attempt=" + attempt);
      return keeper;
    }
  }

  @SuppressForbidden(reason = "needs log4j2 classes to delay a logging call")
  private static class CallbackAppender extends AbstractAppender {
    private final SocketProxy proxy;
    private final boolean holdEnabled;
    private final AtomicBoolean paused = new AtomicBoolean();
    private final AtomicBoolean holdTimedOut = new AtomicBoolean();
    private final AtomicInteger expiredPathEntries = new AtomicInteger();
    private volatile String manager;
    private final CountDownLatch connectedHeld = new CountDownLatch(1);
    private final CountDownLatch releaseConnected = new CountDownLatch(1);
    private final CountDownLatch disconnected = new CountDownLatch(1);
    private final CountDownLatch staleConnected = new CountDownLatch(1);

    CallbackAppender(SocketProxy proxy, boolean holdEnabled) {
      super("houstonDiagCallback", null, null, true, Property.EMPTY_ARRAY);
      this.proxy = proxy;
      this.holdEnabled = holdEnabled;
    }

    void arm(String target) {
      manager = target;
    }

    @Override
    public void append(LogEvent event) {
      String message = event.getMessage().getFormattedMessage();
      if (message.contains("Our previous ZooKeeper session was expired")) {
        int n = expiredPathEntries.incrementAndGet();
        trace("expired path entered count=" + n);
      }
      if (manager == null) {
        return;
      }
      if (holdEnabled
          && message.startsWith("Watcher " + manager)
          && message.contains("state:SyncConnected")
          && connectedHeld.getCount() != 0) {
        connectedHeld.countDown();
        trace("holding SyncConnected callback in log appender");
        try {
          if (!releaseConnected.await(60, TimeUnit.SECONDS)) {
            holdTimedOut.set(true);
          }
        } catch (InterruptedException e) {
          Thread.currentThread().interrupt();
        }
        trace("SyncConnected callback released from hold");
      } else if (connectedHeld.getCount() == 0
          && message.startsWith("Watcher " + manager)
          && message.contains("state:Disconnected")
          && paused.compareAndSet(false, true)) {
        proxy.pause();
      } else if (connectedHeld.getCount() == 0 && message.equals("zkClient has disconnected")) {
        disconnected.countDown();
      } else if (message.startsWith("Ignoring stale connected event ")) {
        staleConnected.countDown();
        trace("stale connected event rejected");
      }
    }
  }
}
