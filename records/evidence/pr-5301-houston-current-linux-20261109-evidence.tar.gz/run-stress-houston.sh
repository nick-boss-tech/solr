#!/bin/bash
# PR 5301 houston-current gate: existing reconnect stress test, nightly. Phone agent.
set -u
CLONE=~/workspace/solr-clones/5301-diag
OUT=~/workspace/tools/gate-5301/runs
H=684354d21476e44458e45c83a810dd25d16ba284
exec 9>~/workspace/tools/.solr-test-queue.lock
flock 9
pkill -f 'Gradle[D]aemon' 2>/dev/null; sleep 2
rm -f ~/.gradle/caches/journal-1/journal-1.lock
cd "$CLONE" || exit 2
[ "$(git rev-parse HEAD)" = "$H" ] || { echo "HEAD MISMATCH" > "$OUT/stress.ABORT"; exit 3; }
echo "RUN stress START $(date -u +%FT%TZ)" > "$OUT/stress.log"
~/workspace/tools/solr-gradle8.sh :solr:core:cleanTest :solr:core:test --tests org.apache.solr.cloud.TestConnectionManagerReconnectStress -Ptests.nightly=true -Ptests.seed=5301C0DE --rerun-tasks --console=plain >> "$OUT/stress.log" 2>&1 9>&-
echo "stress rc=$?" >> "$OUT/stress.log"
mkdir -p "$OUT/xml-stress"
find "$CLONE/solr/core/build/test-results/test" -name 'TEST-*.xml' -exec cp {} "$OUT/xml-stress/" \; 2>/dev/null
echo "RUN stress END $(date -u +%FT%TZ)" >> "$OUT/stress.log"
