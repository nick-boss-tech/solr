#!/bin/bash
# PR 5301 stale-expiry gate: discrimination control (guarded ConnectionManager overlay). Phone agent.
set -u
CLONE=~/workspace/solr-clones/5301-stale-control
OUT=~/workspace/tools/gate-5301-stale/runs
exec 9>~/workspace/tools/.solr-test-queue.lock
flock 9
pkill -f 'Gradle[D]aemon' 2>/dev/null; sleep 2
rm -f ~/.gradle/caches/journal-1/journal-1.lock
cd "$CLONE" || exit 2
{
  echo "CONTROL START $(date -u +%FT%TZ)"
  echo "HEAD=$(git rev-parse HEAD)"
  git diff --stat
  echo "CM blob now: $(git hash-object solr/solrj-zookeeper/src/java/org/apache/solr/common/cloud/ConnectionManager.java)"
  echo "test sha256: $(sha256sum solr/core/src/test/org/apache/solr/cloud/ConnectionManagerStaleExpiryTest.java | cut -d' ' -f1)"
} > "$OUT/control.log"
~/workspace/tools/solr-gradle8.sh --no-daemon :solr:core:cleanTest :solr:core:test --tests org.apache.solr.cloud.ConnectionManagerStaleExpiryTest.testStaleExpiryDoesNotReplaceRecoveredSession -Ptests.seed=5301C0DE --rerun-tasks >> "$OUT/control.log" 2>&1 9>&-
echo "control test rc=$?" >> "$OUT/control.log"
cp solr/core/build/test-results/test/TEST-org.apache.solr.cloud.ConnectionManagerStaleExpiryTest.xml "$OUT/TEST-control.xml" 2>/dev/null || echo "NO CONTROL TEST XML" >> "$OUT/control.log"
echo "CONTROL END $(date -u +%FT%TZ)" >> "$OUT/control.log"
