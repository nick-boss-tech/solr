#!/bin/bash
# PR 5301 stale-expiry test gate: tidy, diff check, root check, focused test (expected failure). Phone agent.
set -u
CLONE=~/workspace/solr-clones/5301-stale
OUT=~/workspace/tools/gate-5301-stale/runs
H=b5477834e588888c542409bebbe2d1b76bbade27
PARENT=684354d21476e44458e45c83a810dd25d16ba284
exec 9>~/workspace/tools/.solr-test-queue.lock
flock 9
pkill -f 'Gradle[D]aemon' 2>/dev/null; sleep 2
rm -f ~/.gradle/caches/journal-1/journal-1.lock
cd "$CLONE" || exit 2
{
  echo "HEAD=$(git rev-parse HEAD)"
  [ "$(git rev-parse HEAD)" = "$H" ] || echo "HEAD MISMATCH"
  echo "STATUS_BEFORE=$(git status --porcelain | grep -v '^?? gradle.properties' | wc -l)"
  echo "LEG tidy START $(date -u +%FT%TZ)"
} > "$OUT/main.log"
~/workspace/tools/solr-gradle8.sh --no-daemon tidy >> "$OUT/main.log" 2>&1 9>&-
echo "tidy rc=$?" >> "$OUT/main.log"
CHANGES=$(git status --porcelain | grep -v '^?? gradle.properties' | wc -l)
echo "TRACKED_CHANGES_AFTER_TIDY=$CHANGES" >> "$OUT/main.log"
git diff --check $PARENT..$H >> "$OUT/main.log" 2>&1
echo "diff-check rc=$?" >> "$OUT/main.log"
if [ "$CHANGES" != "0" ]; then
  echo "ABORT: tidy changed tracked files; stopping per gate" >> "$OUT/main.log"
  exit 0
fi
echo "LEG check START $(date -u +%FT%TZ)" >> "$OUT/main.log"
JAVA_TOOL_OPTIONS="-Djava.net.preferIPv4Stack=true -Djavax.net.ssl.trustStore=$HOME/workspace/tools/truststore-with-hatch-ca.jks" ~/workspace/tools/solr-gradle8.sh --no-daemon check -x test >> "$OUT/main.log" 2>&1 9>&-
echo "check rc=$?" >> "$OUT/main.log"
echo "LEG test START $(date -u +%FT%TZ)" >> "$OUT/main.log"
~/workspace/tools/solr-gradle8.sh --no-daemon :solr:core:cleanTest :solr:core:test --tests org.apache.solr.cloud.ConnectionManagerStaleExpiryTest.testStaleExpiryDoesNotReplaceRecoveredSession -Ptests.seed=5301C0DE --rerun-tasks >> "$OUT/main.log" 2>&1 9>&-
echo "test rc=$?" >> "$OUT/main.log"
cp solr/core/build/test-results/test/TEST-org.apache.solr.cloud.ConnectionManagerStaleExpiryTest.xml "$OUT/" 2>/dev/null || echo "NO TEST XML" >> "$OUT/main.log"
echo "MAIN END $(date -u +%FT%TZ)" >> "$OUT/main.log"
