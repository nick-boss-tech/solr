#!/bin/bash
# PR 5311 root-diagnosis successor: full unexcluded root check at the exact head. Phone agent.
set -u
CLONE=~/workspace/solr-clones/5311-diag
OUT=~/workspace/tools/gate-5311-diag/runs
H=b8f10c9e3ea04746ee5f823e57fd9484426b448d
exec 9>~/workspace/tools/.solr-test-queue.lock
flock 9
pkill -f 'Gradle[D]aemon' 2>/dev/null; sleep 2
rm -f ~/.gradle/caches/journal-1/journal-1.lock
cd "$CLONE" || exit 2
{
  echo "HEAD=$(git rev-parse HEAD)"
  echo "STATUS_BEFORE=$(git status --porcelain | grep -v '^?? gradle.properties' | wc -l)"
  echo "CHECK START $(date -u +%FT%TZ)"
} > "$OUT/check.log"
git diff --check >> "$OUT/check.log" 2>&1
echo "diff-check rc=$?" >> "$OUT/check.log"
JAVA_TOOL_OPTIONS="-Djava.net.preferIPv4Stack=true -Djavax.net.ssl.trustStore=$HOME/workspace/tools/truststore-with-hatch-ca.jks" ~/workspace/tools/solr-gradle.sh --no-daemon check -x test >> "$OUT/check.log" 2>&1 9>&-
echo "check rc=$?" >> "$OUT/check.log"
{
  echo "validateSourcePatterns ran: $(grep -c 'validateSourcePatterns' "$OUT/check.log")"
  echo "TRACKED_CHANGES_AFTER=$(git status --porcelain | grep -v '^?? gradle.properties' | wc -l)"
  echo "HEAD_AFTER=$(git rev-parse HEAD)"
  echo "CHECK END $(date -u +%FT%TZ)"
} >> "$OUT/check.log"
