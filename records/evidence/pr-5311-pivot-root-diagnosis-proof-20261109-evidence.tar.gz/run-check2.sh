#!/bin/bash
# PR 5311: second full check with ref-guide outputs removed so Antora re-executes inside the check. Phone agent.
set -u
CLONE=~/workspace/solr-clones/5311-diag
OUT=~/workspace/tools/gate-5311-diag/runs
exec 9>~/workspace/tools/.solr-test-queue.lock
flock 9
pkill -f 'Gradle[D]aemon' 2>/dev/null; sleep 2
rm -f ~/.gradle/caches/journal-1/journal-1.lock
cd "$CLONE" || exit 2
rm -rf solr/solr-ref-guide/build
{
  echo "HEAD=$(git rev-parse HEAD)"
  echo "CHECK2 START $(date -u +%FT%TZ)"
} > "$OUT/check2.log"
JAVA_TOOL_OPTIONS="-Djava.net.preferIPv4Stack=true -Djavax.net.ssl.trustStore=$HOME/workspace/tools/truststore-with-hatch-ca.jks" ~/workspace/tools/solr-gradle.sh --no-daemon check -x test >> "$OUT/check2.log" 2>&1 9>&-
echo "check2 rc=$?" >> "$OUT/check2.log"
{
  echo "TRACKED_CHANGES_AFTER=$(git status --porcelain | grep -v '^?? gradle.properties' | wc -l)"
  echo "CHECK2 END $(date -u +%FT%TZ)"
} >> "$OUT/check2.log"
