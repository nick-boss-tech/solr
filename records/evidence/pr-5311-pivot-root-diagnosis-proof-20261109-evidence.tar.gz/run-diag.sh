#!/bin/bash
# PR 5311 root-diagnosis: reproduce the Antora leg failure in a clean normal clone. Phone agent.
set -u
CLONE=~/workspace/solr-clones/5311-diag
OUT=~/workspace/tools/gate-5311-diag/runs
H=b8f10c9e3ea04746ee5f823e57fd9484426b448d
exec 9>~/workspace/tools/.solr-test-queue.lock
flock 9
pkill -f 'Gradle[D]aemon' 2>/dev/null; sleep 2
rm -f ~/.gradle/caches/journal-1/journal-1.lock
rm -rf "$CLONE"
git clone -q ~/workspace/solr "$CLONE" || exit 2
cd "$CLONE" || exit 2
git fetch -q https://github.com/nick-boss-tech/solr.git refs/heads/pr-5311-pivot-duplicate-keys || exit 2
git checkout -q "$H" || exit 2
cp ~/workspace/solr/gradle.properties .
{
  echo "HEAD=$(git rev-parse HEAD)"
  echo ".git is: $(if [ -d .git ]; then echo directory; else echo FILE; fi)"
  echo "NODE_ENV=${NODE_ENV-<unset>}"
  echo "node on PATH: $(command -v node || echo none)"
  echo "DIAG START $(date -u +%FT%TZ)"
} > "$OUT/diag.log"
~/workspace/tools/solr-gradle.sh --no-daemon :solr:solr-ref-guide:buildLocalAntoraSite --info >> "$OUT/diag.log" 2>&1 9>&-
echo "diag antora rc=$?" >> "$OUT/diag.log"
echo "DIAG END $(date -u +%FT%TZ)" >> "$OUT/diag.log"
