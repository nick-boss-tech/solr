#!/bin/bash
# PR 5312 czxid gate r2: fail-before at contributor head with offered test file overlaid. Phone agent.
set -u
CLONE=~/workspace/solr-clones/5312-r2-fb
OUT=~/workspace/tools/gate-5312-r2/runs
H=1d71a1b3811b1e9c7fe9bcac7ade1c8bc695ecb0
CONTRIB=0848e85fad1290ed604f881abb265b060be3075f
TESTPATH=solr/core/src/test/org/apache/solr/util/MultipleManagedSchemasTest.java
exec 9>~/workspace/tools/.solr-test-queue.lock
flock 9
pkill -f 'Gradle[D]aemon' 2>/dev/null; sleep 2
rm -f ~/.gradle/caches/journal-1/journal-1.lock
rm -rf "$CLONE"
git clone -q ~/workspace/solr "$CLONE" || exit 2
cd "$CLONE" || exit 2
git fetch -q https://github.com/apache/solr.git refs/pull/5312/head || exit 2
git fetch -q https://github.com/nick-boss-tech/solr.git refs/heads/solr-18632-submit || exit 2
git checkout -q "$CONTRIB" || exit 2
cp ~/workspace/solr/gradle.properties .
{
  echo "HEAD=$(git rev-parse HEAD)"
  echo "offered test blob: $(git rev-parse $H:$TESTPATH)"
} > "$OUT/failbefore.log"
git show "$H:$TESTPATH" > "$TESTPATH"
{
  echo "overlay blob now: $(git hash-object $TESTPATH)"
  echo "overlay sha256: $(sha256sum $TESTPATH | cut -d' ' -f1)"
  echo "changed paths vs contributor head:"
  git status --porcelain | grep -v '^?? gradle.properties'
  echo "FB SETUP END $(date -u +%FT%TZ)"
} >> "$OUT/failbefore.log"
echo "LEG fail-before START $(date -u +%FT%TZ)" >> "$OUT/failbefore.log"
~/workspace/tools/solr-gradle.sh --no-daemon :solr:core:cleanTest :solr:core:test --tests org.apache.solr.util.MultipleManagedSchemasTest.testCacheDistinguishesRecreatedZnodesWithSameCreationTime -Ptests.seed=18632CAFE >> "$OUT/failbefore.log" 2>&1 9>&-
echo "fb rc=$?" >> "$OUT/failbefore.log"
cp solr/core/build/test-results/test/TEST-org.apache.solr.util.MultipleManagedSchemasTest.xml "$OUT/TEST-failbefore.xml" 2>/dev/null || echo "NO FB XML" >> "$OUT/failbefore.log"
echo "FB END $(date -u +%FT%TZ)" >> "$OUT/failbefore.log"
