#!/bin/bash
# PR 5312 czxid gate r2: positive legs at offered head 1d71a1b3. Phone agent.
set -u
CLONE=~/workspace/solr-clones/5312-r2
OUT=~/workspace/tools/gate-5312-r2/runs
H=1d71a1b3811b1e9c7fe9bcac7ade1c8bc695ecb0
TREE=87a0373bcb7bcef89bf98b094339886a5f7971f8
PARENT=9b96f1a23c2b9609c51c46541bf7fe3299921e81
CONTRIB=0848e85fad1290ed604f881abb265b060be3075f
exec 9>~/workspace/tools/.solr-test-queue.lock
flock 9
pkill -f 'Gradle[D]aemon' 2>/dev/null; sleep 2
rm -f ~/.gradle/caches/journal-1/journal-1.lock
rm -rf "$CLONE"
git clone -q ~/workspace/solr "$CLONE" || exit 2
cd "$CLONE" || exit 2
git fetch -q https://github.com/nick-boss-tech/solr.git refs/heads/solr-18632-submit || exit 2
git checkout -q "$H" || exit 2
cp ~/workspace/solr/gradle.properties .
{
  echo "HEAD=$(git rev-parse HEAD)"
  echo "TREE=$(git rev-parse HEAD^{tree})"
  echo "PARENT=$(git rev-parse HEAD^)"
  git merge-base --is-ancestor "$CONTRIB" HEAD; echo "contributor ancestor rc=$?"
  echo ".git is: $(if [ -d .git ]; then echo directory; else echo FILE; fi)"
  echo "STATUS_BEFORE=$(git status --porcelain | grep -v '^?? gradle.properties' | wc -l)"
  echo "--- diff parent..HEAD ---"
  git diff --stat "$PARENT".."$H"
  echo "--- diff contributor..HEAD (stat) ---"
  git diff --stat "$CONTRIB".."$H" | tail -8
  echo "SETUP END $(date -u +%FT%TZ)"
} > "$OUT/positive.log"
echo "LEG tidy START $(date -u +%FT%TZ)" >> "$OUT/positive.log"
~/workspace/tools/solr-gradle.sh --no-daemon tidy >> "$OUT/positive.log" 2>&1 9>&-
echo "tidy rc=$?" >> "$OUT/positive.log"
CHANGES=$(git status --porcelain | grep -v '^?? gradle.properties' | wc -l)
echo "TRACKED_CHANGES_AFTER_TIDY=$CHANGES" >> "$OUT/positive.log"
git diff --check >> "$OUT/positive.log" 2>&1
echo "diff-check rc=$?" >> "$OUT/positive.log"
if [ "$CHANGES" != "0" ]; then echo "ABORT tidy changed tracked files" >> "$OUT/positive.log"; exit 0; fi
echo "LEG mms START $(date -u +%FT%TZ)" >> "$OUT/positive.log"
~/workspace/tools/solr-gradle.sh --no-daemon :solr:core:cleanTest :solr:core:test --tests org.apache.solr.util.MultipleManagedSchemasTest -Ptests.seed=18632CAFE >> "$OUT/positive.log" 2>&1 9>&-
echo "mms rc=$?" >> "$OUT/positive.log"
cp solr/core/build/test-results/test/TEST-org.apache.solr.util.MultipleManagedSchemasTest.xml "$OUT/TEST-mms.xml" 2>/dev/null || echo "NO MMS XML" >> "$OUT/positive.log"
echo "LEG tca START $(date -u +%FT%TZ)" >> "$OUT/positive.log"
~/workspace/tools/solr-gradle.sh --no-daemon :solr:core:cleanTest :solr:core:test --tests org.apache.solr.cloud.api.collections.TestCollectionAPI.testConfigCaching -Ptests.seed=18632CAFE >> "$OUT/positive.log" 2>&1 9>&-
echo "tca rc=$?" >> "$OUT/positive.log"
cp solr/core/build/test-results/test/TEST-org.apache.solr.cloud.api.collections.TestCollectionAPI.xml "$OUT/TEST-tca.xml" 2>/dev/null || echo "NO TCA XML" >> "$OUT/positive.log"
echo "LEG check START $(date -u +%FT%TZ)" >> "$OUT/positive.log"
JAVA_TOOL_OPTIONS="-Djava.net.preferIPv4Stack=true -Djavax.net.ssl.trustStore=$HOME/workspace/tools/truststore-with-hatch-ca.jks" ~/workspace/tools/solr-gradle.sh --no-daemon check -x test >> "$OUT/positive.log" 2>&1 9>&-
echo "check rc=$?" >> "$OUT/positive.log"
{
  echo "validateSourcePatterns executions: $(grep -c '> Task :solr:core:validateSourcePatterns' "$OUT/positive.log")"
  echo "TRACKED_CHANGES_AFTER=$(git status --porcelain | grep -v '^?? gradle.properties' | wc -l)"
  echo "HEAD_AFTER=$(git rev-parse HEAD)"
  echo "POSITIVE END $(date -u +%FT%TZ)"
} >> "$OUT/positive.log"
