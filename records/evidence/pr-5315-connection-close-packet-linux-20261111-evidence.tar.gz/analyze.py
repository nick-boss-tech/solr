#!/usr/bin/env python3
import re, sys, glob

path = sys.argv[1]
line_re = re.compile(r'^(\d+) (\d\d:\d\d:\d\d\.\d+) (\w+)\((.*)\) = (.+)$')
fd_re = re.compile(r'^(\d+)<TCP:\[(\d+)\]>')

conns = {}   # (pid, fd) -> dict
listen_ports = set()
events = []
with open(path, errors='replace') as f:
    for ln, line in enumerate(f):
        m = line_re.match(line.rstrip('\n'))
        if not m:
            continue
        pid, ts, sc, args, res = int(m.group(1)), m.group(2), m.group(3), m.group(4), m.group(5)
        events.append((ts, pid, sc, args, res))
        if sc in ('connect', 'accept', 'accept4'):
            fm = fd_re.match(args.split(',')[0]) if sc == 'connect' else None
            pm = re.search(r'sin_port=htons\((\d+)\)', args)
            if sc in ('accept', 'accept4') and res.strip().split(' ')[0].isdigit():
                newfd = int(res.strip().split(' ')[0])
                am = re.search(r'sin_port=htons\((\d+)\)', args)
                conns[(pid, newfd)] = {'kind': 'accepted', 'peer_port': am.group(1) if am else '?', 't0': ts}
            if sc == 'connect' and fm and pm:
                conns[(pid, int(fm.group(1)))] = {'kind': 'client', 'dst_port': pm.group(1), 'inode': fm.group(2), 't0': ts}

fixture_ports = set()
for (pid, fd), c in conns.items():
    if c.get('kind') == 'accepted':
        fixture_ports.add(c.get('peer_port'))
client_conns = {k: v for k, v in conns.items() if v.get('kind') == 'client'}
print('accepted-side conns:', sum(1 for v in conns.values() if v.get('kind')=='accepted'))
print('client conns by dst port:', {})
from collections import Counter
print(Counter(v.get('dst_port') for v in client_conns.values()))

# Timeline per client connection: all events for its (pid, fd)
byfd = {}
for ts, pid, sc, args, res in events:
    fm = fd_re.match(args.split(',')[0]) if args else None
    if fm:
        key = (pid, int(fm.group(1)))
        if key in client_conns:
            byfd.setdefault(key, []).append((ts, sc, args, res))

for key, c in sorted(client_conns.items(), key=lambda kv: kv[1]['t0']):
    evs = byfd.get(key, [])
    sends = [e for e in evs if e[1] in ('sendto', 'sendmsg', 'write', 'writev')]
    text = ' '.join(a for _, _, a, _ in sends)
    tags = []
    if 'HEAD ' in text: tags.append('HEAD')
    if 'POST ' in text: tags.append('POST')
    if 'GET ' in text: tags.append('GET')
    errs = [e for e in evs if ' = -1 ' in e[3] or e[3].strip() == '0' and e[1].startswith('recv')]
    if tags:
        print(f"\n### conn pid={key[0]} fd={key[1]} dst={c.get('dst_port')} t0={c['t0']} tags={tags} events={len(evs)}")
        for ts, sc, a, r in evs:
            short = a[:150]
            print(f"  {ts} {sc}({short}) = {r[:60]}")
