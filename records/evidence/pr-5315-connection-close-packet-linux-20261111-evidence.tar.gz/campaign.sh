#!/bin/bash
# Block runner v2: MODE=strace|plain, N=max runs, STOPFAIL=failures to stop at, TAG=run dir prefix
set -u
MODE=${MODE:-strace}; N=${N:-6}; STOPFAIL=${STOPFAIL:-2}; TAG=${TAG:-$MODE}
T=~/workspace/tools/5315-packet
C=~/workspace/solr-clones/5315-packet
SUM=$T/runs/campaign-summary.txt
touch $SUM
fails=0
for i in $(seq 1 $N); do
  RD=$T/runs/$TAG-run$i
  mkdir -p $RD
  echo "=== $TAG run$i start $(date -Is)" | tee -a $SUM
  cd $C
  {
    flock 9
    pkill -f "Gradle[Daemon]" 2>/dev/null; sleep 1; rm -f ~/.gradle/caches/journal-1/journal-1.lock
    rm -rf solr/solrj/build/test-results/test solr/solrj/build/reports/tests/test
    if [ "$MODE" = strace ]; then
      timeout 1500 strace -f -tt -yy -s 220 -e trace=${TRACE_SET:-%network,close,shutdown,setsockopt} -o $RD/trace.txt \
        ~/workspace/tools/solr-gradle.sh --no-daemon :solr:solrj:test --tests "org.apache.solr.client.solrj.impl.ProbeGracefulRejectionClientTest" -Ptests.seed=17764C0DE --console=plain 9>&- >> $RD/gradle.log 2>&1
    else
      timeout 1500 ~/workspace/tools/solr-gradle.sh --no-daemon :solr:solrj:test --tests "org.apache.solr.client.solrj.impl.ProbeGracefulRejectionClientTest" -Ptests.seed=17764C0DE --console=plain 9>&- >> $RD/gradle.log 2>&1
    fi
    echo "gradle rc=$?" >> $RD/gradle.log
  } 9>~/workspace/tools/.solr-test-queue.lock
  cp solr/solrj/build/test-results/test/TEST-org.apache.solr.client.solrj.impl.ProbeGracefulRejectionClientTest.xml $RD/test.xml 2>/dev/null || echo "NO XML" >> $SUM
  python3 - $RD >> $SUM 2>&1 <<'PYEOF'
import sys
import xml.etree.ElementTree as ET
rd = sys.argv[1]
try:
    t = ET.parse(rd + '/test.xml').getroot()
    fails = []
    order = []
    for tc in t.iter('testcase'):
        order.append(tc.get('name'))
        for bad in list(tc):
            if bad.tag in ('failure', 'error'):
                fails.append((tc.get('name'), (bad.get('message') or '')[:160]))
    print(f"tests={t.get('tests')} failures={t.get('failures')} errors={t.get('errors')} skipped={t.get('skipped')}")
    print("order:", ",".join(order))
    for n, m in fails:
        print("FAILED:", n, "|", m)
    with open(rd + '/verdict.txt', 'w') as f:
        f.write('FAIL' if fails else 'PASS')
except Exception as e:
    print('parse error', e)
PYEOF
  v=$(cat $RD/verdict.txt 2>/dev/null || echo '?')
  echo "=== $TAG run$i verdict=$v $(date -Is)" | tee -a $SUM
  if [ "$v" = FAIL ]; then fails=$((fails+1)); fi
  if [ $fails -ge $STOPFAIL ]; then echo "stop: $fails failures captured" | tee -a $SUM; break; fi
done
echo "BLOCK DONE tag=$TAG captured_failures=$fails" | tee -a $SUM
