#!/usr/bin/env python3
import re, sys
path = sys.argv[1]
line_re = re.compile(r'^(\d+)\s+(\d\d:\d\d:\d\d\.\d+) (\w+)\((.*)\) = (.+)$')
resumed_re = re.compile(r'^(\d+)\s+(\d\d:\d\d:\d\d\.\d+) <\.\.\. (\w+) resumed>(.*)\) = (.+)$')
fd_re = re.compile(r'^(\d+)<TCP:\[(\d+)\]>')

conns = {}   # (fd, inode) -> list of events + meta
def ev(key, ts, tid, sc, args, res):
    conns.setdefault(key, {'events': [], 'meta': ''})
    conns[key]['events'].append((ts, tid, sc, args, res))

with open(path, errors='replace') as f:
    for line in f:
        m = line_re.match(line.rstrip('\n')) or resumed_re.match(line.rstrip('\n'))
        if not m:
            continue
        tid, ts, sc, args, res = int(m.group(1)), m.group(2), m.group(3), m.group(4), m.group(5)
        fm = fd_re.match(args.split(',')[0]) if args else None
        if sc == 'connect' and fm:
            pm = re.search(r'sin_port=htons\((\d+)\)', args)
            key = (int(fm.group(1)), fm.group(2))
            ev(key, ts, tid, sc, args, res)
            conns[key]['meta'] = f"CLIENT -> port {pm.group(1) if pm else '?'}"
        elif sc in ('accept', 'accept4'):
            rm = re.match(r'(\d+)<TCP:\[(\d+)\]>', res)
            pm = re.search(r'sin_port=htons\((\d+)\)', args)
            if rm:
                key = (int(rm.group(1)), rm.group(2))
                ev(key, ts, tid, sc, args, res)
                conns[key]['meta'] = f"SERVER <- client ephemeral {pm.group(1) if pm else '?'}"
        elif fm and sc in ('read', 'write', 'readv', 'writev', 'sendto', 'recvfrom', 'sendmsg', 'recvmsg', 'shutdown', 'close'):
            key = (int(fm.group(1)), fm.group(2))
            if key in conns:
                ev(key, ts, tid, sc, args, res)

# score connections: writes with POST; reads with HTTP/; terminal reads 0/-1
for key, c in sorted(conns.items(), key=lambda kv: kv[1]['events'][0][0] if kv[1]['events'] else ''):
    posts = [e for e in c['events'] if e[2] in ('write','writev','sendto','sendmsg') and 'POST ' in e[3]]
    heads = [e for e in c['events'] if e[2] in ('write','writev','sendto','sendmsg') and 'HEAD ' in e[3]]
    resps = [e for e in c['events'] if e[2] in ('read','readv','recvfrom','recvmsg') and 'HTTP/' in e[3]]
    sreads = [e for e in c['events'] if e[2] in ('read','readv','recvfrom','recvmsg') and ('POST ' in e[3] or 'HEAD ' in e[3] or 'HTTP/' in e[3])]
    if c['meta'].startswith('CLIENT') and (posts or heads):
        print(f"\n===== {c['meta']} fd={key[0]} inode={key[1]} posts={len(posts)} heads={len(heads)} http_reads={len(resps)}")
        for ts, tid, sc, a, r in c['events']:
            print(f"  {ts} tid={tid} {sc}({a[:130]}) = {r[:40]}")
    if c['meta'].startswith('SERVER') and sreads:
        print(f"\n===== {c['meta']} fd={key[0]} inode={key[1]} http_events={len(sreads)}")
        for ts, tid, sc, a, r in c['events']:
            print(f"  {ts} tid={tid} {sc}({a[:130]}) = {r[:40]}")
