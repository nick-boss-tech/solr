#!/usr/bin/env python3
import re, sys
path = sys.argv[1]
line_re = re.compile(r'^(\d+)\s+(\d\d:\d\d:\d\d\.\d+) (\w+)\((.*)\) = (.+)$')
resumed_re = re.compile(r'^(\d+)\s+(\d\d:\d\d:\d\d\.\d+) <\.\.\. (\w+) resumed>(.*)\) = (.+)$')
fd_re = re.compile(r'^(\d+)<TCP:\[(\d+)\]>')
conns = {}
order = []
def key_of(fd, inode):
    k = (fd, inode)
    if k not in conns:
        conns[k] = {'events': [], 'meta': ''}
        order.append(k)
    return k
with open(path, errors='replace') as f:
    for line in f:
        m = line_re.match(line.rstrip('\n')) or resumed_re.match(line.rstrip('\n'))
        if not m:
            continue
        tid, ts, sc, args, res = int(m.group(1)), m.group(2), m.group(3), m.group(4), m.group(5)
        fm = fd_re.match(args.split(',')[0]) if args else None
        if sc == 'connect' and fm:
            pm = re.search(r'sin_port=htons\((\d+)\)', args)
            k = key_of(int(fm.group(1)), fm.group(2))
            conns[k]['meta'] = f"CLIENT->{pm.group(1) if pm else '?'}"
            conns[k]['events'].append((ts, tid, sc, args, res))
        elif sc in ('accept', 'accept4'):
            rm = re.match(r'(\d+)<TCP:\[(\d+)\]>', res)
            pm = re.search(r'sin_port=htons\((\d+)\)', args)
            if rm:
                k = key_of(int(rm.group(1)), rm.group(2))
                conns[k]['meta'] = f"SERVER<-eph{pm.group(1) if pm else '?'}"
                conns[k]['events'].append((ts, tid, sc, args, res))
        elif fm and sc in ('read','write','readv','writev','sendto','recvfrom','sendmsg','recvmsg','shutdown','close','getsockname'):
            k = (int(fm.group(1)), fm.group(2))
            if k in conns:
                conns[k]['events'].append((ts, tid, sc, args, res))

jdk = [k for k in order if conns[k]['meta'].startswith('CLIENT') and any('h2c' in e[3] or 'HTTP2-Settings' in e[3] for e in conns[k]['events'])]
print(f"JDK client connections: {len(jdk)}")
for k in jdk:
    c = conns[k]
    print(f"\n===== {c['meta']} fd={k[0]} inode={k[1]}")
    for ts, tid, sc, a, r in c['events']:
        if sc in ('read','readv','recvfrom','recvmsg') and r.startswith('-1 EAGAIN'):
            continue
        tag = ''
        if 'HEAD ' in a: tag = ' <<< HEAD req'
        if 'POST ' in a: tag = ' <<< POST req'
        if 'HTTP/1.1 ' in a and sc.startswith(('read','recv')): tag = ' <<< RESPONSE read'
        if r.strip() == '0' and sc.startswith(('read','recv')): tag = ' <<< EOF read'
        if 'ECONNRESET' in r or 'EPIPE' in r: tag = ' <<< ERROR'
        print(f"  {ts} tid={tid} {sc}({a[:110]}) = {r[:36]}{tag}")
