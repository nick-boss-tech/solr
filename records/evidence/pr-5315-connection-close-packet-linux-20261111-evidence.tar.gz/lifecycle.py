#!/usr/bin/env python3
import re, sys
path, t_from, t_to = sys.argv[1], sys.argv[2], sys.argv[3]
line_re = re.compile(r'^(\d+) (\d\d:\d\d:\d\d\.\d+) (\S+?)\((.*)\) = (.+)$')
resumed_re = re.compile(r'^(\d+) (\d\d:\d\d:\d\d\.\d+) <\.\.\. (\w+) resumed>(.*)\) = (.+)$')
fd_re = re.compile(r'^(\d+)<TCP:\[(\d+)\]>')
infra = {'3129', '53'}
connects = []   # (ts, tid, fd, dst)
accepts = {}    # client ephemeral port -> (ts, tid, newfd)
names = {}      # (tid-agnostic) fd -> local/peer ephemeral via getsockname/getpeername seen in window
evs = []
with open(path, errors='replace') as f:
    for line in f:
        m = line_re.match(line.rstrip('\n')) or resumed_re.match(line.rstrip('\n'))
        if not m:
            continue
        tid, ts, sc, args, res = int(m.group(1)), m.group(2), m.group(3), m.group(4), m.group(5)
        if not (t_from <= ts <= t_to):
            continue
        evs.append((ts, tid, sc, args, res))
        if sc == 'connect':
            fm = fd_re.match(args.split(',')[0]); pm = re.search(r'sin_port=htons\((\d+)\)', args)
            if fm and pm and pm.group(1) not in infra:
                connects.append((ts, tid, int(fm.group(1)), pm.group(1)))
        if sc in ('accept', 'accept4'):
            pm = re.search(r'sin_port=htons\((\d+)\)', args)
            rm = re.match(r'(\d+)<', res)
            if pm and rm:
                accepts[pm.group(1)] = (ts, tid, int(rm.group(1)))
        if sc == 'getsockname':
            fm = fd_re.match(args.split(',')[0]); pm = re.search(r'sin_port=htons\((\d+)\)', args)
            if fm and pm:
                names[int(fm.group(1))] = pm.group(1)
print("fixture connects in window:")
for ts, tid, fd, dst in connects:
    print(f"  {ts} tid={tid} clientfd={fd} -> server port {dst}; client local port {names.get(fd)}")
print("\naccepts (by client ephemeral port):")
for eph, (ts, tid, fd) in sorted(accepts.items()):
    print(f"  {ts} tid={tid} serverfd={fd} peer ephemeral {eph}")
# close/shutdown events for all fds involved
fds = set()
for _, _, fd, _ in connects: fds.add(fd)
for _, (_, _, fd) in [(k, v) for k, v in accepts.items()]: fds.add(fd)
print("\nclose/shutdown timeline for involved fds:")
for ts, tid, sc, args, res in evs:
    if sc in ('close', 'shutdown'):
        fm = fd_re.match(args.split(',')[0])
        if fm and int(fm.group(1)) in fds:
            print(f"  {ts} tid={tid} {sc}({args[:60]}) = {res[:30]}")
