import http.client, time, sys
port = int(sys.argv[1])
out = open(sys.argv[2], 'a', buffering=1)
conn = None
end = time.time() + 40
n = 0
while time.time() < end:
    n += 1
    t = time.strftime('%H:%M:%S', time.gmtime()) + f".{int((time.time()%1)*1000):03d}"
    try:
        if conn is None:
            conn = http.client.HTTPConnection('127.0.0.1', port, timeout=3)
        conn.request('GET', '/solr/probe5315/select?q=*:*')
        r = conn.getresponse()
        marker = r.getheader('X-Solr-Graceful-Shutdown')
        r.read()
        out.write(f"ka poll {n} {t} http={r.status} marker={marker}\n")
        if r.will_close:
            conn.close(); conn = None
    except Exception as e:
        out.write(f"ka poll {n} {t} http=ERR {type(e).__name__}\n")
        try: conn.close()
        except Exception: pass
        conn = None
    time.sleep(0.25)
out.write("ka poller done\n")
