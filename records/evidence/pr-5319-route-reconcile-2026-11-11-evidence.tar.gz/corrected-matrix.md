# PR 5319 route surfaces: corrected matrix (reconcile round 2)

Head: babbdaeee25b3ee4687fd1f6a6cef66a9e2d16ed (epugh/solr, SOLR-18553-fix-param-naming)
Prior evidence: records/evidence/pr-5319-route-surface-probes-2026-11-11-evidence.tar.gz,
SHA-256 bc3ab9a8c63d98253bcebe0a31a18e21be63c472e99662b6c1ae71f3da738d35 (verified in this job).
Labels: OBSERVED = executed over HTTP in the prior job at this head. INFERRED = established by
source trace at this head in this job; no new HTTP request was run for the row.

## The rename itself
- v2 detailed list (GET /api/collections?detailed=true): `route` governs, `_route_` ignored. OBSERVED.
- v1 CLUSTERSTATUS: `_route_` governs, `route` ignored. OBSERVED.

## Select
- v1 distributed select: `_route_` governs (key A and key B), `route` ignored, `_route_` wins conflicts. OBSERVED.
- v2 select: no-route (all docs), `_route_`=key A (shard1 only), `route`=key A (ignored, all docs). OBSERVED.
- v2 select: key B and conflicting-names cases. INFERRED. There is no v2-specific select code:
  V2HttpCall parses the raw query string wholesale (V2HttpCall.java:90) and builds the request with
  the same SolrRequestParsers used for v1 (V2HttpCall.java:230); the named "/select" handler
  (SearchHandler) executes for both versions, and distributed routing reads ShardParams._ROUTE_
  once, in CloudReplicaSource.java:64. Nothing in the v2 layer special-cases a second key or the
  name pair, so the v1 key-B and conflict outcomes carry over.

## Real-time get
- v1 and v2 get on a compositeId collection: key derived from the document id without a route;
  `_route_` overrides the id prefix; `route` ignored. OBSERVED (both versions, round 2 controls).
- v1 and v2 get on an implicit-router collection (router.field): explicit `_route_` required to
  reach the non-obvious shard; `route` behaves exactly as absent. OBSERVED (both versions).

## Update adds
- v1 adds under compositeId: placed by document id regardless of request-level `_route_`, `route`,
  or both; a JSON per-document "_route_" value is stored as an ordinary field. OBSERVED.
- v2 adds: INFERRED as identical. V2UpdateRequestHandler.getApis() registers UpdateAPI
  (V2UpdateRequestHandler.java:39-40); every UpdateAPI endpoint calls
  updateRequestHandler.handleRequest(req, rsp) with the unchanged request
  (UpdateAPI.java:45,50,55,61,66). The only rewrite is the PATH context set to /update/json/docs
  for the /update and /update/json forms (UpdateAPI.java:44,60), a loader selection inside the
  same handler. The update processor chain that places documents is the core's own, shared with v1.

## Update deletes
- v1 delete by id: wrong `_route_` key leaves the document in place in all three forms (JSON
  per-operation "_route_", request-level `_route_`, XML _route_ attribute); a no-route control
  delete removes it. OBSERVED.
- Delete routing inputs (source, this head): request-level ShardParams._ROUTE_
  (DistributedZkUpdateProcessor.java:483 and :699); JSON per-operation "_route_" key
  (JsonLoader.java:413, constant imported at :24); XML id attribute (XMLLoader.java:283).
- `route`-spelled deletes: INFERRED to behave exactly as no-route deletes. A search of the whole
  update path (update/, handler/loader/, UpdateRequestHandler, UpdateAPI) finds no read of a bare
  "route" parameter, and neither UpdateAPI nor V2HttpCall translates `route` to `_route_`; the
  value arrives as an ordinary unknown parameter and is never consumed by routing. The wrong-key
  protection observed for `_route_` therefore does not extend to the `route` spelling.
- v2 deletes: INFERRED as identical to v1, by the same UpdateAPI pass-through as adds.

## Javabin
- Per-document `_route_` is read from the javabin document params (JavabinLoader) and written by
  the client codec (JavaBinUpdateRequestCodec). Source-assessed in the prior job; unchanged here,
  and the /update/bin v2 endpoint is the same UpdateAPI pass-through (UpdateAPI.java:66). INFERRED.

## Add replica
- v1 ADDREPLICA with `_route_` but no shard: HTTP 400 (shard is required at the parameter layer;
  the route-only fallback in AddReplicaCmd is unreachable through v1 parameters). With an explicit
  shard, the shard wins over a conflicting `_route_`. OBSERVED.
- v2 replica creation: the path shard wins over a conflicting body `route`; the shard-less v2
  collection-level path returns 404. OBSERVED.

## Compatibility note (unchanged from the prior receipt)
The rename is confined to the v2 detailed-list endpoint and its docs. A client that generalizes
the new `route` spelling to select, get, or update gets no error anywhere: the parameter is
silently ignored on every one of those surfaces, in both API versions (observed for v1 and for
v2 select/get; inferred for v2 update by the pass-through trace above).

## Runtime work in this job
None. All three gaps closed by source trace; no Solr process was started, so there is no
process-stop or fixture cleanup to record. The prior job's fixtures were already discarded.
