#!/bin/bash
set -u
T=~/workspace/tools/5319-probes
LOG=$T/runs/build.log; : > $LOG
C=~/workspace/solr-clones/5319-probes
rm -rf "$C"; mkdir -p "$C"; cd "$C"
git init -q . >> $LOG 2>&1
git remote add origin https://github.com/epugh/solr.git
for attempt in 1 2 3 4 5; do
  git fetch -q --depth 1 origin babbdaeee25b3ee4687fd1f6a6cef66a9e2d16ed >> $LOG 2>&1 && { echo "fetch ok attempt $attempt" >> $LOG; break; }
  echo "fetch attempt $attempt failed rc=$?" >> $LOG; sleep 5
done
git checkout -q FETCH_HEAD >> $LOG 2>&1; echo "checkout rc=$?" >> $LOG
git rev-parse HEAD >> $LOG 2>&1
cp ~/workspace/solr/gradle.properties .
{
  flock 9
  timeout 2400 ~/workspace/tools/solr-gradle.sh :solr:packaging:installDist -x test --console=plain 9>&-
  echo "installDist rc=$?"
} 9>~/workspace/tools/.solr-test-queue.lock >> $LOG 2>&1
ls solr/packaging/build/ >> $LOG 2>&1
echo "BUILD DONE" >> $LOG
cat $LOG
