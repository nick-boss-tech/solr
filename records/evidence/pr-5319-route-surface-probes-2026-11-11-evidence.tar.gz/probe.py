#!/usr/bin/env python3
"""PR 5319 route-surface probes at head babbdaeee. Disposable packaged cluster."""
import glob, json, os, sys, time, urllib.request, urllib.error

BASE = "http://127.0.0.1:18983"
BASE2 = "http://127.0.0.1:18984"
HERE = os.path.dirname(os.path.abspath(__file__))
RUNS = os.path.join(HERE, "runs")
os.makedirs(RUNS, exist_ok=True)

def _seq():
    n = 0
    for f in glob.glob(os.path.join(RUNS, "[0-9]*")):
        try: n = max(n, int(os.path.basename(f)[:3]))
        except ValueError: pass
    return n + 1

SEQ = [_seq()]

def call(name, method, url, body=None, ctype="application/json"):
    data = None
    headers = {}
    if body is not None:
        data = body.encode() if isinstance(body, str) else body
        headers["Content-Type"] = ctype
    req = urllib.request.Request(url, data=data, headers=headers, method=method)
    try:
        with urllib.request.urlopen(req, timeout=120) as resp:
            status, text = resp.status, resp.read().decode("utf-8", "replace")
    except urllib.error.HTTPError as e:
        status, text = e.code, e.read().decode("utf-8", "replace")
    except Exception as e:
        status, text = -1, f"{type(e).__name__}: {e}"
    fn = os.path.join(RUNS, f"{SEQ[0]:03d}-{name}.json")
    SEQ[0] += 1
    with open(fn, "w") as f:
        json.dump({"method": method, "url": url, "status": status, "body": text}, f, indent=1)
    try:
        return status, json.loads(text)
    except Exception:
        return status, text

def clusterstatus(coll):
    s, j = call(f"clusterstatus-{coll}", "GET",
                f"{BASE}/solr/admin/collections?action=CLUSTERSTATUS&collection={coll}&wt=json")
    return j["cluster"]["collections"][coll]

def cores(coll):
    """shard -> {core, base} for the (single) replica of each shard."""
    cs = clusterstatus(coll)
    out = {}
    for shard, info in cs["shards"].items():
        for name, rep in info["replicas"].items():
            out[shard] = {"core": rep["core"], "base": rep["base_url"]}
    return out

def local_select(coll, shardmap, shard, q="*:*", extra=""):
    info = shardmap[shard]
    s, j = call(f"local-{coll}-{shard}", "GET",
                f"{info['base']}/{info['core']}/select?q={q}&distrib=false&rows=100&fl=id&wt=json{extra}")
    return sorted(d["id"] for d in j["response"]["docs"])

def wait_active(coll, want_replicas, timeout=180):
    deadline = time.time() + timeout
    while time.time() < deadline:
        cs = clusterstatus(coll)
        states = []
        total = 0
        for shard, info in cs["shards"].items():
            for name, rep in info["replicas"].items():
                total += 1
                states.append(rep["state"])
        if total == want_replicas and all(st == "active" for st in states):
            return True
        time.sleep(3)
    return False

def setup():
    for coll in ["routes", "routesrtg", "routesupd", "routesar"]:
        s, j = call(f"create-{coll}", "GET",
                    f"{BASE}/solr/admin/collections?action=CREATE&name={coll}&numShards=2&replicationFactor=1&wt=json")
        print("create", coll, s)
    assert wait_active("routes", 2)
    docs = [{"id": "ka!a1", "grp_s": "A"}, {"id": "ka!a2", "grp_s": "A"},
            {"id": "kb!b1", "grp_s": "B"},
            {"id": "kc!c1", "grp_s": "C"}, {"id": "kd!d1", "grp_s": "D"},
            {"id": "plain1", "grp_s": "P"}, {"id": "plain2", "grp_s": "P"}]
    s, j = call("index-routes", "POST", f"{BASE}/solr/routes/update/json?commit=true",
                json.dumps(docs))
    print("index routes", s)
    sm = cores("routes")
    placement = {sh: local_select("routes", sm, sh) for sh in sorted(sm)}
    print("placement:", json.dumps(placement))
    keyshard = {}
    for sh, ids in placement.items():
        for i in ids:
            if "!" in i:
                keyshard[i.split("!")[0]] = sh
    print("key->shard:", json.dumps(keyshard))
    with open(os.path.join(RUNS, "mapping.json"), "w") as f:
        json.dump({"placement": placement, "keyshard": keyshard, "cores": sm}, f, indent=1)

def mapping():
    with open(os.path.join(RUNS, "mapping.json")) as f:
        return json.load(f)

def two_keys():
    ks = mapping()["keyshard"]
    byshard = {}
    for k, sh in ks.items():
        byshard.setdefault(sh, k)
    shards = sorted(byshard)
    return byshard[shards[0]], byshard[shards[1]], shards[0], shards[1]

# ---------------- list leg ----------------
def list_leg():
    ka, kb, sha, shb = two_keys()
    print(f"KEY_A={ka} ({sha}) KEY_B={kb} ({shb})")
    def v2(name, qs):
        s, j = call(name, "GET", f"{BASE}/api/collections?detailed=true&collection=routes&wt=json{qs}")
        shards = []
        try:
            shards = sorted(j["collections"]["routes"]["shards"].keys())
        except Exception:
            pass
        print("V2", name, "http", s, "shards", shards)
        return shards
    def v1(name, qs):
        s, j = call(name, "GET", f"{BASE}/solr/admin/collections?action=CLUSTERSTATUS&collection=routes&wt=json{qs}")
        shards = []
        try:
            shards = sorted(j["cluster"]["collections"]["routes"]["shards"].keys())
        except Exception:
            pass
        print("V1", name, "http", s, "shards", shards)
        return shards
    v2("list-v2-unfiltered", "")
    v2("list-v2-routeA", f"&route={ka}")
    v2("list-v2-routeB", f"&route={kb}")
    v2("list-v2-oldnameA", f"&_route_={ka}")
    v2("list-v2-both-conflict", f"&route={ka}&_route_={kb}")
    v1("list-v1-unfiltered", "")
    v1("list-v1-oldnameA", f"&_route_={ka}")
    v1("list-v1-oldnameB", f"&_route_={kb}")
    v1("list-v1-newnameA", f"&route={ka}")

# ---------------- select leg ----------------
def select_leg():
    ka, kb, sha, shb = two_keys()
    m = mapping()
    def dist(name, path, qs):
        s, j = call(name, "GET", f"{BASE}{path}?q=*:*&rows=100&fl=id&wt=json{qs}")
        ids = []
        nf = None
        try:
            nf = j["response"]["numFound"]
            ids = sorted(d["id"] for d in j["response"]["docs"])
        except Exception:
            pass
        print(name, "http", s, "numFound", nf, "ids", ids)
        return ids
    full = m["placement"][sha] + m["placement"][shb]
    print("expected full:", sorted(full), "| shardA set:", m["placement"][sha], "| shardB set:", m["placement"][shb])
    dist("select-v1-noroute", "/solr/routes/select", "")
    dist("select-v1-oldnameA", "/solr/routes/select", f"&_route_={ka}")
    dist("select-v1-oldnameB", "/solr/routes/select", f"&_route_={kb}")
    dist("select-v1-newnameA", "/solr/routes/select", f"&route={ka}")
    dist("select-v1-both-conflict", "/solr/routes/select", f"&_route_={ka}&route={kb}")
    dist("select-v2-noroute", "/api/collections/routes/select", "")
    dist("select-v2-oldnameA", "/api/collections/routes/select", f"&_route_={ka}")
    dist("select-v2-newnameA", "/api/collections/routes/select", f"&route={ka}")
    # id-targeted queries prove narrowing vs absence: doc ka!a1 lives on KEY_A's shard
    qid = urllib.parse.quote(ka + "!a1")
    for name, qs in [("select-v1-idA-wrongroute", f"&_route_={kb}"),
                     ("select-v1-idA-rightroute", f"&_route_={ka}"),
                     ("select-v1-idA-newname-wrong", f"&route={kb}")]:
        s, j = call(name, "GET", f"{BASE}/solr/routes/select?q=id:{qid}&wt=json{qs}")
        print(name, "http", s, "numFound", (j.get("response") or {}).get("numFound"))

import urllib.parse

# ---------------- get (RTG) leg ----------------
def get_leg():
    ka, kb, sha, shb = two_keys()
    coll = "routesrtg"
    sm = cores(coll)
    docid = "rtgplain1"
    # control: add with no route, locate home shard
    s, j = call("get-ctl-add", "POST", f"{BASE}/solr/{coll}/update/json?commit=true",
                json.dumps([{"id": docid, "grp_s": "R"}]))
    home = None
    for sh in sorted(sm):
        ids = local_select(coll, sm, sh, q=f"id:{docid}")
        if ids: home = sh
    print("control home shard:", home)
    other = shb if home == sha else sha
    okey = kb if home == sha else ka
    print(f"explicit route key for other shard: {okey} -> {other}")
    # delete control, re-add pinned to the other shard via request-level _route_
    call("get-ctl-del", "POST", f"{BASE}/solr/{coll}/update/json?commit=true",
         json.dumps({"delete": {"id": docid}}))
    s, j = call("get-pin-add", "POST", f"{BASE}/solr/{coll}/update/json?commit=true&_route_={okey}",
                json.dumps([{"id": docid, "grp_s": "R"}]))
    print("pinned add http", s)
    for sh in sorted(sm):
        print("pinned placement", sh, local_select(coll, sm, sh, q=f"id:{docid}"))
    def get(name, path, qs):
        s, j = call(name, "GET", f"{BASE}{path}?id={docid}&wt=json{qs}")
        doc = None
        try: doc = (j.get("doc") or {}).get("id")
        except Exception: pass
        print(name, "http", s, "doc", doc)
    get("get-v1-noroute", f"/solr/{coll}/get", "")
    get("get-v1-oldname-other", f"/solr/{coll}/get", f"&_route_={okey}")
    get("get-v1-oldname-home", f"/solr/{coll}/get", f"&_route_={ka if okey == kb else kb}")
    get("get-v1-newname-other", f"/solr/{coll}/get", f"&route={okey}")
    get("get-v1-both-conflict", f"/solr/{coll}/get", f"&_route_={okey}&route={ka if okey == kb else kb}")
    get("get-v2-noroute", f"/api/collections/{coll}/get", "")
    get("get-v2-oldname-other", f"/api/collections/{coll}/get", f"&_route_={okey}")
    get("get-v2-newname-other", f"/api/collections/{coll}/get", f"&route={okey}")

# ---------------- update leg ----------------
def update_leg():
    ka, kb, sha, shb = two_keys()
    coll = "routesupd"
    sm = cores(coll)
    def locate(docid):
        here = [sh for sh in sorted(sm) if local_select(coll, sm, sh, q=f"id:{docid}")]
        return here
    def add(name, docid, qs=""):
        s, j = call(name, "POST", f"{BASE}/solr/{coll}/update/json?commit=true{qs}",
                    json.dumps([{"id": docid, "grp_s": "U"}]))
        print(name, "http", s, "-> located", locate(docid))
        return s
    # controls: no-route adds establish each id's hash shard
    add("upd-u0-noroute", "u0")
    add("upd-u1-noroute-probe", "u1probe")
    # request-level _route_ pins u1 to KEY_B's shard (delete the probe pattern: use fresh ids per case)
    add("upd-u2-oldname-B", "u2", f"&_route_={kb}")
    add("upd-u3-newname-B", "u3", f"&route={kb}")
    add("upd-u4-both-conflict", "u4", f"&_route_={ka}&route={kb}")
    # request-level route via XML add for format parity
    s, j = call("upd-u5-xml-oldname-B", "POST", f"{BASE}/solr/{coll}/update?commit=true&_route_={kb}",
                '<add><doc><field name="id">u5</field><field name="grp_s">U</field></doc></add>',
                ctype="text/xml")
    print("upd-u5-xml-oldname-B http", s, "-> located", locate("u5"))
    # JSON add carrying a per-doc _route_ key
    s, j = call("upd-u6-json-perdoc-route", "POST", f"{BASE}/solr/{coll}/update/json?commit=true",
                json.dumps([{"id": "u6", "_route_": kb, "grp_s": "U"}]))
    print("upd-u6-json-perdoc-route http", s, "body head:", str(j)[:220], "-> located", locate("u6"))
    # deletes: u2 sits on KEY_B's shard (via _route_ add). Delete by id without route first.
    s, j = call("upd-del-u2-noroute", "POST", f"{BASE}/solr/{coll}/update/json?commit=true",
                json.dumps({"delete": {"id": "u2"}}))
    print("del u2 no-route http", s, "-> still located", locate("u2"))
    s, j = call("upd-del-u2-oldname", "POST", f"{BASE}/solr/{coll}/update/json?commit=true&_route_={kb}",
                json.dumps({"delete": {"id": "u2"}}))
    print("del u2 with _route_ http", s, "-> still located", locate("u2"))
    # per-operation delete routes: JSON {"delete":{"id":..,"_route_":..}}
    add("upd-u7-oldname-B", "u7", f"&_route_={kb}")
    s, j = call("upd-del-u7-perop-wrong", "POST", f"{BASE}/solr/{coll}/update/json?commit=true",
                json.dumps({"delete": {"id": "u7", "_route_": ka}}))
    print("del u7 per-op wrong-key http", s, "-> still located", locate("u7"))
    s, j = call("upd-del-u7-perop-right", "POST", f"{BASE}/solr/{coll}/update/json?commit=true",
                json.dumps({"delete": {"id": "u7", "_route_": kb}}))
    print("del u7 per-op right-key http", s, "-> still located", locate("u7"))
    # per-operation delete route: XML <id _route_="..">
    add("upd-u8-oldname-B", "u8", f"&_route_={kb}")
    s, j = call("upd-del-u8-xml-perop", "POST", f"{BASE}/solr/{coll}/update?commit=true",
                f'<delete><id _route_="{kb}">u8</id></delete>', ctype="text/xml")
    print("del u8 xml per-op http", s, "-> still located", locate("u8"))

# ---------------- add-replica leg ----------------
def replica_leg():
    ka, kb, sha, shb = two_keys()
    coll = "routesar"
    def status(name):
        cs = clusterstatus(coll)
        out = {}
        for shard, info in cs["shards"].items():
            out[shard] = sorted((r["core"], r["node_name"], r["state"]) for r in info["replicas"].values())
        print(name, json.dumps(out))
        return out
    status("replica-initial")
    # v1 route-only: no shard param, _route_=<KEY_B> should select KEY_B's shard
    s, j = call("repl-v1-routeonly-B", "GET",
                f"{BASE}/solr/admin/collections?action=ADDREPLICA&collection={coll}&_route_={kb}&wt=json")
    print("v1 route-only http", s, str(j)[:200])
    wait_active(coll, 3, timeout=240)
    status("replica-after-v1-routeonly")
    # v1 conflicting: shard=shard-of-A with _route_=<KEY_B>
    s, j = call("repl-v1-conflict", "GET",
                f"{BASE}/solr/admin/collections?action=ADDREPLICA&collection={coll}&shard={sha}&_route_={kb}&wt=json")
    print("v1 conflict http", s, str(j)[:200])
    wait_active(coll, 4, timeout=240)
    status("replica-after-v1-conflict")
    # v2 matching route: path shard = shard-of-A, body route = KEY_A
    s, j = call("repl-v2-match", "POST", f"{BASE}/api/collections/{coll}/shards/{sha}/replicas?wt=json",
                json.dumps({"route": ka}))
    print("v2 match http", s, str(j)[:200])
    wait_active(coll, 5, timeout=240)
    status("replica-after-v2-match")
    # v2 conflicting route: path shard = shard-of-B, body route = KEY_A
    s, j = call("repl-v2-conflict", "POST", f"{BASE}/api/collections/{coll}/shards/{shb}/replicas?wt=json",
                json.dumps({"route": ka}))
    print("v2 conflict http", s, str(j)[:200])
    wait_active(coll, 6, timeout=240)
    status("replica-after-v2-conflict")
    # v2 without shard path
    s, j = call("repl-v2-noshard", "POST", f"{BASE}/api/collections/{coll}/replicas?wt=json",
                json.dumps({"route": ka}))
    print("v2 no-shard-path http", s, str(j)[:300])
    # cleanup: delete every replica beyond the first per shard
    cs = clusterstatus(coll)
    for shard, info in cs["shards"].items():
        reps = sorted(info["replicas"].keys())
        for extra in reps[1:]:
            s, j = call(f"repl-cleanup-{extra}", "GET",
                        f"{BASE}/solr/admin/collections?action=DELETEREPLICA&collection={coll}&shard={shard}&replica={extra}&wt=json")
            print("cleanup", extra, "http", s)
    time.sleep(5)
    status("replica-after-cleanup")

if __name__ == "__main__":
    cmd = sys.argv[1]
    {"setup": setup, "list": list_leg, "select": select_leg, "get": get_leg,
     "update": update_leg, "replica": replica_leg}[cmd]()
