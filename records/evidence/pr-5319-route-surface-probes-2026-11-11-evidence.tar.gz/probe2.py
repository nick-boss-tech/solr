#!/usr/bin/env python3
"""PR 5319 probes round 2: discriminating controls for update/get legs."""
import json, os, sys
sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
import probe
from probe import call, cores, local_select, clusterstatus, mapping

def home_of(docid, scratch="routes"):
    """Learn docid's natural shard by a no-route add into a same-range scratch collection."""
    call(f"home-add-{docid}", "POST", f"{probe.BASE}/solr/{scratch}/update/json?commit=true",
         json.dumps([{"id": docid, "grp_s": "H"}]))
    sm = cores(scratch)
    found = [sh for sh in sorted(sm) if local_select(scratch, sm, sh, q=f"id:{docid}")]
    call(f"home-del-{docid}", "POST", f"{probe.BASE}/solr/{scratch}/update/json?commit=true",
         json.dumps({"delete": {"id": docid}}))
    return found[0] if found else None

def locate(coll, docid):
    sm = cores(coll)
    return [sh for sh in sorted(sm) if local_select(coll, sm, sh, q=f"id:{docid}")]

def add(coll, name, docid, qs="", body=None, ctype="application/json"):
    if body is None:
        body = json.dumps([{"id": docid, "grp_s": "U"}])
    s, j = call(name, "POST", f"{probe.BASE}/solr/{coll}/update/json?commit=true{qs}", body, ctype=ctype)
    print(name, "http", s, "-> located", locate(coll, docid))
    return s, j

def main():
    ka, kb = probe.two_keys()[0], probe.two_keys()[1]  # ka -> shard1, kb(=kc) -> shard2
    sha, shb = probe.two_keys()[2], probe.two_keys()[3]
    print(f"KEY_A={ka}->{sha} KEY_B={kb}->{shb}")
    # --- pin tests on routesrtg with home-known plain ids
    homes = {}
    for cand in ["pinA", "pinB", "pinC", "pinD"]:
        homes[cand] = home_of(cand)
    print("homes:", homes)
    by_home = {}
    for i, h in homes.items():
        by_home.setdefault(h, i)
    id_h1, id_h2 = by_home[sha], by_home[shb]
    print(f"id home {sha}: {id_h1}; id home {shb}: {id_h2}")
    add("routesrtg", "pin1-homeA-routeB", id_h1, f"&_route_={kb}")
    add("routesrtg", "pin2-homeB-routeA", id_h2, f"&_route_={ka}")
    # --- update redo on routesupd
    add("routesupd", "wA-home-known-route-newname", id_h1, f"&route={kb}")
    add("routesupd", "wB-both-names", id_h2, f"&_route_={ka}&route={kb}")
    s, j = call("wC-xml-oldname", "POST", f"{probe.BASE}/solr/routesupd/update?commit=true&_route_={ka}",
                f'<add><doc><field name="id">{id_h2}2</field><field name="grp_s">U</field></doc></add>',
                ctype="text/xml")
    print("wC-xml-oldname (id", id_h2 + "2", "home", home_of(id_h2 + "2"), ") http", s, "-> located", locate("routesupd", id_h2 + "2"))
    s, j = call("wD-json-perdoc", "POST", f"{probe.BASE}/solr/routesupd/update/json?commit=true",
                json.dumps([{"id": id_h2 + "3", "_route_": ka, "grp_s": "U"}]))
    print("wD-json-perdoc http", s, "-> located", locate("routesupd", id_h2 + "3"))
    s, j = call("wD-fetch", "GET", f"{probe.BASE}/solr/routesupd/select?q=id:{id_h2}3&fl=*&wt=json")
    print("wD stored doc:", json.dumps(((j.get('response') or {}).get('docs') or []))[:300])
    # --- delete discrimination on routesupd: doc kc!del1 naturally on shard2 (KEY_B shard)
    docid = kb + "!del1"
    def readd():
        call("del-readd", "POST", f"{probe.BASE}/solr/routesupd/update/json?commit=true",
             json.dumps([{"id": docid, "grp_s": "U"}]))
    readd(); print("del1 placed:", locate("routesupd", docid))
    s, j = call("del-perop-wrong", "POST", f"{probe.BASE}/solr/routesupd/update/json?commit=true",
                json.dumps({"delete": {"id": docid, "_route_": ka}}))
    print("delete per-op _route_=KEY_A(wrong) http", s, "-> still located", locate("routesupd", docid))
    readd()
    s, j = call("del-reqlevel-wrong", "POST", f"{probe.BASE}/solr/routesupd/update/json?commit=true&_route_={ka}",
                json.dumps({"delete": {"id": docid}}))
    print("delete request-level _route_=KEY_A(wrong) http", s, "-> still located", locate("routesupd", docid))
    readd()
    s, j = call("del-xml-perop-wrong", "POST", f"{probe.BASE}/solr/routesupd/update?commit=true",
                f'<delete><id _route_="{ka}">{docid}</id></delete>', ctype="text/xml")
    print("delete XML per-op _route_=KEY_A(wrong) http", s, "-> still located", locate("routesupd", docid))
    readd()
    s, j = call("del-control-noroute", "POST", f"{probe.BASE}/solr/routesupd/update/json?commit=true",
                json.dumps({"delete": {"id": docid}}))
    print("delete control no-route http", s, "-> still located", locate("routesupd", docid))
    # --- get leg: implicit-router collection
    s, j = call("create-routesimp", "GET",
                f"{probe.BASE}/solr/admin/collections?action=CREATE&name=routesimp&router.name=implicit&router.field=route_s&shards=shard1,shard2&replicationFactor=1&wt=json")
    print("create routesimp http", s, str(j)[:160])
    probe.wait_active("routesimp", 2)
    s, j = call("imp-add", "POST", f"{probe.BASE}/solr/routesimp/update/json?commit=true",
                json.dumps([{"id": "imp1", "route_s": "shard2", "grp_s": "I"}]))
    print("imp1 add http", s, "-> located", locate("routesimp", "imp1"))
    def get(name, path, qs):
        s, j = call(name, "GET", f"{probe.BASE}{path}?id=imp1&wt=json{qs}")
        doc = None
        try: doc = (j.get("doc") or {}).get("id")
        except Exception: pass
        print(name, "http", s, "doc", doc)
    get("imp-get-v1-noroute", "/solr/routesimp/get", "")
    get("imp-get-v1-route-shard2", "/solr/routesimp/get", "&_route_=shard2")
    get("imp-get-v1-route-shard1", "/solr/routesimp/get", "&_route_=shard1")
    get("imp-get-v1-newname-shard2", "/solr/routesimp/get", "&route=shard2")
    get("imp-get-v2-noroute", "/api/collections/routesimp/get", "")
    get("imp-get-v2-oldname", "/api/collections/routesimp/get", "&_route_=shard2")
    get("imp-get-v2-newname", "/api/collections/routesimp/get", "&route=shard2")
    # --- get leg: composite prefixed doc pair on routesrtg
    gid = kb + "!g1"
    call("g-add", "POST", f"{probe.BASE}/solr/routesrtg/update/json?commit=true",
         json.dumps([{"id": gid, "grp_s": "G"}]))
    print(gid, "placed:", locate("routesrtg", gid), "(id home is KEY_B shard by prefix)")
    def getg(name, path, qs):
        s, j = call(name, "GET", f"{probe.BASE}{path}?id={gid}&wt=json{qs}")
        doc = None
        try: doc = (j.get("doc") or {}).get("id")
        except Exception: pass
        print(name, "http", s, "doc", doc)
    getg("g-get-noroute", "/solr/routesrtg/get", "")
    getg("g-get-rightkey", "/solr/routesrtg/get", f"&_route_={kb}")
    getg("g-get-wrongkey", "/solr/routesrtg/get", f"&_route_={ka}")
    getg("g-get-newname-wrong", "/solr/routesrtg/get", f"&route={ka}")

if __name__ == "__main__":
    main()
