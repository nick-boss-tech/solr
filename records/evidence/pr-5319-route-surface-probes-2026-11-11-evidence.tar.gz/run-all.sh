#!/bin/bash
set -u
T=~/workspace/tools/5319-probes
RUNS=$T/runs
INST=$(ls -d ~/workspace/solr-clones/5319-probes/solr/packaging/build/solr-11.0.0-SNAPSHOT)
export JAVA_HOME=~/workspace/tools/jdk21/jdk-21.0.12.1+1
export PATH=$JAVA_HOME/bin:$PATH
export JDK_JAVA_OPTIONS=-Djava.net.preferIPv4Stack=true
export SOLR_ULIMIT_CHECKS=false
{
  mkdir -p $T/node1-home $T/node2-home $T/node1-logs $T/node2-logs $T/node1-pids $T/node2-pids
  SOLR_LOGS_DIR=$T/node1-logs SOLR_PID_DIR=$T/node1-pids $INST/bin/solr start --force -p 18983 --solr-home $T/node1-home --host 127.0.0.1
  echo "node1 rc=$?"
  for i in $(seq 1 40); do curl -sf http://127.0.0.1:18983/solr/admin/info/system?wt=json -o $RUNS/node1-system.json && break; sleep 5; done
  SOLR_LOGS_DIR=$T/node2-logs SOLR_PID_DIR=$T/node2-pids $INST/bin/solr start --force -p 18984 --solr-home $T/node2-home --host 127.0.0.1 -z 127.0.0.1:19983
  echo "node2 rc=$?"
  for i in $(seq 1 40); do curl -sf http://127.0.0.1:18984/solr/admin/info/system?wt=json -o $RUNS/node2-system.json && break; sleep 5; done
  cd $T
  for leg in setup list select get update replica; do
    echo "===== LEG $leg"
    python3 probe.py $leg 2>&1
    echo "===== LEG $leg rc=$?"
  done
  SOLR_LOGS_DIR=$T/node2-logs SOLR_PID_DIR=$T/node2-pids $INST/bin/solr stop -p 18984
  echo "node2 stop rc=$?"
  SOLR_LOGS_DIR=$T/node1-logs SOLR_PID_DIR=$T/node1-pids $INST/bin/solr stop -p 18983
  echo "node1 stop rc=$?"
  sleep 5
  ps aux | grep "[s]olr" | grep -v grep > $RUNS/teardown-ps.txt; echo "remaining solr procs: $(wc -l < $RUNS/teardown-ps.txt)"
  echo "RUN-ALL DONE"
} > $RUNS/run-all.log 2>&1
cat $RUNS/run-all.log
