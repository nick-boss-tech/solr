/*
 * Disposable gate probe for pr-5321-response-coverage-linux-20261111, leg 4.
 * NOT part of the branch. Never committed or pushed. Archived in gate evidence.
 * Indexes a real stored field whose name begins with a hyphen ("-foo_s",
 * matched by schema12's *_s dynamic field) plus a control field, then records
 * the serialized response for a baseline request and for an explicit
 * fl=-foo_s request, or the parser error if the request fails.
 */
package org.apache.solr.search;

import org.apache.solr.SolrTestCaseJ4;
import org.junit.BeforeClass;
import org.junit.Test;

public class HyphenFlProbeTest extends SolrTestCaseJ4 {

  @BeforeClass
  public static void beforeClass() throws Exception {
    System.setProperty("solr.index.updatelog.enabled", "false");
    initCore("solrconfig.xml", "schema12.xml");
  }

  @Test
  public void probeHyphenField() throws Exception {
    assertU(adoc("id", "1", "-foo_s", "hyphval", "title_s", "control"));
    assertU(commit());

    String all = h.query(req("q", "*:*", "wt", "xml"));
    System.out.println("PROBE-BASELINE-BEGIN");
    System.out.println(all);
    System.out.println("PROBE-BASELINE-END");

    String excl = null;
    Throwable err = null;
    try {
      excl = h.query(req("q", "*:*", "fl", "-foo_s", "wt", "xml"));
    } catch (Throwable t) {
      err = t;
    }
    System.out.println("PROBE-EXCL-BEGIN");
    System.out.println(excl);
    System.out.println("PROBE-EXCL-END");
    System.out.println("PROBE-ERROR: " + err);
  }
}
