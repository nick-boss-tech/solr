#!/bin/bash
set -u
OUT=~/workspace/tools/gate-5321/runs
G=~/workspace/tools/solr-gradle.sh
LOG="$OUT/resume.log"; : > "$LOG"
exec 9>~/workspace/tools/.solr-test-queue.lock
flock 9
# Part 1 retry: root check in main clone at exact head
cd ~/workspace/solr-clones/5321-cov || exit 2
echo "cov HEAD=$(git rev-parse HEAD) tracked=$(git status --porcelain | wc -l)" >> "$LOG"
pkill -f 'Gradle[D]aemon' 2>/dev/null; sleep 2
rm -f ~/.gradle/caches/journal-1/journal-1.lock
$G --no-daemon check -x test >> "$OUT/check3.log" 2>&1 9>&-
echo "rootcheck3 rc=$?" >> "$LOG"
# Part 2: classification clone, javabin alone at parent and base
rm -rf ~/workspace/solr-clones/5321-mut
git clone -q --no-checkout ~/workspace/solr ~/workspace/solr-clones/5321-mut
cd ~/workspace/solr-clones/5321-mut || exit 2
git remote add fork https://github.com/nick-boss-tech/solr.git 2>/dev/null
git fetch -q fork 0de81e22382b81a87826b3744a0a91e6f4d9d1bc 35db4554284ca0d2ca37eb78ed4c7c7dee599db2 780653ba4e9e65052dc7eb7baf77113a6788bbb5
cp ~/workspace/solr/gradle.properties .
R=solr/core/build/test-results/test
for ref in 35db4554284ca0d2ca37eb78ed4c7c7dee599db2 780653ba4e9e65052dc7eb7baf77113a6788bbb5; do
  git checkout -q $ref; git checkout -- . 2>/dev/null
  pkill -f 'Gradle[D]aemon' 2>/dev/null; sleep 2
  rm -f ~/.gradle/caches/journal-1/journal-1.lock
  $G --no-daemon :solr:core:cleanTest :solr:core:test --tests org.apache.solr.response.TestJavaBinResponseWriter -Ptests.seed=5321CAFE >> "$OUT/classify-$ref.log" 2>&1 9>&-
  echo "classify $ref rc=$?" >> "$LOG"
  cp $R/TEST-org.apache.solr.response.TestJavaBinResponseWriter.xml "$OUT/classify-$ref-javabin.xml" 2>/dev/null
done
# Part 3: mutation at head
git checkout -q 0de81e22382b81a87826b3744a0a91e6f4d9d1bc; git checkout -- . 2>/dev/null
echo "mutation-base HEAD=$(git rev-parse HEAD) tracked=$(git status --porcelain | wc -l)" >> "$LOG"
python3 - <<'PYEOF'
p='solr/core/src/java/org/apache/solr/search/SolrReturnFields.java'
s=open(p).read()
old='''  private boolean isExcluded(String field) {
    if (excludedFields.contains(field)) {'''
new='''  private boolean isExcluded(String field) {
    if (true) return false; // MUTATION for gate pr-5321-response-coverage-linux-20261111
    if (excludedFields.contains(field)) {'''
assert old in s
open(p,'w').write(s.replace(old,new,1))
print('mutation applied')
PYEOF
git diff > "$OUT/mutation.patch"
pkill -f 'Gradle[D]aemon' 2>/dev/null; sleep 2
rm -f ~/.gradle/caches/journal-1/journal-1.lock
$G --no-daemon :solr:core:cleanTest :solr:core:test --tests "org.apache.solr.search.ReturnFieldsTest.testExclusionResponses" -Ptests.seed=5321CAFE >> "$OUT/mut-rf.log" 2>&1 9>&-
echo "mut ReturnFieldsTest.testExclusionResponses rc=$?" >> "$LOG"
cp $R/TEST-org.apache.solr.search.ReturnFieldsTest.xml "$OUT/mut-rf.xml" 2>/dev/null
$G --no-daemon :solr:core:test --tests "org.apache.solr.response.TestCSVResponseWriter.testExclusionResponse" -Ptests.seed=5321CAFE --rerun-tasks >> "$OUT/mut-csv.log" 2>&1 9>&-
echo "mut TestCSVResponseWriter.testExclusionResponse rc=$?" >> "$LOG"
cp $R/TEST-org.apache.solr.response.TestCSVResponseWriter.xml "$OUT/mut-csv.xml" 2>/dev/null
$G --no-daemon :solr:core:test --tests "org.apache.solr.response.TestJavaBinResponseWriter.testExclusionResponse" -Ptests.seed=5321CAFE --rerun-tasks >> "$OUT/mut-javabin.log" 2>&1 9>&-
echo "mut TestJavaBinResponseWriter.testExclusionResponse rc=$?" >> "$LOG"
cp $R/TEST-org.apache.solr.response.TestJavaBinResponseWriter.xml "$OUT/mut-javabin.xml" 2>/dev/null
git checkout -- solr/core/src/java/org/apache/solr/search/SolrReturnFields.java
echo "restored tracked=$(git status --porcelain | wc -l)" >> "$LOG"
$G --no-daemon :solr:core:test --tests "org.apache.solr.search.ReturnFieldsTest.testExclusionResponses" --tests "org.apache.solr.response.TestCSVResponseWriter.testExclusionResponse" --tests "org.apache.solr.response.TestJavaBinResponseWriter.testExclusionResponse" -Ptests.seed=5321CAFE --rerun-tasks >> "$OUT/mut-restored.log" 2>&1 9>&-
echo "restored-rerun rc=$?" >> "$LOG"
cp $R/TEST-org.apache.solr.search.ReturnFieldsTest.xml "$OUT/mut-restored-rf.xml" 2>/dev/null
cp $R/TEST-org.apache.solr.response.TestCSVResponseWriter.xml "$OUT/mut-restored-csv.xml" 2>/dev/null
cp $R/TEST-org.apache.solr.response.TestJavaBinResponseWriter.xml "$OUT/mut-restored-javabin.xml" 2>/dev/null
cat "$LOG"
