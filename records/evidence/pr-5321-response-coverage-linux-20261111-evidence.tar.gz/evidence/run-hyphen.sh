#!/bin/bash
set -u
OUT=~/workspace/tools/gate-5321/runs
G=~/workspace/tools/solr-gradle.sh
LOG="$OUT/hyphen.log"; : > "$LOG"
exec 9>~/workspace/tools/.solr-test-queue.lock
flock 9
cd ~/workspace/solr-clones/5321-mut || exit 2
TGT=solr/core/src/test/org/apache/solr/search/HyphenFlProbeTest.java
for ref in 35db4554284ca0d2ca37eb78ed4c7c7dee599db2 780653ba4e9e65052dc7eb7baf77113a6788bbb5; do
  git checkout -q $ref; git checkout -- . 2>/dev/null; rm -f $TGT
  echo "hyphen $ref HEAD=$(git rev-parse HEAD)" >> "$LOG"
  cp ~/workspace/tools/gate-5321/HyphenFlProbeTest.java $TGT
  pkill -f 'Gradle[D]aemon' 2>/dev/null; sleep 2
  rm -f ~/.gradle/caches/journal-1/journal-1.lock
  $G --no-daemon :solr:core:cleanTest :solr:core:test --tests "org.apache.solr.search.HyphenFlProbeTest" -Ptests.seed=5321CAFE >> "$OUT/hyphen-$ref.log" 2>&1 9>&-
  echo "hyphen $ref rc=$?" >> "$LOG"
  cp solr/core/build/test-results/test/TEST-org.apache.solr.search.HyphenFlProbeTest.xml "$OUT/hyphen-$ref.xml" 2>/dev/null
  rm -f $TGT; git checkout -- . 2>/dev/null
  echo "hyphen $ref cleaned tracked=$(git status --porcelain | wc -l)" >> "$LOG"
done
git checkout -q 0de81e22382b81a87826b3744a0a91e6f4d9d1bc
echo "final HEAD=$(git rev-parse HEAD) tracked=$(git status --porcelain | wc -l)" >> "$LOG"
python3 - <<'PYEOF'
import xml.etree.ElementTree as ET, os
H=os.path.expanduser('~/workspace/tools/gate-5321/runs/')
for ref in ['35db4554284ca0d2ca37eb78ed4c7c7dee599db2','780653ba4e9e65052dc7eb7baf77113a6788bbb5']:
    f=H+f'hyphen-{ref}.xml'
    if not os.path.exists(f):
        print(ref, 'NO XML'); continue
    r=ET.parse(f).getroot()
    so=r.find('system-out')
    txt = so.text if so is not None and so.text else ''
    with open(H+f'hyphen-{ref}-output.txt','w') as fh: fh.write(txt)
    print(ref, 'tests', r.get('tests'), 'failures', r.get('failures'), 'errors', r.get('errors'), 'sysout chars', len(txt))
PYEOF
cat "$LOG"
