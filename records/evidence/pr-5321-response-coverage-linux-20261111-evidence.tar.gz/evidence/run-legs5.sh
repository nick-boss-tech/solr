#!/bin/bash
set -u
OUT=~/workspace/tools/gate-5321/runs
G=~/workspace/tools/solr-gradle.sh
LOG="$OUT/resume2.log"; : > "$LOG"
exec 9>~/workspace/tools/.solr-test-queue.lock
flock 9
cd ~/workspace/solr-clones/5321-mut || exit 2
echo "mut-clone HEAD=$(git rev-parse HEAD) tracked=$(git status --porcelain | wc -l)" >> "$LOG"
R=solr/core/build/test-results/test
pkill -f 'Gradle[D]aemon' 2>/dev/null; sleep 2
rm -f ~/.gradle/caches/journal-1/journal-1.lock
$G --no-daemon :solr:core:cleanTest :solr:core:test --tests "org.apache.solr.response.TestJavaBinResponseWriter.testUUID" -Ptests.seed=5321CAFE >> "$OUT/uuid-alone.log" 2>&1 9>&-
echo "uuid-alone rc=$?" >> "$LOG"
cp $R/TEST-org.apache.solr.response.TestJavaBinResponseWriter.xml "$OUT/uuid-alone.xml" 2>/dev/null
$G --no-daemon :solr:core:test --tests "org.apache.solr.response.TestJavaBinResponseWriter.testExclusionResponse" --tests "org.apache.solr.response.TestJavaBinResponseWriter.testUUID" -Ptests.seed=5321CAFE --rerun-tasks >> "$OUT/uuid-pair.log" 2>&1 9>&-
echo "uuid-pair rc=$?" >> "$LOG"
cp $R/TEST-org.apache.solr.response.TestJavaBinResponseWriter.xml "$OUT/uuid-pair.xml" 2>/dev/null
cd ~/workspace/solr-clones/5321-cov || exit 2
echo "cov HEAD=$(git rev-parse HEAD) tracked=$(git status --porcelain | wc -l)" >> "$LOG"
pkill -f 'Gradle[D]aemon' 2>/dev/null; sleep 2
rm -f ~/.gradle/caches/journal-1/journal-1.lock
$G --no-daemon check -x test >> "$OUT/check4.log" 2>&1 9>&-
echo "rootcheck4 rc=$?" >> "$LOG"
cat "$LOG"
