#!/bin/bash
set -u
T=~/workspace/tools/5321-r2; C=~/workspace/solr-clones/5321-r2
SUM=$T/runs/summary.txt; : > $SUM
cd $C
{
  flock 9
  pkill -f "Gradle[Daemon]" 2>/dev/null; sleep 1; rm -f ~/.gradle/caches/journal-1/journal-1.lock
  echo "== LEG A full three classes seed 5321CAFE $(date -Is)" | tee -a $SUM
  timeout 2400 ~/workspace/tools/solr-gradle.sh :solr:core:cleanTest :solr:core:test --tests org.apache.solr.search.ReturnFieldsTest --tests org.apache.solr.response.TestCSVResponseWriter --tests org.apache.solr.response.TestJavaBinResponseWriter -Ptests.seed=5321CAFE --console=plain 9>&- > $T/runs/legA.log 2>&1
  echo "legA rc=$?" | tee -a $SUM
  mkdir -p $T/runs/legA-xml
  cp solr/core/build/test-results/test/TEST-org.apache.solr.search.ReturnFieldsTest.xml solr/core/build/test-results/test/TEST-org.apache.solr.response.TestCSVResponseWriter.xml solr/core/build/test-results/test/TEST-org.apache.solr.response.TestJavaBinResponseWriter.xml $T/runs/legA-xml/ 2>/dev/null || echo "XML MISSING" | tee -a $SUM
  echo "== LEG B two-method combination $(date -Is)" | tee -a $SUM
  rm -rf solr/core/build/test-results/test solr/core/build/reports/tests/test
  timeout 1200 ~/workspace/tools/solr-gradle.sh :solr:core:test --tests "org.apache.solr.response.TestJavaBinResponseWriter.testExclusionResponse" --tests "org.apache.solr.response.TestJavaBinResponseWriter.testUUID" -Ptests.seed=5321CAFE --console=plain 9>&- > $T/runs/legB.log 2>&1
  echo "legB rc=$?" | tee -a $SUM
  cp solr/core/build/test-results/test/TEST-org.apache.solr.response.TestJavaBinResponseWriter.xml $T/runs/legB.xml 2>/dev/null || echo "XML MISSING" | tee -a $SUM
  echo "== LEG C root tidy $(date -Is)" | tee -a $SUM
  timeout 1200 ~/workspace/tools/solr-gradle.sh tidy --console=plain 9>&- > $T/runs/legC.log 2>&1
  echo "legC rc=$? tracked changes after tidy: $(git status --porcelain | wc -l)" | tee -a $SUM
  git status --porcelain >> $SUM
  echo "== LEG D root check -x test $(date -Is)" | tee -a $SUM
  pkill -f "Gradle[Daemon]" 2>/dev/null; sleep 1; rm -f ~/.gradle/caches/journal-1/journal-1.lock
  timeout 3600 ~/workspace/tools/solr-gradle.sh check -x test --console=plain 9>&- > $T/runs/legD.log 2>&1
  echo "legD rc=$?" | tee -a $SUM
  grep -E "BUILD (SUCCESSFUL|FAILED)" $T/runs/legD.log | tail -1 | tee -a $SUM
} 9>~/workspace/tools/.solr-test-queue.lock
echo "GATE LEGS A-D DONE $(date -Is)" | tee -a $SUM
