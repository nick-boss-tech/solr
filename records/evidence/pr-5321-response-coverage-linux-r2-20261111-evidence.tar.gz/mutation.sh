#!/bin/bash
set -u
T=~/workspace/tools/5321-r2; SUM=$T/runs/summary.txt
C=~/workspace/solr-clones/5321-r2-mut
rm -rf "$C"; cp -a ~/workspace/solr-clones/5321-r2 "$C" 2>/dev/null || { mkdir -p "$C"; cd ~/workspace/solr-clones/5321-r2 && git archive HEAD | tar -x -C "$C"; cp gradle.properties "$C"/; }
cd "$C"
echo "mutclone HEAD=$(git rev-parse HEAD 2>/dev/null || echo archive-copy)" | tee -a $SUM
F=$(grep -rl "boolean isExcluded" solr/core/src/java/org/apache/solr/search/SolrReturnFields.java)
echo "target file: $F" | tee -a $SUM
grep -n "isExcluded" solr/core/src/java/org/apache/solr/search/SolrReturnFields.java | head -5 | tee -a $SUM
python3 - <<'PYEOF'
import re
p = 'solr/core/src/java/org/apache/solr/search/SolrReturnFields.java'
s = open(p).read()
m = re.search(r'(boolean isExcluded\(String fieldName\) \{\n)(\s*)', s)
assert m, 'method not found'
s2 = s[:m.end()] + m.group(2) + 'if (true) return false; // MUTATION\n' + s[m.end():]
open(p, 'w').write(s2)
print('mutation inserted')
PYEOF
git diff > $T/runs/mutation.diff 2>/dev/null || diff /dev/null /dev/null
cat $T/runs/mutation.diff | head -20
{
  flock 9
  pkill -f "Gradle[Daemon]" 2>/dev/null; sleep 1; rm -f ~/.gradle/caches/journal-1/journal-1.lock
  i=0
  for M in "org.apache.solr.search.ReturnFieldsTest.testExclusionResponses" "org.apache.solr.response.TestCSVResponseWriter.testExclusionResponse" "org.apache.solr.response.TestJavaBinResponseWriter.testExclusionResponse"; do
    i=$((i+1))
    rm -rf solr/core/build/test-results/test solr/core/build/reports/tests/test
    timeout 1200 ~/workspace/tools/solr-gradle.sh :solr:core:test --tests "$M" -Ptests.seed=5321CAFE --console=plain 9>&- > $T/runs/mut$i.log 2>&1
    echo "mut$i $M rc=$?" | tee -a $SUM
    CLS=${M%.*}; cp solr/core/build/test-results/test/TEST-$CLS.xml $T/runs/mut$i.xml 2>/dev/null || echo "mut$i XML MISSING" | tee -a $SUM
  done
  echo "== restore and verify" | tee -a $SUM
  git checkout -- solr/core/src/java/org/apache/solr/search/SolrReturnFields.java 2>/dev/null || python3 -c "
s=open('solr/core/src/java/org/apache/solr/search/SolrReturnFields.java').read()
s=s.replace('if (true) return false; // MUTATION\n','')
open('solr/core/src/java/org/apache/solr/search/SolrReturnFields.java','w').write(s)
print('mutation removed by string replace')"
  grep -c "MUTATION" solr/core/src/java/org/apache/solr/search/SolrReturnFields.java | tee -a $SUM
  rm -rf solr/core/build/test-results/test solr/core/build/reports/tests/test
  timeout 1800 ~/workspace/tools/solr-gradle.sh :solr:core:test --tests org.apache.solr.search.ReturnFieldsTest --tests org.apache.solr.response.TestCSVResponseWriter --tests org.apache.solr.response.TestJavaBinResponseWriter -Ptests.seed=5321CAFE --console=plain 9>&- > $T/runs/mut-restore.log 2>&1
  echo "restore-run rc=$?" | tee -a $SUM
  mkdir -p $T/runs/mut-restore-xml; cp solr/core/build/test-results/test/TEST-*.xml $T/runs/mut-restore-xml/ 2>/dev/null
} 9>~/workspace/tools/.solr-test-queue.lock
echo "MUTATION LEG DONE $(date -Is)" | tee -a $SUM
