#!/bin/bash
set -u
T=~/workspace/tools/5321-r2; SUM=$T/runs/summary.txt
C=~/workspace/solr-clones/5321-r2-mut
cd "$C"
python3 - <<'PYEOF'
p = 'solr/core/src/java/org/apache/solr/search/SolrReturnFields.java'
s = open(p).read()
old = """  private boolean isExcluded(String field) {
    if (excludedFields.contains(field)) {"""
new = """  private boolean isExcluded(String field) {
    if (true) return false; // MUTATION
    if (excludedFields.contains(field)) {"""
assert old in s and 'MUTATION' not in s
open(p, 'w').write(s.replace(old, new))
print('mutation inserted v2')
PYEOF
git diff > $T/runs/mutation.diff; cat $T/runs/mutation.diff
{
  flock 9
  pkill -f "Gradle[Daemon]" 2>/dev/null; sleep 1; rm -f ~/.gradle/caches/journal-1/journal-1.lock
  i=0
  for M in "org.apache.solr.search.ReturnFieldsTest.testExclusionResponses" "org.apache.solr.response.TestCSVResponseWriter.testExclusionResponse" "org.apache.solr.response.TestJavaBinResponseWriter.testExclusionResponse"; do
    i=$((i+1))
    rm -rf solr/core/build/test-results/test solr/core/build/reports/tests/test
    timeout 1200 ~/workspace/tools/solr-gradle.sh :solr:core:test --tests "$M" -Ptests.seed=5321CAFE --console=plain 9>&- > $T/runs/mutv2-$i.log 2>&1
    echo "mutv2-$i $M rc=$?" | tee -a $SUM
    CLS=${M%.*}; cp solr/core/build/test-results/test/TEST-$CLS.xml $T/runs/mutv2-$i.xml 2>/dev/null || echo "mutv2-$i XML MISSING" | tee -a $SUM
  done
  git checkout -- solr/core/src/java/org/apache/solr/search/SolrReturnFields.java
  echo "MUTATION count after restore: $(grep -c MUTATION solr/core/src/java/org/apache/solr/search/SolrReturnFields.java)" | tee -a $SUM
  rm -rf solr/core/build/test-results/test solr/core/build/reports/tests/test
  timeout 1800 ~/workspace/tools/solr-gradle.sh :solr:core:test --tests org.apache.solr.search.ReturnFieldsTest --tests org.apache.solr.response.TestCSVResponseWriter --tests org.apache.solr.response.TestJavaBinResponseWriter -Ptests.seed=5321CAFE --console=plain 9>&- > $T/runs/mutv2-restore.log 2>&1
  echo "restore-run rc=$?" | tee -a $SUM
  mkdir -p $T/runs/mutv2-restore-xml; cp solr/core/build/test-results/test/TEST-*.xml $T/runs/mutv2-restore-xml/ 2>/dev/null
} 9>~/workspace/tools/.solr-test-queue.lock
echo "MUTATION V2 DONE $(date -Is)" | tee -a $SUM
