#!/bin/bash
set -u
T=~/workspace/tools/5328-r2; SUM=$T/runs/summary.txt
FB=~/workspace/solr-clones/5328-r2-fb; cd $FB
GDIR=/home/hatch/workspace/solr-clones/5328-r2/.git
git --git-dir=$GDIR show fc65261419c7a4890510e50d9b93163268d1d853:solr/core/src/test-files/solr/collection1/conf/schema-densevector-raw-rtg.xml > solr/core/src/test-files/solr/collection1/conf/schema-densevector-raw-rtg.xml
echo "FB2 overlay status:" | tee -a $SUM; git status --porcelain | tee -a $SUM
wc -l solr/core/src/test-files/solr/collection1/conf/schema-densevector-raw-rtg.xml | tee -a $SUM
{
  flock 9
  pkill -f "Gradle[Daemon]" 2>/dev/null; sleep 1; rm -f ~/.gradle/caches/journal-1/journal-1.lock
  find solr -path "*build/test-results/test" -name "TEST-*.xml" -delete 2>/dev/null
  timeout 2400 ~/workspace/tools/solr-gradle.sh :solr:core:test --tests "org.apache.solr.schema.DenseVectorRetrievalTest.rawFloatVectorCopyTargetIsFilteredFromRealTimeGet" --tests "org.apache.solr.schema.DenseVectorRetrievalTest.rawByteVectorCopyTargetIsFilteredFromRealTimeGet" -Ptests.seed=5328A11 --console=plain 9>&- > $T/runs/failbefore2.log 2>&1
  echo "failbefore2 rc=$?" | tee -a $SUM
  cp solr/core/build/test-results/test/TEST-org.apache.solr.schema.DenseVectorRetrievalTest.xml $T/runs/failbefore2.xml 2>/dev/null || echo "FB2 XML MISSING" | tee -a $SUM
} 9>~/workspace/tools/.solr-test-queue.lock
echo "FB2 DONE $(date -Is)" | tee -a $SUM
