#!/bin/bash
set -u
T=~/workspace/tools/5328-r2; C=~/workspace/solr-clones/5328-r2; SUM=$T/runs/summary.txt; : > $SUM
G=~/workspace/tools/solr-gradle.sh
cd $C
mkdir -p solr/webapp/build/ui-download
curl -sL --max-time 300 -o solr/webapp/build/ui-download/solr-ui-wasm-473a55ef64a9a1605e00eb6c1c386887d4cb7dac.zip https://nightlies.apache.org/solr/ui/wasm/473a55ef64a9a1605e00eb6c1c386887d4cb7dac/solr-ui-wasm.zip
echo "wasm sha: $(sha256sum solr/webapp/build/ui-download/solr-ui-wasm-473a55ef64a9a1605e00eb6c1c386887d4cb7dac.zip | cut -d' ' -f1)" | tee -a $SUM
{
  flock 9
  pkill -f "Gradle[Daemon]" 2>/dev/null; sleep 1; rm -f ~/.gradle/caches/journal-1/journal-1.lock
  find solr -path "*build/test-results/test" -name "TEST-*.xml" -delete 2>/dev/null
  timeout 2400 $G :solr:core:test --tests org.apache.solr.schema.DenseVectorRetrievalTest -Ptests.seed=5328A11 --console=plain 9>&- > $T/runs/retrieval.log 2>&1
  echo "retrieval rc=$?" | tee -a $SUM
  mkdir -p $T/runs/retrieval-xml; cp solr/core/build/test-results/test/TEST-org.apache.solr.schema.DenseVectorRetrievalTest.xml $T/runs/retrieval-xml/ 2>/dev/null || echo "retrieval XML MISSING" | tee -a $SUM
  find solr -path "*build/test-results/test" -name "TEST-*.xml" -delete 2>/dev/null
  timeout 2400 $G :solr:core:test --tests org.apache.solr.schema.DenseVectorFieldTest -Ptests.seed=5328A11 --console=plain 9>&- > $T/runs/field.log 2>&1
  echo "field rc=$?" | tee -a $SUM
  mkdir -p $T/runs/field-xml; cp solr/core/build/test-results/test/TEST-org.apache.solr.schema.DenseVectorFieldTest.xml $T/runs/field-xml/ 2>/dev/null || echo "field XML MISSING" | tee -a $SUM
  timeout 1200 $G tidy --console=plain 9>&- > $T/runs/tidy.log 2>&1
  echo "tidy rc=$? tracked changes: $(git status --porcelain | grep -v '^??' | wc -l)" | tee -a $SUM
  git status --porcelain | grep -v '^??' >> $SUM
  pkill -f "Gradle[Daemon]" 2>/dev/null; sleep 1; rm -f ~/.gradle/caches/journal-1/journal-1.lock
  timeout 3600 $G check -x test --console=plain 9>&- > $T/runs/check.log 2>&1
  echo "check rc=$?" | tee -a $SUM
  grep -E "BUILD (SUCCESSFUL|FAILED)" $T/runs/check.log | tail -1 | tee -a $SUM
} 9>~/workspace/tools/.solr-test-queue.lock
echo "MAIN LEGS DONE $(date -Is)" | tee -a $SUM
