#!/bin/bash
set -u
T=~/workspace/tools/5328-r2; C=~/workspace/solr-clones/5328-r2; SUM=$T/runs/summary.txt
G=~/workspace/tools/solr-gradle.sh
cd $C
echo "rest HEAD=$(git rev-parse HEAD) modified=$(git status --porcelain | grep -v '^??' | wc -l)" | tee -a $SUM
ls solr/webapp/build/ui-download/ | tee -a $SUM
{
  flock 9
  pkill -f "Gradle[Daemon]" 2>/dev/null; sleep 1; rm -f ~/.gradle/caches/journal-1/journal-1.lock
  timeout 3600 $G check -x test --console=plain 9>&- > $T/runs/check.log 2>&1
  echo "check rc=$?" | tee -a $SUM
  grep -E "BUILD (SUCCESSFUL|FAILED)" $T/runs/check.log | tail -1 | tee -a $SUM
} 9>~/workspace/tools/.solr-test-queue.lock
# fail-before: parent + test/schema overlay only
FB=~/workspace/solr-clones/5328-r2-fb
rm -rf "$FB"; mkdir -p "$FB"; cd "$FB"
git init -q .; git remote add origin https://github.com/nick-boss-tech/solr.git
for attempt in 1 2 3 4 5; do git fetch -q --depth 40 origin c295e8c855d35c9edcf0fcf75de04d2f24803db6 && break; sleep 5; done
git checkout -q c295e8c855d35c9edcf0fcf75de04d2f24803db6
echo "FB HEAD=$(git rev-parse HEAD)" | tee -a $SUM
GDIR=/home/hatch/workspace/solr-clones/5328-r2/.git
git --git-dir=$GDIR show fc65261419c7a4890510e50d9b93163268d1d853:solr/core/src/test/org/apache/solr/schema/DenseVectorRetrievalTest.java > solr/core/src/test/org/apache/solr/schema/DenseVectorRetrievalTest.java
git --git-dir=$GDIR show fc65261419c7a4890510e50d9b93163268d1d853:solr/core/src/test/resources/solr/collection1/conf/schema-densevector-raw-rtg.xml > solr/core/src/test/resources/solr/collection1/conf/schema-densevector-raw-rtg.xml 2>/dev/null || find solr -name "schema-densevector-raw-rtg.xml" | tee -a $SUM
echo "overlay status:" | tee -a $SUM; git status --porcelain | tee -a $SUM
cp ~/workspace/solr/gradle.properties .
{
  flock 9
  pkill -f "Gradle[Daemon]" 2>/dev/null; sleep 1; rm -f ~/.gradle/caches/journal-1/journal-1.lock
  find solr -path "*build/test-results/test" -name "TEST-*.xml" -delete 2>/dev/null
  timeout 2400 $G :solr:core:test --tests "org.apache.solr.schema.DenseVectorRetrievalTest.rawFloatVectorCopyTargetIsFilteredFromRealTimeGet" --tests "org.apache.solr.schema.DenseVectorRetrievalTest.rawByteVectorCopyTargetIsFilteredFromRealTimeGet" -Ptests.seed=5328A11 --console=plain 9>&- > $T/runs/failbefore.log 2>&1
  echo "failbefore rc=$?" | tee -a $SUM
  cp solr/core/build/test-results/test/TEST-org.apache.solr.schema.DenseVectorRetrievalTest.xml $T/runs/failbefore.xml 2>/dev/null || echo "FB XML MISSING" | tee -a $SUM
} 9>~/workspace/tools/.solr-test-queue.lock
echo "REST DONE $(date -Is)" | tee -a $SUM
