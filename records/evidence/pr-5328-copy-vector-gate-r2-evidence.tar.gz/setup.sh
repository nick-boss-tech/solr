#!/bin/bash
set -u
T=~/workspace/tools/5328-r2; LOG=$T/runs/setup.log; : > $LOG
C=~/workspace/solr-clones/5328-r2
rm -rf "$C"; mkdir -p "$C"; cd "$C"
git init -q . >> $LOG 2>&1
git remote add origin https://github.com/nick-boss-tech/solr.git
for attempt in 1 2 3 4 5; do git fetch -q --depth 40 origin pr-5328-raw-copy-target >> $LOG 2>&1 && break; sleep 5; done
git checkout -q fc65261419c7a4890510e50d9b93163268d1d853 >> $LOG 2>&1
echo "HEAD=$(git rev-parse HEAD) modified=$(git status --porcelain | wc -l)" >> $LOG
git fetch -q --depth 40 origin c295e8c855d35c9edcf0fcf75de04d2f24803db6 >> $LOG 2>&1
echo "parent present: $(git cat-file -t c295e8c855d35c9edcf0fcf75de04d2f24803db6 2>&1)" >> $LOG
echo "--- diff parent..head (stat)" >> $LOG
git diff --stat c295e8c855d35c9edcf0fcf75de04d2f24803db6 HEAD >> $LOG 2>&1
echo "--- log parent..head" >> $LOG
git log --oneline c295e8c855d35c9edcf0fcf75de04d2f24803db6..HEAD >> $LOG 2>&1
echo "--- new test methods in DenseVectorRetrievalTest" >> $LOG
grep -rn "rawFloatVectorCopyTargetIsFiltered\|rawByteVectorCopyTargetIsFiltered" solr/core/src/test/org/apache/solr/schema/DenseVectorRetrievalTest.java >> $LOG 2>&1
grep -c "public void test" solr/core/src/test/org/apache/solr/schema/DenseVectorRetrievalTest.java >> $LOG 2>&1
grep "solr.ui" ~/workspace/solr/gradle.properties >> $LOG 2>&1
cp ~/workspace/solr/gradle.properties .
echo "SETUP DONE" >> $LOG; cat $LOG
