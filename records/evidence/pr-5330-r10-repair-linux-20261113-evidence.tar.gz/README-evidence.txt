PR 5330 r10-repair Linux gate evidence (vm6 host)
Job: pr-5330-r10-repair-linux-20261113
Head: e5117658841ca30d4b888f311754c8818f06dbf3 (fork branch pr-5330-test-fix-20261113, verified by git ls-remote at claim)
Repair commit: e5117658 "SOLR-18656: Repair stalled stream regression tests", parent 13522945 (the r9 head)
Contributor parent: eedcb534aca361be5bad5c56f1b2d3002eea855f (ancestor of head)
Seed: 5330 (r9 recorded seed) and 5330C0DE for every test leg
Verdict: FAILED (unresolved material concern: root check -x test fails on
  :solr:core:forbiddenApisTest)

== Head verification (gate requirement 1)
Isolated clean worktrees at e5117658 (gate-5330-r10-head for positive/tidy/check; gate-5330-r10-mut for mutation legs), rev-parse HEAD equals the offered head, zero modifications at setup. Fork branch pr-5330-test-fix-20261113 verified == gate head by git ls-remote at claim time. Repair commit has parent 13522945 (r9 head); contributor parent eedcb534 is an ancestor. Round-2 Linux job (pr-5330-regression-r2-linux-20261113) reconciled as disclaimed (phone-agent release) and superseded; no overlapping active work.

== Positive legs (gate requirement 2)
Leg 1: :solr:core:cleanTest :solr:core:test --tests org.apache.solr.update.SolrCmdDistributorTest -Ptests.seed=5330
  rc=0 (BUILD SUCCESSFUL in 11m 5s). 10 tests, 0 failures, 0 errors, 0 skipped.
  Executed: test, testStallKeepsErrorsFromOtherNodes, testFinishKeepsErrorsAfterStall,
  testRetryReachesServerWhileAnotherClientStalls, testStalledClientIgnoresLateCallbacks,
  testSuccessfulResponseKeepsReplicationFactorAccounting, testRealRunnerCallbacksDoNotNeedClientMonitor,
  testErrorCallbacksDoNotClassifyRetries, testConcurrentErrorDrainRetainsEveryError,
  testStallReportedWhileResponseBodyIsBlocked.
Leg 2: same command -Ptests.seed=5330C0DE
  rc=0. 10 tests, 0 failures, 0 errors, 0 skipped (same 10 methods).

== HTTP/1.1 fixture proof (gate requirement 2)
Leg 3: testRealRunnerCallbacksDoNotNeedClientMonitor -Ptests.seed=5330
  rc=0. 1 test, 0 failures. The test loops success=true/false and asserts both the
  HTTP 200 success-callback latch (successReported) and the HTTP 503 intended-node
  error callback (statusCode == 503 in errors). newHttp1UpdateShardHandler() sets
  solr.http1=true before constructing the UpdateShardHandler, so the raw-socket
  fixture receives HTTP/1.1 (consumeHttpRequest requires "POST " request line).
Leg 4: testRealRunnerCallbacksDoNotNeedClientMonitor -Ptests.seed=5330C0DE
  rc=0. 1 test, 0 failures.

== Tidy leg (gate requirement 2)
Tidy: ./gradlew tidy at head e5117658. rc=0 (BUILD SUCCESSFUL). Post-tidy tracked
changes: 0 — the head is spotless-clean (the r10 repair applied the r9 spotless diff).

== Check leg (gate requirement 2) - FAILED
./gradlew check -x test -Prefguide.include=false at head e5117658. rc=1
(BUILD FAILED in 5m34s). Failing task :solr:core:forbiddenApisTest: 3 forbidden
API invocations in SolrCmdDistributorTest.java —
  line 718:  Executors.newSingleThreadExecutor()  (blame 1712a7dcbdd, Nick Shanin 2026-11-13)
  line 944:  Executors.newSingleThreadExecutor()  (blame 04c5746d177, Nick Shanin 2026-11-13)
  line 1002: Executors.newFixedThreadPool(2)      (blame 6ad35b2d9be, Nick Shanin 2026-11-13)
All three commit origins are ancestors of both the r9 head (13522945de) and this r10
head; none is introduced by the repair commit e5117658 (its test diff is HTTP/1.1
fixture + spotless reformat only). Upstream main's SolrCmdDistributorTest.java has
zero such calls, so the fork introduced the forbidden executor usage. The r9 gate
could not reach forbiddenApisTest because compile failed first; this is the first
clean run of root check -x test on the branch. Deterministic static analysis
(de.thetaphi.forbiddenapis on compiled classes), not environment, run-shape,
dispatch or seed-dependent. NOT covered by the failure atlas classes 2-7.
Classified per decision-ladder rung 1 (code + git history: git blame + parent
diffs + upstream comparison). Material defect: the head does not pass root check.
== Mutation legs (gate requirement 3) - carried-forward fail-before proofs
Each mutation reverts exactly one load-bearing production change at the exact r10 head
(e5117658) in the isolated mutation worktree (git diff SHA-256 recorded per leg). Each
matching focused test must FAIL behaviorally (AssertionError / expected-vs-actual); compile
failures, skips, setup errors and unrelated timeouts are not proof. Single method runs,
seed 5330, cleanTest per leg. Worktree restored to zero tracked changes after each leg.
Leg 1 drain_atomicity: remove outer synchronized (errors) in drainErrors() (diff SHA-256
  bb977e1d598fd38c1cc0dd46d67c09d283e57933d515cd6e1904dad9314aad4e).
  compile rc=0. testConcurrentErrorDrainRetainsEveryError FAILED behaviorally:
  java.lang.AssertionError expected:<2> but was:<1> (BUILD FAILED in 3m26s).
Leg 2 onsuccess_fence_rf: remove the synchronized (callbackLock) { if (stalled) return;
  req.trackRequestResult(rfFromResp, true); } fence in onSuccess (diff SHA-256
  2753f9069861d81261852f979670ec064c17a72a6e33cc9f5437bdd508114b3a).
  compile rc=0. testStallReportedWhileResponseBodyIsBlocked FAILED behaviorally:
  java.lang.AssertionError expected:<1> but was:<2> (BUILD FAILED in 2m4s).
Leg 3 handleerror_fence: remove the synchronized (callbackLock) { if (stalled) return; }
  fence in handleError (diff SHA-256 c94f4805f4370d25c17cb379650658b84b55d0a91d56f2fe469ebb79ecf44e3a).
  compile rc=0. testStalledClientIgnoresLateCallbacks FAILED behaviorally:
  java.lang.AssertionError expected:<1> but was:<2> (BUILD FAILED in 1m57s).
Leg 4 blockanddo_rethrow: remove the if (failure != null) { throw failure; } in
  blockAndDoRetries (SolrCmdDistributor.java) (diff SHA-256
  0bbcc6c87a2f4695af0be0f6cbcd21d36b9d8d7bb6dfa1c1169d48c73f31f030).
  compile rc=0. testStallKeepsErrorsFromOtherNodes FAILED behaviorally:
  junit.framework.AssertionFailedError "Expected exception IOException but no
  exception was thrown" at assertStallKeepsErrorsFromOtherNodes line 1100
  (BUILD FAILED in 2m21s).
Leg 5 retry_classify_once: re-add the retry decision + RF tracking in recordError
  (if (!req.shouldRetry(error)) { req.trackRequestResult(null, null, false); })
  so a callback classifies a retry (StreamingSolrClients.java) (diff SHA-256
  00db482b42468e4026f5b9b986d0187123f820dd390affab57ce30dfa5fd89ac).
  compile rc=0. testErrorCallbacksDoNotClassifyRetries FAILED behaviorally:
  java.lang.AssertionError "Callbacks must leave retry decisions to the
  distributor" expected:<0> but was:<2> (BUILD FAILED).
