# PR-5330 r9 — atomic-drain fail-before mutation

Target: `StreamingSolrClients.drainErrors()`. The gate requirement is to remove
**only the outer `synchronized (errors)` block**, retain the package-private
injection constructor and the test unchanged, and show the deterministic test
loses the concurrent error.

## Exact mutation diff (applied on the disposable compile-fixed proof worktree)

```diff
--- a/solr/core/src/java/org/apache/solr/update/StreamingSolrClients.java
+++ b/solr/core/src/java/org/apache/solr/update/StreamingSolrClients.java
@@ -69,8 +69,7 @@ public class StreamingSolrClients {
   public List<SolrError> drainErrors() {
-    synchronized (errors) {
-      List<SolrError> result = new ArrayList<>(errors);
-      errors.clear();
-      return result;
-    }
+    List<SolrError> result = new ArrayList<>(errors);
+    errors.clear();
+    return result;
   }
```

The package-private injection constructor
`StreamingSolrClients(UpdateShardHandler, List<SolrError>)` is retained.
`SolrCmdDistributorTest.java` is byte-identical to the r9 head (SHA-256
`cd66d9286eedd0712ef14442d780a51fa1bd554b2f4b04b32d9d7756c75f044e`, 0 diff).

The mutation runs in the disposable proof worktree, which already carries the
minimal compile fix (base `ConcurrentUpdateBaseSolrClient` map/local/loop types,
4-line diff). The mutation is applied **on top** of the compile fix, so the only
delta versus the proof state is the drainErrors change.

## Expected deterministic behavior

Test `testConcurrentErrorDrainRetainsEveryError` uses an `AbstractList` whose
`clear()` pauses (latch `clearReached`, then awaits `allowClear`). The drain
thread snapshots `errors` (reads `[before]`), then calls `clear()` and pauses.

- **With the outer `synchronized (errors)` (head behavior, pass):** the drain
  thread holds the `errors` monitor across snapshot + clear. The writer thread's
  `errors.add(concurrent)` blocks until the monitor is released after the drain
  completes, so `concurrent` lands after the clear. `drainErrors()` #1 returns
  `[before]`; `drainErrors()` #2 returns `[concurrent]`; `collected` size == 2
  and contains both -> `assertEquals(2, collected.size())` **passes**.
- **Without the outer sync (mutant):** snapshot and clear are each individually
  synchronized on `errors`, but not atomically together. The writer adds
  `concurrent` into the delegate while the drain thread is paused in `clear()`.
  The subsequent `delegate.clear()` clears both `before` and `concurrent`, so
  `drainErrors()` #1 returns `[before]` and `drainErrors()` #2 returns `[]`.
  `collected` size == 1 -> `assertEquals(2, collected.size())` **fails**,
  deterministically losing the concurrent error.

The latches (`clearReached`, `allowClear`) make the interleaving deterministic:
the writer is only started after the drain has reached `clear()`, and the drain
cannot proceed past `clear()` until `allowClear` is released, by which time the
writer has added `concurrent`.

## Observed JUnit result (seed 5330, run 2026-11-13)

`testConcurrentErrorDrainRetainsEveryError` **fails** with exactly the expected
deterministic assertion:

```
java.lang.AssertionError: expected:<2> but was:<1>
```

Single-method run (`:solr:core:cleanTest :solr:core:test
--tests org.apache.solr.update.SolrCmdDistributorTest.testConcurrentErrorDrainRetainsEveryError
-Ptests.seed=5330`): `tests=1 failures=1 errors=0 skipped=0`. The concurrent
error is lost at the `assertEquals(2, collected.size())` assertion (line 976).
The package-private injection constructor was retained; the test file was
unchanged from the r9 head (SHA-256
`cd66d9286eedd0712ef14442d780a51fa1bd554b2f4b04b32d9d7756c75f044e`, 0 diff).
This confirms the drain test specifically and deterministically discriminates
the atomic-drain race.

The mutation was applied on top of the compile-fixed proof tree; after the run
the compile-fixed `drainErrors` (outer `synchronized (errors)` intact) was
restored (evidence: `mutation/drainErrors-before.txt`,
`mutation/StreamingSolrClients-compilefixed.java`, `mutation/mutation.diff`,
`mutation/TEST-org.apache.solr.update.SolrCmdDistributorTest.xml`).
