# PR-5330 r9 Linux gate — compile defect root cause

Decisive finding: the r9 gate head **does not compile** on Linux JDK 21.

## Evidence

Two independent clean `:solr:core:compileJava` runs at the exact head
`13522945de6c9102ecdbe8efb821ed451e840216` both fail identically:

```
StreamingSolrClients.java:100: error: incompatible types:
  ConcurrentUpdateBaseSolrClient cannot be converted to
  ErrorReportingConcurrentUpdateSolrClient
```

- run 1 (focused leg seed 5330): `BUILD FAILED in 3m 30s`, `focused_rc=1`
- run 2 (determinism re-run): `BUILD FAILED in 1m 52s`, `compile_rc=1`

Both on a clean worktree at the exact head, `git status --porcelain` empty
before and after (0 tracked changes). No edits to the branch.

## Root cause

Commit `6476beb8debb` ("Fence callbacks after stalled streams") changed
`StreamingSolrClients`:

- map: `Map<String, ConcurrentUpdateBaseSolrClient>` -> `Map<String, ErrorReportingConcurrentUpdateSolrClient>`
- local: `ConcurrentUpdateBaseSolrClient client = solrClients.get(url)` -> `ErrorReportingConcurrentUpdateSolrClient client = solrClients.get(url)`
- loop: `for (ConcurrentUpdateBaseSolrClient client : solrClients.values())` -> `for (ErrorReportingConcurrentUpdateSolrClient client : solrClients.values())`

But the builder chain used to construct the client is:

```java
new ErrorReportingConcurrentUpdateSolrClient.Builder(...)
    .withDefaultCollection(defaultCore)
    .withQueueSize(100)          // -> returns base Builder (non-generic)
    .withThreadCount(runnerCount)
    .withExecutorService(updateExecutor)
    .alwaysStreamDeletes()
    .setPollQueueTime(pollQueueTimeMillis, MILLISECONDS)
    .build();                    // -> abstract base build(): ConcurrentUpdateBaseSolrClient
```

`ConcurrentUpdateBaseSolrClient.Builder` is a **non-generic** abstract class whose
fluent methods return the base `Builder`, and whose `build()` is
`public abstract ConcurrentUpdateBaseSolrClient build()`. The subclass
`ConcurrentUpdateJettySolrClient.Builder` overrides `build()` covariantly to
`ConcurrentUpdateJettySolrClient`, but after the first inherited chain call the
static type is the base `Builder`, so `.build()` resolves to the base method and
returns `ConcurrentUpdateBaseSolrClient`. Assigning that to the narrowed
`ErrorReportingConcurrentUpdateSolrClient` variable is a compile error.

Upstream `apache/solr` main keeps the base types (map + local + loop all
`ConcurrentUpdateBaseSolrClient`), so main compiles. The PR narrowed the types
in commit `6476beb8debb` without a self-type builder, introducing the defect.

## Why the Windows report did not catch it

The r9 Windows report says explicitly: "No Gradle, compilation or runtime tests
on Windows. Linux must validate fixture framing and deterministic mutant
failure." The Linux gate is the first place this compiles, and it fails.

## Minimal successor-style remediation (disposable proof)

Reverting the three type declarations to base `ConcurrentUpdateBaseSolrClient`
(cast to the concrete subtype only where `reportStall` is needed in
`blockUntilFinished`) makes `:solr:core:compileJava` succeed (rc=0), 4-line
diff, matching upstream main's structure. This is what a successor commit would
contain (plus the same change in the loop). The focused test run under this
remediation is being executed to show the 9 named tests otherwise pass.

## Consequence

The exact head cannot be positively gated: the first positive leg (compile /
focused test) fails. The r9 gate has **no clean verdict**. The drain mutation
and concurrent-verification legs are unmountable on the un-fixed head because
the module does not compile. The deterministic mutant failure for the atomic
drain requires a compiling tree; it is executed under the remediation to
preserve the discriminating evidence for the review agent.

Fix must land as a committed successor (e.g. `pr-5330-test-fix-...r10`) on the
fork; no public comments; no source edits to the contributor branch.

---

## Second finding (compiled proof run): HTTP/2 raw-socket fixture defect

Under the minimal compile fix, 9 of the 10 focused tests pass; the single
failure is `testRealRunnerCallbacksDoNotNeedClientMonitor`:

```
java.io.IOException: Unexpected request: PRI * HTTP/2.0
  at SolrCmdDistributorTest.consumeHttpRequest(SolrCmdDistributorTest.java:1151)
  at SolrCmdDistributorTest.testRealRunnerCallbacksDoNotNeedClientMonitor(SolrCmdDistributorTest.java:815)
```

### Root cause

`testRealRunnerCallbacksDoNotNeedClientMonitor` binds a real `ServerSocket`
(line 783), calls `client.request(update)` (line 812), then reads the raw
socket with `consumeHttpRequest` (line 815), which requires an HTTP/1.1 request
line starting with `POST `. But the client is an
`ErrorReportingConcurrentUpdateSolrClient` built on the update-only
`HttpJettySolrClient`, which by default uses the **HTTP/2 transport**:
`HttpSolrClient.Builder.defaultUseHttp1_1 = Boolean.getBoolean("solr.http1")`
= false unless `solr.http1=true` is set. The raw socket receives the HTTP/2
connection preface `PRI * HTTP/2.0` instead of an HTTP/1.1 request line, so
`consumeHttpRequest` throws deterministically.

The test neither sets `solr.http1` nor forces `useHttp1_1(true)` on the client,
and the test's `consumeHttpRequest` (and its response, `HTTP/1.1 ...` at line
825) only understands HTTP/1.1 framing.

The other two raw-`ServerSocket` tests
(`testRetryReachesServerWhileAnotherClientStalls` line 675,
`testStallReportedWhileResponseBodyIsBlocked` line 1089) only `accept()` and do
not read the request line, so the HTTP/2 preface never triggers a parse error —
only `testRealRunnerCallbacksDoNotNeedClientMonitor` reads the socket.

`upstream main` has no `testRealRunnerCallbacksDoNotNeedClientMonitor` (the
test is new in the PR), so this defect is introduced by the PR, not
environmental.

### Severity

This is the exact concern the gate record calls out ("raw socket consumes the
complete HTTP request with actual Jetty framing"). The raw-socket fixture does
not exercise HTTP/1.1 framing as intended; it deterministically receives HTTP/2
framing that the assertion rejects. A successor must force HTTP/1.1 for this
client (e.g. `useHttp1_1(true)` on the builder, or `solr.http1=true` scoped to
the test) or make `consumeHttpRequest` HTTP/2-aware.

### Reproduction

`./gradlew :solr:core:cleanTest :solr:core:test --tests
org.apache.solr.update.SolrCmdDistributorTest -Ptests.seed=5330` on the
compile-fixed proof worktree: 10 tests, 1 failed
(`testRealRunnerCallbacksDoNotNeedClientMonitor`, 208s total).

---

## Third finding (tidy leg): head test file is not spotless-clean

The tidy leg (`:solr:tidy`, runs `spotlessApply`) succeeded (rc=0) on the proof
tree, but `post_tidy_tracked_changes=2` — spotless rewrote
`SolrCmdDistributorTest.java` in addition to the 4-line compile fix. The test
file was byte-identical to the r9 head (SHA-256
`cd66d9286eedd0712ef14442d780a51fa1bd554b2f4b04b32d9d7756c75f044e`) before the
tidy, so the spotless reformat is a finding against the **head**, not against
the proof fix. The reformat is 2 hunks:

```
@@ -1036,7 +1036,8 @@
-  private void assertStallKeepsErrorsFromOtherNodes(boolean testOrderedOperations) throws Exception {
+  private void assertStallKeepsErrorsFromOtherNodes(boolean testOrderedOperations)
+      throws Exception {

@@ -1074,8 +1075,7 @@
-                streamingClients.getErrors().stream()
-                    .anyMatch(e -> failingNode.equals(e.req.node));
+                streamingClients.getErrors().stream().anyMatch(e -> failingNode.equals(e.req.node));
```

The head test file therefore fails `spotlessCheck`. A fail-before
`:solr:core:spotlessCheck` on the proof tree with the test reverted to exact
head bytes (compile fix retained in the java file only) is recorded at
`spotless/spotlesscheck.log` and is expected to name
`SolrCmdDistributorTest.java` as the violation. A successor commit must include
this spotless reformat of the test file (or the PR's formatting must be made
clean), and the r10 gate's tidy/check leg must then pass.

Evidence: `spotless/SolrCmdDistributorTest-tidy-fixed.java`,
`spotless/tidy-testfile.diff` (24 lines), `spotless/test-sha-after-revert.txt`.

