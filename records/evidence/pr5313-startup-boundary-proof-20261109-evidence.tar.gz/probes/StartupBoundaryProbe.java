package org.apache.solr.core;

import java.io.IOException;
import java.net.InetAddress;
import java.net.ServerSocket;
import java.net.Socket;
import java.net.SocketTimeoutException;
import java.nio.file.Files;
import java.nio.file.Path;
import java.util.Properties;
import java.util.concurrent.ConcurrentLinkedQueue;
import org.apache.solr.common.SolrException;

/**
 * Disposable boundary probe for the PR 5313 startup gate, leg 1. Unlike the round-two probe, this
 * class never touches EnvUtils or any NodeConfig member before the real {@code
 * NodeConfig.loadNodeConfig} call: the only work before that call is pure JDK setup (temp Solr
 * home, a silent loopback peer, and node properties carrying zkHost under its literal name, so no
 * Solr class is even initialized by a constant lookup). Class initialization ordering is observed
 * from the JVM's own class-init log.
 */
public final class StartupBoundaryProbe {
  private StartupBoundaryProbe() {}

  public static void main(String[] args) throws Exception {
    if (args.length != 2) {
      throw new IllegalArgumentException("usage: StartupBoundaryProbe <label> <expected-ms>");
    }
    String label = args[0];
    int expectedMillis = Integer.parseInt(args[1]);
    System.out.println("label=" + label);

    Path solrHome = Files.createTempDirectory("solr-5313-boundary-");
    Files.writeString(solrHome.resolve("solr.xml"), "<solr/>");
    try (BlackHole blackHole = new BlackHole()) {
      Properties props = new Properties();
      String zkHost = "127.0.0.1:" + blackHole.port();
      props.setProperty("zkHost", zkHost);
      System.out.println("explicit_zkHost=" + zkHost);
      System.out.println("PROBE_MARKER before-loadNodeConfig");

      long start = System.nanoTime();
      Throwable failure = null;
      try {
        NodeConfig.loadNodeConfig(solrHome, props);
      } catch (Throwable t) {
        failure = t;
      }
      long elapsedMillis = (System.nanoTime() - start) / 1_000_000;
      System.out.println("PROBE_MARKER after-loadNodeConfig");
      System.out.println("elapsed_ms=" + elapsedMillis);
      System.out.println(
          "failure="
              + (failure == null
                  ? "none"
                  : failure.getClass().getName() + ": " + failure.getMessage()));
      for (Throwable c = failure == null ? null : failure.getCause();
          c != null;
          c = c.getCause()) {
        System.out.println("cause=" + c.getClass().getName() + ": " + c.getMessage());
      }
      System.out.println("accepted_local_connections=" + blackHole.acceptedCount());

      if (!(failure instanceof SolrException)) {
        throw new AssertionError("expected NodeConfig ZooKeeper connection failure", failure);
      }
      if (failure.getMessage() == null
          || !failure.getMessage().contains("testing zookeeper connection")) {
        throw new AssertionError(
            "failure did not come from NodeConfig's ZooKeeper startup probe", failure);
      }
      if (blackHole.acceptedCount() < 1) {
        throw new AssertionError("the explicit local zkHost was not reached");
      }
      long lowerBound = Math.max(500, Math.round(expectedMillis * 0.75));
      long upperBound = expectedMillis + Math.max(5_000, expectedMillis / 2);
      if (elapsedMillis < lowerBound || elapsedMillis > upperBound) {
        throw new AssertionError(
            "startup did not wait within expected bounds: expected="
                + expectedMillis
                + "ms elapsed="
                + elapsedMillis
                + "ms bounds="
                + lowerBound
                + ".."
                + upperBound);
      }
      System.out.println("startup_boundary_probe=PASS");
    } finally {
      try (var paths = Files.walk(solrHome)) {
        paths.sorted((a, b) -> b.getNameCount() - a.getNameCount())
            .forEach(
                p -> {
                  try {
                    Files.deleteIfExists(p);
                  } catch (IOException e) {
                    throw new RuntimeException(e);
                  }
                });
      }
    }
    System.exit(0);
  }

  private static final class BlackHole implements AutoCloseable {
    private final ServerSocket server;
    private final ConcurrentLinkedQueue<Socket> sockets = new ConcurrentLinkedQueue<>();
    private volatile boolean closed;
    private final Thread acceptor;

    BlackHole() throws IOException {
      server = new ServerSocket(0, 16, InetAddress.getByName("127.0.0.1"));
      server.setSoTimeout(500);
      acceptor = new Thread(this::acceptForever, "solr-5313-boundary-blackhole");
      acceptor.setDaemon(true);
      acceptor.start();
    }

    int port() {
      return server.getLocalPort();
    }

    int acceptedCount() {
      return sockets.size();
    }

    private void acceptForever() {
      while (!closed) {
        try {
          sockets.add(server.accept());
        } catch (SocketTimeoutException ignored) {
          // Continue until the client times out or the probe is closed.
        } catch (IOException e) {
          if (!closed) {
            throw new RuntimeException(e);
          }
          return;
        }
      }
    }

    @Override
    public void close() throws IOException {
      closed = true;
      server.close();
      for (Socket socket : sockets) {
        socket.close();
      }
      try {
        acceptor.join(1_000);
      } catch (InterruptedException e) {
        Thread.currentThread().interrupt();
      }
    }
  }
}
