package org.apache.solr.core;

import java.io.IOException;
import java.io.InputStream;
import java.net.InetAddress;
import java.net.ServerSocket;
import java.net.Socket;
import java.net.SocketTimeoutException;
import java.nio.file.Files;
import java.nio.file.Path;
import java.util.ArrayList;
import java.util.List;
import java.util.Properties;
import java.util.concurrent.ConcurrentLinkedQueue;
import org.apache.solr.common.SolrException;

/**
 * Disposable wire probe for the PR 5313 startup gate, leg 2. A local accepting peer records the
 * exact bytes the real startup ZooKeeper client sends on connect, so the session-timeout field of
 * the outgoing ConnectRequest is observed directly instead of being inferred from elapsed time.
 * The peer never answers, so the time until {@code NodeConfig.loadNodeConfig} fails is the
 * separately measured connection wait against the same client.
 */
public final class StartupWireProbe {
  private StartupWireProbe() {}

  public static void main(String[] args) throws Exception {
    if (args.length != 2) {
      throw new IllegalArgumentException(
          "usage: StartupWireProbe <label> <expected-session-timeout-ms>");
    }
    String label = args[0];
    int expectedSessionTimeout = Integer.parseInt(args[1]);
    System.out.println("label=" + label);
    System.out.println("expected_session_timeout_ms=" + expectedSessionTimeout);

    Path solrHome = Files.createTempDirectory("solr-5313-wire-");
    Files.writeString(solrHome.resolve("solr.xml"), "<solr/>");
    try (RecordingPeer peer = new RecordingPeer()) {
      Properties props = new Properties();
      String zkHost = "127.0.0.1:" + peer.port();
      props.setProperty("zkHost", zkHost);
      System.out.println("explicit_zkHost=" + zkHost);

      long start = System.nanoTime();
      Throwable failure = null;
      try {
        NodeConfig.loadNodeConfig(solrHome, props);
      } catch (Throwable t) {
        failure = t;
      }
      long elapsedMillis = (System.nanoTime() - start) / 1_000_000;
      System.out.println("elapsed_ms=" + elapsedMillis);
      System.out.println(
          "failure="
              + (failure == null
                  ? "none"
                  : failure.getClass().getName() + ": " + failure.getMessage()));
      if (!(failure instanceof SolrException)
          || failure.getMessage() == null
          || !failure.getMessage().contains("testing zookeeper connection")) {
        throw new AssertionError("failure did not come from NodeConfig's startup probe", failure);
      }

      // Give any in-flight first packet a moment to be read, then report what was captured.
      Thread.sleep(500);
      List<byte[]> packets = peer.packets();
      System.out.println("accepted_local_connections=" + peer.acceptedCount());
      System.out.println("captured_packets=" + packets.size());
      if (packets.isEmpty()) {
        throw new AssertionError("no bytes captured from the startup client");
      }
      boolean sessionTimeoutObserved = false;
      for (int i = 0; i < packets.size(); i++) {
        byte[] p = packets.get(i);
        System.out.println("packet[" + i + "]_length=" + p.length);
        System.out.println("packet[" + i + "]_hex=" + hex(p));
        // ConnectRequest layout (ZooKeeper jute, big-endian): 4-byte packet length,
        // 8-byte protocolVersion, 8-byte lastZxidSeen, 4-byte timeOut (session timeout),
        // 8-byte sessionId, 4-byte password length + password, 1-byte readOnly.
        if (p.length >= 24) {
          int timeOutAt20 = readInt(p, 16);
          System.out.println("packet[" + i + "]_int_at_offset_16=" + timeOutAt20);
          if (timeOutAt20 == expectedSessionTimeout) {
            sessionTimeoutObserved = true;
          }
        }
        List<Integer> scan = new ArrayList<>();
        for (int off = 0; off + 4 <= p.length; off++) {
          if (readInt(p, off) == expectedSessionTimeout) {
            scan.add(off);
          }
        }
        System.out.println("packet[" + i + "]_offsets_matching_expected=" + scan);
      }
      if (!sessionTimeoutObserved) {
        throw new AssertionError(
            "session timeout "
                + expectedSessionTimeout
                + " not observed at the ConnectRequest timeOut offset");
      }
      System.out.println("startup_wire_probe=PASS");
    } finally {
      try (var paths = Files.walk(solrHome)) {
        paths.sorted((a, b) -> b.getNameCount() - a.getNameCount())
            .forEach(
                p -> {
                  try {
                    Files.deleteIfExists(p);
                  } catch (IOException e) {
                    throw new RuntimeException(e);
                  }
                });
      }
    }
    System.exit(0);
  }

  private static int readInt(byte[] b, int off) {
    return ((b[off] & 0xff) << 24)
        | ((b[off + 1] & 0xff) << 16)
        | ((b[off + 2] & 0xff) << 8)
        | (b[off + 3] & 0xff);
  }

  private static String hex(byte[] b) {
    StringBuilder sb = new StringBuilder(b.length * 2);
    for (byte v : b) {
      sb.append(Character.forDigit((v >> 4) & 0xf, 16));
      sb.append(Character.forDigit(v & 0xf, 16));
    }
    return sb.toString();
  }

  private static final class RecordingPeer implements AutoCloseable {
    private final ServerSocket server;
    private final ConcurrentLinkedQueue<Socket> sockets = new ConcurrentLinkedQueue<>();
    private final ConcurrentLinkedQueue<byte[]> packets = new ConcurrentLinkedQueue<>();
    private volatile boolean closed;
    private final Thread acceptor;

    RecordingPeer() throws IOException {
      server = new ServerSocket(0, 16, InetAddress.getByName("127.0.0.1"));
      server.setSoTimeout(500);
      acceptor = new Thread(this::acceptForever, "solr-5313-wire-peer");
      acceptor.setDaemon(true);
      acceptor.start();
    }

    int port() {
      return server.getLocalPort();
    }

    int acceptedCount() {
      return sockets.size();
    }

    List<byte[]> packets() {
      return new ArrayList<>(packets);
    }

    private void acceptForever() {
      while (!closed) {
        try {
          Socket socket = server.accept();
          sockets.add(socket);
          Thread reader = new Thread(() -> readPacket(socket), "solr-5313-wire-reader");
          reader.setDaemon(true);
          reader.start();
        } catch (SocketTimeoutException ignored) {
          // Continue until closed.
        } catch (IOException e) {
          if (!closed) {
            throw new RuntimeException(e);
          }
          return;
        }
      }
    }

    private void readPacket(Socket socket) {
      try {
        socket.setSoTimeout(120_000);
        InputStream in = socket.getInputStream();
        byte[] buffer = new byte[256];
        int total = 0;
        // The ConnectRequest is a single small write; read until the first chunk boundary
        // settles (short pause with no new bytes) or the buffer fills.
        long deadline = System.nanoTime() + 3_000_000_000L;
        while (total < buffer.length && System.nanoTime() < deadline) {
          try {
            socket.setSoTimeout(400);
            int n = in.read(buffer, total, buffer.length - total);
            if (n < 0) {
              break;
            }
            total += n;
            deadline = System.nanoTime() + 600_000_000L;
          } catch (SocketTimeoutException e) {
            if (total > 0) {
              break;
            }
          }
        }
        if (total > 0) {
          byte[] packet = new byte[total];
          System.arraycopy(buffer, 0, packet, 0, total);
          packets.add(packet);
        }
      } catch (IOException e) {
        // A reset while capturing is recorded by the absence of a packet, not hidden.
        System.out.println("reader_error=" + e);
      }
    }

    @Override
    public void close() throws IOException {
      closed = true;
      server.close();
      for (Socket socket : sockets) {
        socket.close();
      }
      try {
        acceptor.join(1_000);
      } catch (InterruptedException e) {
        Thread.currentThread().interrupt();
      }
    }
  }
}
