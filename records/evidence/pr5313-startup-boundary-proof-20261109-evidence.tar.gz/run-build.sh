#!/bin/bash
# PR 5313 boundary proof: build core test classes and harvest the probe classpath. Phone agent.
set -u
CLONE=~/workspace/solr-clones/5313-boundary
OUT=~/workspace/tools/gate-5313/runs
H=4be1ad602621d2af96565355dce3804ee4744aae
exec 9>~/workspace/tools/.solr-test-queue.lock
flock 9
pkill -f 'Gradle[D]aemon' 2>/dev/null; sleep 2
rm -f ~/.gradle/caches/journal-1/journal-1.lock
cd "$CLONE" || exit 2
[ "$(git rev-parse HEAD)" = "$H" ] || { echo "HEAD MISMATCH" > "$OUT/build.ABORT"; exit 3; }
cp ~/workspace/tools/gate-5313/prior/r2/probes/print-test-classpath.init.gradle ~/workspace/tools/gate-5313/print-test-classpath.init.gradle
echo "BUILD START $(date -u +%FT%TZ)" > "$OUT/build.log"
~/workspace/tools/solr-gradle.sh --no-daemon -q -I ~/workspace/tools/gate-5313/print-test-classpath.init.gradle :solr:core:compileTestJava :solr:core:printGateProbeClasspath >> "$OUT/build.log" 2>&1 9>&-
echo "build rc=$?" >> "$OUT/build.log"
grep '^GATE_PROBE_CP=' "$OUT/build.log" | sed 's/^GATE_PROBE_CP=//' > ~/workspace/tools/gate-5313/core-test.classpath
wc -c ~/workspace/tools/gate-5313/core-test.classpath >> "$OUT/build.log"
echo "BUILD END $(date -u +%FT%TZ)" >> "$OUT/build.log"
