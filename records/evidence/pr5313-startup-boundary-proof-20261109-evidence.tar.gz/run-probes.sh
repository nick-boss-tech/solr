#!/bin/bash
# PR 5313 boundary proof: compile probes and run all fresh-JVM cases. Phone agent.
set -u
G=~/workspace/tools/gate-5313
OUT=$G/runs
JAVA_HOME21=~/workspace/tools/jdk21/jdk-21.0.12.1+1
CP=$(cat $G/core-test.classpath)
# The harvested runtime classpath names module jars that a compile-only build never produced;
# the freshly compiled classes dirs carry the same content, so they go first.
CLONE=~/workspace/solr-clones/5313-boundary
for m in api solrj solrj-zookeeper solrj-streaming solrj-jetty; do
  CP="$CLONE/solr/$m/build/classes/java/main:$CLONE/solr/$m/build/resources/main:$CP"
done
mkdir -p $G/probes/classes
"$JAVA_HOME21/bin/javac" -cp "$CP" -d $G/probes/classes $G/probes/StartupBoundaryProbe.java $G/probes/StartupWireProbe.java > $OUT/probe-compile.log 2>&1
echo "compile rc=$?" >> $OUT/probe-compile.log
[ -f $G/probes/classes/org/apache/solr/core/StartupBoundaryProbe.class ] || { echo "COMPILE FAILED"; exit 1; }
PCP="$G/probes/classes:$CP"
run_case() {
  local name="$1"; shift
  local cmd=("$@")
  printf '%q ' "${cmd[@]}" > $OUT/$name.command; echo >> $OUT/$name.command
  echo "CASE $name START $(date -u +%FT%TZ)" > $OUT/$name.log
  timeout 150 "${cmd[@]}" >> $OUT/$name.log 2>&1
  echo "$name rc=$?" >> $OUT/$name.log
  echo "CASE $name END $(date -u +%FT%TZ)" >> $OUT/$name.log
}
J="$JAVA_HOME21/bin/java"
# Leg 1: initialization-ordering probes (no pre-initialization of EnvUtils or the helper).
run_case 10-order-sysprop env -u SOLR_WAIT_FOR_ZK "$J" -Djava.net.preferIPv4Stack=true -DwaitForZk=1 -verbose:class -Xlog:class+init=info -cp "$PCP" org.apache.solr.core.StartupBoundaryProbe sysprop-waitForZk 1000
run_case 11-order-env env SOLR_WAIT_FOR_ZK=1 "$J" -Djava.net.preferIPv4Stack=true -verbose:class -Xlog:class+init=info -cp "$PCP" org.apache.solr.core.StartupBoundaryProbe env-SOLR_WAIT_FOR_ZK 1000
run_case 12-order-modern env -u SOLR_WAIT_FOR_ZK "$J" -Djava.net.preferIPv4Stack=true -Dsolr.cloud.wait.for.zk.seconds=5 -DwaitForZk=1 -verbose:class -Xlog:class+init=info -cp "$PCP" org.apache.solr.core.StartupBoundaryProbe modern-wins 5000
run_case 13-order-alias env -u SOLR_WAIT_FOR_ZK "$J" -Djava.net.preferIPv4Stack=true -Dsolr.wait.for.zk=1 -DwaitForZk=5 -verbose:class -Xlog:class+init=info -cp "$PCP" org.apache.solr.core.StartupBoundaryProbe alias-order 1000
# Leg 2: wire observation of the ConnectRequest session timeout + connection wait.
run_case 20-wire-fallback env -u SOLR_WAIT_FOR_ZK "$J" -Djava.net.preferIPv4Stack=true -Dsolr.zookeeper.client.timeout=30001 -cp "$PCP" org.apache.solr.core.StartupWireProbe fallback-30001 30001
run_case 21-wire-override env -u SOLR_WAIT_FOR_ZK "$J" -Djava.net.preferIPv4Stack=true -Dsolr.zookeeper.client.timeout=30001 -Dsolr.cloud.wait.for.zk.seconds=2 -cp "$PCP" org.apache.solr.core.StartupWireProbe override-2s 2000
echo "ALL CASES DONE" >> $OUT/probe-compile.log
