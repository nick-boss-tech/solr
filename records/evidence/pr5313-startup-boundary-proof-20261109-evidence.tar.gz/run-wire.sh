#!/bin/bash
# PR 5313 boundary proof: rerun only the two wire cases with the corrected ConnectRequest offset. Phone agent.
set -u
G=~/workspace/tools/gate-5313
OUT=$G/runs
JAVA_HOME21=~/workspace/tools/jdk21/jdk-21.0.12.1+1
CP=$(cat $G/core-test.classpath)
CLONE=~/workspace/solr-clones/5313-boundary
for m in api solrj solrj-zookeeper solrj-streaming solrj-jetty; do
  CP="$CLONE/solr/$m/build/classes/java/main:$CLONE/solr/$m/build/resources/main:$CP"
done
"$JAVA_HOME21/bin/javac" -cp "$CP" -d $G/probes/classes $G/probes/StartupWireProbe.java > $OUT/wire-recompile.log 2>&1
echo "recompile rc=$?" >> $OUT/wire-recompile.log
PCP="$G/probes/classes:$CP"
run_case() {
  local name="$1"; shift
  local cmd=("$@")
  printf '%q ' "${cmd[@]}" > $OUT/$name.command; echo >> $OUT/$name.command
  echo "CASE $name START $(date -u +%FT%TZ)" > $OUT/$name.log
  timeout 150 "${cmd[@]}" >> $OUT/$name.log 2>&1
  echo "$name rc=$?" >> $OUT/$name.log
  echo "CASE $name END $(date -u +%FT%TZ)" >> $OUT/$name.log
}
J="$JAVA_HOME21/bin/java"
run_case 20-wire-fallback env -u SOLR_WAIT_FOR_ZK "$J" -Djava.net.preferIPv4Stack=true -Dsolr.zookeeper.client.timeout=30001 -cp "$PCP" org.apache.solr.core.StartupWireProbe fallback-30001 30001
run_case 21-wire-override env -u SOLR_WAIT_FOR_ZK "$J" -Djava.net.preferIPv4Stack=true -Dsolr.zookeeper.client.timeout=30001 -Dsolr.cloud.wait.for.zk.seconds=2 -cp "$PCP" org.apache.solr.core.StartupWireProbe override-2s 2000
echo "WIRE RERUN DONE" >> $OUT/wire-recompile.log
