# r2 root-cause diagnosis (SOLR-18138)

The coordinator's r2 premise — that the r1 teardown failure was caused by `lsof`
being absent — is **disproven**. Building lsof 4.99.0 and putting it on PATH fixed
the *start* path but not the teardown.

## Evidence

1. With lsof present, `solr start` succeeds ("Started Solr server... Happy searching!").
2. The graceful stop mechanism is **fine** on this build:
   - STOP port opens (e.g. `java 13054 41u IPv6 127.0.0.1:32999 (LISTEN)`).
   - `solr stop` sends the stop command; solr.log shows:
     `ShutdownService Performing 'stop' command` -> `Server Stopped` ->
     `CoreContainer Shutting Down` -> `Exiting JVM`.
   - The JVM exits cleanly and quickly.
3. The failure is the **final zombie check in `stop_solr`** (solr/bin/solr ~line 580):
   after the JVM exits, it becomes a **zombie under PID 1** (`python3 /supervisor.py`),
   which **never reaps orphaned children**. `ps -o stat` shows `Z`, so the script
   prints "terminated abnormally... zombie process entry remains" and exits 1.
   -> BATS `teardown_file` fails -> Gradle exit 1.

This is exactly the case the solr script's own comment describes:
"running Solr inside a docker container with multiple processes rather than running
it as the only service. The --init flag on docker avoids that particular problem."

## Host fix (no patch change, no test weakening)

Run the whole Gradle integration test under a **child subreaper**
(/workspace/tools/subreaper.py: prctl(PR_SET_CHILD_SUBREAPER) + waitpid loop).
Orphaned Solr JVMs then reparent to the subreaper, which reaps them, so the zombie
check in `solr stop` sees the process gone.

Verified manually: start under subreaper -> `solr stop -p 33990` returns rc=0 and
`ps` shows the JVM reaped ("13661 gone"), where the same stop without the subreaper
timed out and left an unreaped zombie.

## lsof still needed

lsof remains required for the *start* path (solr/bin/solr uses `lsof -t -PniTCP`
to detect the listener). Built at /workspace/tools/lsof-prefix/bin/lsof (4.99.0),
added to PATH for the gate.
