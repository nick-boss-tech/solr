#!/bin/bash
# SOLR-18592 gate round 1 mutation leg: matchesWildcard() -> return true in an isolated copy. Phone agent.
set -u
CLONE=~/workspace/solr-clones/18592-a-mut
OUT=~/workspace/tools/gate-18592-a/runs
H=25bdab4e926261a70a0cae399d22ed4fa6600ef6
SF=solr/core/src/java/org/apache/solr/schema/SchemaField.java
exec 9>~/workspace/tools/.solr-test-queue.lock
flock 9
pkill -f 'Gradle[D]aemon' 2>/dev/null; sleep 2
rm -f ~/.gradle/caches/journal-1/journal-1.lock
rm -rf "$CLONE"
git clone -q ~/workspace/solr "$CLONE" || exit 2
cd "$CLONE" || exit 2
git fetch -q https://github.com/nick-boss-tech/solr.git refs/heads/solr-18592-submit || exit 2
git checkout -q "$H" || exit 2
cp ~/workspace/solr/gradle.properties .
{
  echo "HEAD=$(git rev-parse HEAD)"
  python3 - <<'PY'
import re
p = 'solr/core/src/java/org/apache/solr/schema/SchemaField.java'
s = open(p).read()
old = """  public boolean matchesWildcard() {
    if (args.containsKey("matchesWildcard")
        || ((type.trueProperties | type.falseProperties) & MATCHES_WILDCARD) != 0) {
      return (properties & MATCHES_WILDCARD) != 0;
    }
    return stored() || useDocValuesAsStored();
  }"""
new = """  public boolean matchesWildcard() {
    return true;
  }"""
assert old in s, 'method body not found verbatim'
open(p, 'w').write(s.replace(old, new, 1))
print('mutation applied')
PY
  echo "mutated paths:"
  git status --porcelain | grep -v '^?? gradle.properties'
  echo "--- mutation diff ---"
  git diff -- "$SF"
  echo "MUT SETUP END $(date -u +%FT%TZ)"
} > "$OUT/mutation.log"
echo "LEG mutated run START $(date -u +%FT%TZ)" >> "$OUT/mutation.log"
~/workspace/tools/solr-gradle.sh --no-daemon :solr:core:cleanTest :solr:core:test --tests org.apache.solr.search.ReturnFieldsTest.testSchemaWildcardSelection -Ptests.seed=18592CAFE >> "$OUT/mutation.log" 2>&1 9>&-
echo "mutated rc=$?" >> "$OUT/mutation.log"
cp solr/core/build/test-results/test/TEST-org.apache.solr.search.ReturnFieldsTest.xml "$OUT/TEST-mutation.xml" 2>/dev/null || echo "NO MUT XML" >> "$OUT/mutation.log"
git checkout -- "$SF"
echo "restored; status now: $(git status --porcelain | grep -v '^?? gradle.properties' | wc -l) changed" >> "$OUT/mutation.log"
echo "LEG restored run START $(date -u +%FT%TZ)" >> "$OUT/mutation.log"
~/workspace/tools/solr-gradle.sh --no-daemon :solr:core:cleanTest :solr:core:test --tests org.apache.solr.search.ReturnFieldsTest.testSchemaWildcardSelection -Ptests.seed=18592CAFE >> "$OUT/mutation.log" 2>&1 9>&-
echo "restored rc=$?" >> "$OUT/mutation.log"
cp solr/core/build/test-results/test/TEST-org.apache.solr.search.ReturnFieldsTest.xml "$OUT/TEST-restored.xml" 2>/dev/null || echo "NO RESTORED XML" >> "$OUT/mutation.log"
echo "MUT END $(date -u +%FT%TZ)" >> "$OUT/mutation.log"
