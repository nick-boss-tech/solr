#!/bin/bash
# SOLR-18592 linux gate round 1: focused tests, tidy, root check at 25bdab4e. Phone agent.
set -u
CLONE=~/workspace/solr-clones/18592-a2
OUT=~/workspace/tools/gate-18592-a/runs2
H=e75cbe0433d027b04373efd983cf361f99612bd7
exec 9>~/workspace/tools/.solr-test-queue.lock
flock 9
pkill -f 'Gradle[D]aemon' 2>/dev/null; sleep 2
rm -f ~/.gradle/caches/journal-1/journal-1.lock
rm -rf "$CLONE"
git clone -q ~/workspace/solr "$CLONE" || exit 2
cd "$CLONE" || exit 2
git fetch -q https://github.com/nick-boss-tech/solr.git refs/heads/solr-18592-submit || exit 2
git checkout -q "$H" || exit 2
cp ~/workspace/solr/gradle.properties .
{
  echo "HEAD=$(git rev-parse HEAD)"
  echo "TREE=$(git rev-parse HEAD^{tree})"
  echo ".git is: $(if [ -d .git ]; then echo directory; else echo FILE; fi)"
  echo "STATUS_BEFORE=$(git status --porcelain | grep -v '^?? gradle.properties' | wc -l)"
  echo "SETUP END $(date -u +%FT%TZ)"
} > "$OUT/positive.log"
echo "LEG tests START $(date -u +%FT%TZ)" >> "$OUT/positive.log"
~/workspace/tools/solr-gradle.sh --no-daemon :solr:core:cleanTest :solr:core:test --tests org.apache.solr.search.ReturnFieldsTest --tests org.apache.solr.response.TestJavaBinResponseWriter --tests org.apache.solr.response.TestCSVResponseWriter --tests org.apache.solr.search.LargeFieldTest -Ptests.seed=18592CAFE >> "$OUT/positive.log" 2>&1 9>&-
echo "tests rc=$?" >> "$OUT/positive.log"
for c in org.apache.solr.search.ReturnFieldsTest org.apache.solr.response.TestJavaBinResponseWriter org.apache.solr.response.TestCSVResponseWriter org.apache.solr.search.LargeFieldTest; do
  cp "solr/core/build/test-results/test/TEST-$c.xml" "$OUT/TEST-$c.xml" 2>/dev/null || echo "NO XML $c" >> "$OUT/positive.log"
done
echo "LEG tidy START $(date -u +%FT%TZ)" >> "$OUT/positive.log"
~/workspace/tools/solr-gradle.sh --no-daemon tidy >> "$OUT/positive.log" 2>&1 9>&-
echo "tidy rc=$?" >> "$OUT/positive.log"
echo "TRACKED_CHANGES_AFTER_TIDY=$(git status --porcelain | grep -v '^?? gradle.properties' | wc -l)" >> "$OUT/positive.log"
git diff --check >> "$OUT/positive.log" 2>&1
echo "diff-check rc=$?" >> "$OUT/positive.log"
echo "LEG check START $(date -u +%FT%TZ)" >> "$OUT/positive.log"
JAVA_TOOL_OPTIONS="-Djava.net.preferIPv4Stack=true -Djavax.net.ssl.trustStore=$HOME/workspace/tools/truststore-with-hatch-ca.jks" ~/workspace/tools/solr-gradle.sh --no-daemon check -x test >> "$OUT/positive.log" 2>&1 9>&-
echo "check rc=$?" >> "$OUT/positive.log"
{
  echo "validateSourcePatterns executions: $(grep -c '> Task :solr:core:validateSourcePatterns' "$OUT/positive.log")"
  echo "TRACKED_CHANGES_AFTER=$(git status --porcelain | grep -v '^?? gradle.properties' | wc -l)"
  echo "HEAD_AFTER=$(git rev-parse HEAD)"
  echo "POSITIVE END $(date -u +%FT%TZ)"
} >> "$OUT/positive.log"
