#!/bin/bash
# SOLR-18592 sortable DV fix gate: fail-before at unfixed head with fix-head test overlaid. Phone agent.
set -u
CLONE=~/workspace/solr-clones/18592-fix-fb
OUT=~/workspace/tools/gate-18592-fix/runs
FIX=b225cd5bb2a5886c187b13009e7016c9165414ce
UNFIXED=b9aed02ac1cde907a06d04fdbd96568ca38b85a9
TESTPATH=solr/core/src/test/org/apache/solr/schema/TestSortableTextField.java
PRODPATH=solr/core/src/java/org/apache/solr/search/SolrDocumentFetcher.java
CLS=org.apache.solr.schema.TestSortableTextField
exec 9>~/workspace/tools/.solr-test-queue.lock
flock 9
pkill -f 'Gradle[D]aemon' 2>/dev/null; sleep 2
rm -f ~/.gradle/caches/journal-1/journal-1.lock
rm -rf "$CLONE"
git clone -q ~/workspace/solr "$CLONE" || exit 2
cd "$CLONE" || exit 2
git fetch -q https://github.com/nick-boss-tech/solr.git refs/heads/solr-18592-sortable-dv-repro-20261110 refs/heads/solr-18592-sortable-dv-fix-20261110 || exit 2
git checkout -q "$UNFIXED" || exit 2
cp ~/workspace/solr/gradle.properties .
{
  echo "HEAD=$(git rev-parse HEAD)"
  echo "fix test blob: $(git rev-parse $FIX:$TESTPATH)"
  echo "unfixed prod blob: $(git rev-parse $UNFIXED:$PRODPATH)"
} > "$OUT/failbefore.log"
git show "$FIX:$TESTPATH" > "$TESTPATH"
{
  echo "overlay test blob now: $(git hash-object $TESTPATH)"
  echo "overlay test sha256: $(sha256sum $TESTPATH | cut -d' ' -f1)"
  echo "prod blob now: $(git hash-object $PRODPATH)"
  echo "prod sha256: $(sha256sum $PRODPATH | cut -d' ' -f1)"
  echo "changed paths vs unfixed head:"
  git status --porcelain | grep -v '^?? gradle.properties'
  echo "FB SETUP END $(date -u +%FT%TZ)"
} >> "$OUT/failbefore.log"
echo "LEG fb controls START $(date -u +%FT%TZ)" >> "$OUT/failbefore.log"
~/workspace/tools/solr-gradle.sh --no-daemon :solr:core:cleanTest :solr:core:test --tests "$CLS.testStoredDocValuesSelectionControls" -Ptests.seed=18592D0C >> "$OUT/failbefore.log" 2>&1 9>&-
echo "fb controls rc=$?" >> "$OUT/failbefore.log"
cp "solr/core/build/test-results/test/TEST-$CLS.xml" "$OUT/TEST-fb-controls.xml" 2>/dev/null || echo "NO FB CONTROLS XML" >> "$OUT/failbefore.log"
echo "LEG fb explicit START $(date -u +%FT%TZ)" >> "$OUT/failbefore.log"
~/workspace/tools/solr-gradle.sh --no-daemon :solr:core:cleanTest :solr:core:test --tests "$CLS.testStoredDocValuesExplicitPreservesFullValue" -Ptests.seed=18592D0C >> "$OUT/failbefore.log" 2>&1 9>&-
echo "fb explicit rc=$?" >> "$OUT/failbefore.log"
cp "solr/core/build/test-results/test/TEST-$CLS.xml" "$OUT/TEST-fb-explicit.xml" 2>/dev/null || echo "NO FB EXPLICIT XML" >> "$OUT/failbefore.log"
echo "FB END $(date -u +%FT%TZ)" >> "$OUT/failbefore.log"
