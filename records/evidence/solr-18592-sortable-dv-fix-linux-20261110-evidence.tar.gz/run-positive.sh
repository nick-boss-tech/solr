#!/bin/bash
# SOLR-18592 sortable DV fix gate: positive legs at fix head b225cd5b. Phone agent.
set -u
CLONE=~/workspace/solr-clones/18592-fix
OUT=~/workspace/tools/gate-18592-fix/runs
FIX=b225cd5bb2a5886c187b13009e7016c9165414ce
UNFIXED=b9aed02ac1cde907a06d04fdbd96568ca38b85a9
BASE=d8ae2a03785c78840ee8dc8bf7e600f9d7b57d01
exec 9>~/workspace/tools/.solr-test-queue.lock
flock 9
pkill -f 'Gradle[D]aemon' 2>/dev/null; sleep 2
rm -f ~/.gradle/caches/journal-1/journal-1.lock
rm -rf "$CLONE"
git clone -q ~/workspace/solr "$CLONE" || exit 2
cd "$CLONE" || exit 2
git fetch -q https://github.com/nick-boss-tech/solr.git refs/heads/solr-18592-sortable-dv-fix-20261110 || exit 2
git checkout -q "$FIX" || exit 2
cp ~/workspace/solr/gradle.properties .
{
  echo "HEAD=$(git rev-parse HEAD)"
  echo "TREE=$(git rev-parse HEAD^{tree})"
  echo ".git is: $(if [ -d .git ]; then echo directory; else echo FILE; fi)"
  git merge-base --is-ancestor "$UNFIXED" HEAD; echo "unfixed ancestor rc=$?"
  echo "STATUS_BEFORE=$(git status --porcelain | grep -v '^?? gradle.properties' | wc -l)"
  echo "diff base..HEAD stat:"
  git diff --stat "$BASE".."$FIX"
  echo "diff unfixed..HEAD stat:"
  git diff --stat "$UNFIXED".."$FIX"
  echo "SETUP END $(date -u +%FT%TZ)"
} > "$OUT/positive.log"
echo "LEG suite START $(date -u +%FT%TZ)" >> "$OUT/positive.log"
~/workspace/tools/solr-gradle.sh --no-daemon :solr:core:cleanTest :solr:core:test --tests org.apache.solr.schema.TestSortableTextField --tests org.apache.solr.response.TestRetrieveFieldsOptimizer --tests org.apache.solr.schema.TestUseDocValuesAsStored --tests org.apache.solr.schema.DocValuesTest --tests org.apache.solr.schema.DocValuesMultiTest -Ptests.seed=18592D0C >> "$OUT/positive.log" 2>&1 9>&-
echo "suite rc=$?" >> "$OUT/positive.log"
for c in org.apache.solr.schema.TestSortableTextField org.apache.solr.response.TestRetrieveFieldsOptimizer org.apache.solr.schema.TestUseDocValuesAsStored org.apache.solr.schema.DocValuesTest org.apache.solr.schema.DocValuesMultiTest; do
  cp "solr/core/build/test-results/test/TEST-$c.xml" "$OUT/TEST-$c.xml" 2>/dev/null || echo "NO XML $c" >> "$OUT/positive.log"
done
echo "LEG tidy START $(date -u +%FT%TZ)" >> "$OUT/positive.log"
~/workspace/tools/solr-gradle.sh --no-daemon tidy >> "$OUT/positive.log" 2>&1 9>&-
echo "tidy rc=$?" >> "$OUT/positive.log"
echo "TRACKED_CHANGES_AFTER_TIDY=$(git status --porcelain | grep -v '^?? gradle.properties' | wc -l)" >> "$OUT/positive.log"
git status --porcelain | grep -v '^?? gradle.properties' >> "$OUT/positive.log"
git diff > "$OUT/tidy-diff.txt" 2>/dev/null
git diff --check >> "$OUT/positive.log" 2>&1
echo "diff-check rc=$?" >> "$OUT/positive.log"
echo "LEG check START $(date -u +%FT%TZ)" >> "$OUT/positive.log"
JAVA_TOOL_OPTIONS="-Djava.net.preferIPv4Stack=true -Djavax.net.ssl.trustStore=$HOME/workspace/tools/truststore-with-hatch-ca.jks" ~/workspace/tools/solr-gradle.sh --no-daemon check -x test >> "$OUT/positive.log" 2>&1 9>&-
echo "check rc=$?" >> "$OUT/positive.log"
{
  echo "validateSourcePatterns executions: $(grep -c '> Task :solr:core:validateSourcePatterns' "$OUT/positive.log")"
  echo "TRACKED_CHANGES_AFTER=$(git status --porcelain | grep -v '^?? gradle.properties' | wc -l)"
  echo "HEAD_AFTER=$(git rev-parse HEAD)"
  echo "POSITIVE END $(date -u +%FT%TZ)"
} >> "$OUT/positive.log"
