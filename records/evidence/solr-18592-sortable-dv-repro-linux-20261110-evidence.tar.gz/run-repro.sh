#!/bin/bash
# SOLR-18592 sortable DV repro (Linux): three TestSortableTextField runs, tidy, root check. Phone agent.
set -u
CLONE=~/workspace/solr-clones/18592-b
OUT=~/workspace/tools/gate-18592-b/runs
H=b9aed02ac1cde907a06d04fdbd96568ca38b85a9
CLS=org.apache.solr.schema.TestSortableTextField
exec 9>~/workspace/tools/.solr-test-queue.lock
flock 9
pkill -f 'Gradle[D]aemon' 2>/dev/null; sleep 2
rm -f ~/.gradle/caches/journal-1/journal-1.lock
rm -rf "$CLONE"
git clone -q ~/workspace/solr "$CLONE" || exit 2
cd "$CLONE" || exit 2
git fetch -q https://github.com/nick-boss-tech/solr.git refs/heads/solr-18592-sortable-dv-repro-20261110 || exit 2
git checkout -q "$H" || exit 2
cp ~/workspace/solr/gradle.properties .
{
  echo "HEAD=$(git rev-parse HEAD)"
  echo "TREE=$(git rev-parse HEAD^{tree})"
  echo ".git is: $(if [ -d .git ]; then echo directory; else echo FILE; fi)"
  echo "STATUS_BEFORE=$(git status --porcelain | grep -v '^?? gradle.properties' | wc -l)"
  echo "diff base..HEAD stat:"
  git diff --stat d8ae2a03785c78840ee8dc8bf7e600f9d7b57d01.."$H"
  echo "SETUP END $(date -u +%FT%TZ)"
} > "$OUT/repro.log"
run_one () {
  local name="$1" method="$2"
  echo "LEG $name START $(date -u +%FT%TZ)" >> "$OUT/repro.log"
  ~/workspace/tools/solr-gradle.sh --no-daemon :solr:core:cleanTest :solr:core:test --tests "$CLS.$method" -Ptests.seed=18592D0C >> "$OUT/repro.log" 2>&1 9>&-
  echo "$name rc=$?" >> "$OUT/repro.log"
  cp "solr/core/build/test-results/test/TEST-$CLS.xml" "$OUT/TEST-$name.xml" 2>/dev/null || echo "NO XML $name" >> "$OUT/repro.log"
}
run_one controls testStoredDocValuesSelectionControls
run_one explicit testStoredDocValuesExplicitPreservesFullValue
run_one neighbor testUseDocValuesAsStored
echo "LEG tidy START $(date -u +%FT%TZ)" >> "$OUT/repro.log"
~/workspace/tools/solr-gradle.sh --no-daemon tidy >> "$OUT/repro.log" 2>&1 9>&-
echo "tidy rc=$?" >> "$OUT/repro.log"
echo "TRACKED_CHANGES_AFTER_TIDY=$(git status --porcelain | grep -v '^?? gradle.properties' | wc -l)" >> "$OUT/repro.log"
git diff --check >> "$OUT/repro.log" 2>&1
echo "diff-check rc=$?" >> "$OUT/repro.log"
echo "LEG check START $(date -u +%FT%TZ)" >> "$OUT/repro.log"
JAVA_TOOL_OPTIONS="-Djava.net.preferIPv4Stack=true -Djavax.net.ssl.trustStore=$HOME/workspace/tools/truststore-with-hatch-ca.jks" ~/workspace/tools/solr-gradle.sh --no-daemon check -x test >> "$OUT/repro.log" 2>&1 9>&-
echo "check rc=$?" >> "$OUT/repro.log"
{
  echo "validateSourcePatterns executions: $(grep -c '> Task :solr:core:validateSourcePatterns' "$OUT/repro.log")"
  echo "TRACKED_CHANGES_AFTER=$(git status --porcelain | grep -v '^?? gradle.properties' | wc -l)"
  echo "HEAD_AFTER=$(git rev-parse HEAD)"
  echo "REPRO END $(date -u +%FT%TZ)"
} >> "$OUT/repro.log"
