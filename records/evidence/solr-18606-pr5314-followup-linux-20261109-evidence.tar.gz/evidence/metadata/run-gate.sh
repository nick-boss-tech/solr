#!/usr/bin/env bash
set -u
TASK=/workspace/gates/logs/phone-agent-2/pr5314-followup-linux-gate-20261109
ROOT=/workspace/worktrees/pr5314-followup-linux-gate-20261109
HEAD_SHA=672448a49c33a257e7a2f8722c84e823b100199c
BASE_SHA=9d4dc33e5d829d2bc9d1304054b5af6746879b34
BRANCH=solr-18606-pr5314-followup
GH=${MANUS_CONFIG_HOME:?}/connectors/github/gh
JAVA_HOME=/usr/lib/jvm/java-21-openjdk-amd64
GRADLE_USER_HOME=/workspace/gradle-home
LOCK_A=/workspace/tools/.gradle-0609f7968656.lock
LOCK_B=/workspace/tools/.gradle-phone-agent-2.lock
mkdir -p "$TASK/logs" "$TASK/evidence"
PROGRESS="$TASK/logs/progress.log"
RESULTS="$TASK/logs/leg-results.tsv"
REFLOG="$TASK/logs/source-ref-checks.log"
: > "$RESULTS"
: > "$REFLOG"
ACTIVE_PID=
GLOBAL_ABORT=0
ABORT_REASON=
exec 9>"$LOCK_A"
exec 8>"$LOCK_B"

inode_snapshot() {
  df -Pi "$TASK" | awk 'NR==2 {printf "%s\t%s\t%s", $2, $3, $4}'
}
inode_free_pct() {
  local total used free
  read -r total used free < <(inode_snapshot)
  awk -v t="$total" -v f="$free" 'BEGIN { if (t>0) printf "%.2f", 100*f/t; else print "0.00" }'
}
check_inodes() {
  local pct
  pct=$(inode_free_pct)
  printf '%s\tfree_inode_percent=%s\n' "$(date -u +%FT%TZ)" "$pct" >> "$PROGRESS"
  if awk -v p="$pct" 'BEGIN {exit !(p <= 15.0)}'; then
    echo "STOP: free inode headroom is ${pct}%, at/below 15% threshold" | tee -a "$PROGRESS"
    return 1
  fi
  return 0
}
check_refs() {
  local branch_sha pr_info pr_state pr_head stamp
  stamp=$(date -u +%FT%TZ)
  if ! branch_sha=$("$GH" api "repos/nick-boss-tech/solr/branches/$BRANCH" --jq '.commit.sha' 2>>"$REFLOG"); then
    echo "$stamp source ref check failed: fork branch lookup unavailable" | tee -a "$REFLOG"
    return 1
  fi
  if ! pr_info=$("$GH" pr view 5314 -R apache/solr --json state,headRefOid --jq '[.state,.headRefOid] | @tsv' 2>>"$REFLOG"); then
    echo "$stamp source ref check failed: PR lookup unavailable" | tee -a "$REFLOG"
    return 1
  fi
  IFS=$'\t' read -r pr_state pr_head <<< "$pr_info"
  echo "$stamp fork=$branch_sha PR_state=$pr_state PR_head=$pr_head" >> "$REFLOG"
  if [[ "$branch_sha" != "$HEAD_SHA" || "$pr_head" != "$BASE_SHA" || "$pr_state" != OPEN ]]; then
    echo "$stamp STOP: assigned source refs changed (expected fork=$HEAD_SHA PR=OPEN@$BASE_SHA)" | tee -a "$REFLOG"
    return 1
  fi
  return 0
}
kill_active_group() {
  if [[ -n "$ACTIVE_PID" ]]; then
    kill -TERM -- "-$ACTIVE_PID" 2>/dev/null || kill -TERM "$ACTIVE_PID" 2>/dev/null || true
    sleep 2
    kill -KILL -- "-$ACTIVE_PID" 2>/dev/null || kill -KILL "$ACTIVE_PID" 2>/dev/null || true
    wait "$ACTIVE_PID" 2>/dev/null || true
    ACTIVE_PID=
  fi
}
run_leg() {
  local name="$1" cwd="$2" cmd="$3"
  local logfile="$TASK/logs/$name.log"
  local started started_iso before pct_now last_heartbeat last_ref rc ended elapsed status
  if [[ "$GLOBAL_ABORT" != 0 ]]; then return 0; fi
  if ! check_refs; then GLOBAL_ABORT=1; ABORT_REASON=source_ref_check_failed_before_leg; return 0; fi
  if ! check_inodes; then GLOBAL_ABORT=1; ABORT_REASON=inode_threshold_before_leg; return 0; fi
  started=$SECONDS
  started_iso=$(date -u +%FT%TZ)
  before=$(inode_free_pct)
  {
    printf 'leg=%s\ncommand=%s\nworking_directory=%s\nhead=%s\nstarted_at_utc=%s\n' "$name" "$cmd" "$cwd" "$HEAD_SHA" "$started_iso"
    printf 'locks_held=%s,%s\n' "$LOCK_A" "$LOCK_B"
    printf 'inode_free_percent_before=%s\n' "$before"
  } > "$logfile"
  echo "[$started_iso] START $name (free inodes ${before}%)" | tee -a "$PROGRESS"
  setsid env JAVA_HOME="$JAVA_HOME" GRADLE_USER_HOME="$GRADLE_USER_HOME" PATH="$JAVA_HOME/bin:$PATH" bash -c 'workdir=$1; command=$2; cd "$workdir" || exit 125; echo "RUN: $command"; eval "$command"' _ "$cwd" "$cmd" >> "$logfile" 2>&1 &
  ACTIVE_PID=$!
  last_heartbeat=$SECONDS
  last_ref=$SECONDS
  local aborted=
  while :; do
    local pstat
    pstat=$(ps -p "$ACTIVE_PID" -o stat= 2>/dev/null || true)
    if [[ -z "$pstat" || "$pstat" == Z* ]]; then break; fi
    sleep 30
    pct_now=$(inode_free_pct)
    if awk -v p="$pct_now" 'BEGIN {exit !(p <= 15.0)}'; then
      GLOBAL_ABORT=1; ABORT_REASON=inode_threshold_during_leg; aborted=inode_threshold
      echo "STOP: $name reached ${pct_now}% free inodes" | tee -a "$PROGRESS"
      kill_active_group
      break
    fi
    if (( SECONDS - last_ref >= 300 )); then
      last_ref=$SECONDS
      if ! check_refs; then
        GLOBAL_ABORT=1; ABORT_REASON=source_refs_changed_or_unavailable_during_leg; aborted=source_refs
        kill_active_group
        break
      fi
    fi
    if (( SECONDS - last_heartbeat >= 60 )); then
      last_heartbeat=$SECONDS
      local tail_line
      tail_line=$(tail -n 1 "$logfile" 2>/dev/null | tr '\n' ' ' | cut -c1-220)
      echo "[$(date -u +%FT%TZ)] HEARTBEAT $name running; free inodes ${pct_now}%; log: ${tail_line:-no new output}" | tee -a "$PROGRESS"
    fi
  done
  rc=0
  if [[ -n "$ACTIVE_PID" ]]; then wait "$ACTIVE_PID" || rc=$?; ACTIVE_PID=; else rc=143; fi
  ended=$(date -u +%FT%TZ)
  elapsed=$((SECONDS-started))
  if [[ -n "$aborted" ]]; then status="aborted_$aborted"; else status=completed; fi
  local after
  after=$(inode_free_pct)
  printf '%s\t%s\t%s\t%s\t%s\t%s\t%s\t%s\t%s\t%s\n' "$name" "$cmd" "$cwd" "$rc" "$started_iso" "$ended" "$elapsed" "$status" "$before" "$after" >> "$RESULTS"
  echo "[$ended] DONE $name exit_code=$rc status=$status duration=${elapsed}s free_inodes=${after}%" | tee -a "$PROGRESS"
}

# Acquire in a stable order and hold both locks for the complete Gradle sequence.
echo "$(date -u +%FT%TZ) waiting for both host locks" | tee -a "$PROGRESS"
if ! flock -w 600 -x 9; then echo 'STOP: first host lock unavailable' | tee -a "$PROGRESS"; exit 80; fi
if ! flock -w 600 -x 8; then echo 'STOP: second host lock unavailable' | tee -a "$PROGRESS"; exit 81; fi
echo "$(date -u +%FT%TZ) both host locks held; executor_pid=$$" | tee -a "$PROGRESS"
if ! check_refs; then GLOBAL_ABORT=1; ABORT_REASON=source_ref_check_failed_at_start; fi
if ! check_inodes; then GLOBAL_ABORT=1; ABORT_REASON=inode_threshold_at_start; fi

run_leg head_solrj "$ROOT/head" "./gradlew --no-daemon :solr:solrj:test --tests org.apache.solr.client.solrj.impl.CloudSolrClientCacheTest --tests org.apache.solr.client.solrj.impl.CloudSolrClientRoutingTest -Ptests.seed=18606CAFE"
run_leg head_core "$ROOT/head" "./gradlew --no-daemon :solr:core:test --tests org.apache.solr.cloud.overseer.ZkStateReaderTest --tests org.apache.solr.cloud.AliasIntegrationTest -Ptests.seed=18606CAFE"
run_leg head_solrj_zookeeper "$ROOT/head" "./gradlew --no-daemon :solr:solrj-zookeeper:test --tests org.apache.solr.common.cloud.SolrZkClientTest -Ptests.seed=18606CAFE"
run_leg fail_before_cache "$ROOT/base-cache-fail-before" "./gradlew --no-daemon :solr:solrj:test --tests org.apache.solr.client.solrj.impl.CloudSolrClientCacheTest.testMissingCollectionIsCheckedOncePerRequest -Ptests.seed=18606CAFE"
run_leg fail_before_reader "$ROOT/base-reader-fail-before" "./gradlew --no-daemon :solr:core:test --tests org.apache.solr.cloud.overseer.ZkStateReaderTest.testProviderPropagatesCollectionReadFailures -Ptests.seed=18606CAFE"
run_leg mutation_provider_sync_removed "$ROOT/mut-provider-sync" "./gradlew --no-daemon :solr:core:test --tests org.apache.solr.cloud.overseer.ZkStateReaderTest.testProviderUnknownCollection -Ptests.seed=18606CAFE"
run_leg mutation_sync_timeout_disabled "$ROOT/mut-sync-timeout" "./gradlew --no-daemon :solr:core:test --tests org.apache.solr.cloud.overseer.ZkStateReaderTest.testSyncWaitsForCallbackAndPropagatesFailure -Ptests.seed=18606CAFE"
run_leg mutation_alias_guard_removed "$ROOT/mut-alias-guard" "./gradlew --no-daemon :solr:core:test --tests org.apache.solr.cloud.overseer.ZkStateReaderTest.testProviderDoesNotRefreshKnownAlias -Ptests.seed=18606CAFE"
run_leg tidy "$ROOT/head" "./gradlew --no-daemon tidy"
if [[ "$GLOBAL_ABORT" == 0 ]]; then
  if git -C "$ROOT/head" diff --quiet HEAD --; then
    echo "$(date -u +%FT%TZ) tidy left tracked files unchanged" | tee -a "$PROGRESS"
    run_leg root_check "$ROOT/head" "./gradlew --no-daemon check -x test"
  else
    git -C "$ROOT/head" diff --binary HEAD -- > "$TASK/logs/tidy-tracked-diff.patch"
    git -C "$ROOT/head" status --short > "$TASK/logs/tidy-tracked-status.txt"
    echo "$(date -u +%FT%TZ) STOP: tidy modified tracked files; root check not run at invalidated head" | tee -a "$PROGRESS"
    git -C "$ROOT/head" reset --hard HEAD >> "$PROGRESS" 2>&1
    GLOBAL_ABORT=1; ABORT_REASON=tidy_modified_tracked_files
  fi
fi
# Stop any single-use/leftover Gradle daemons while both locks remain held.
if [[ "$GLOBAL_ABORT" == 0 ]]; then
  run_leg gradle_stop "$ROOT/head" "./gradlew --no-daemon --stop"
fi
if [[ "$GLOBAL_ABORT" != 0 ]]; then
  echo "$(date -u +%FT%TZ) RUNNER_ABORT reason=$ABORT_REASON" | tee -a "$PROGRESS"
else
  echo "$(date -u +%FT%TZ) RUNNER_ALL_COMMANDS_FINISHED" | tee -a "$PROGRESS"
fi
# Source ref check at the end, still under both locks.
if [[ "$GLOBAL_ABORT" == 0 ]] && ! check_refs; then GLOBAL_ABORT=1; ABORT_REASON=source_ref_check_failed_at_end; fi

# Release locks, then capture local executor-stop evidence for the later board release.
flock -u 8 || true
flock -u 9 || true
free_a=busy; free_b=busy
flock -n "$LOCK_A" -c true && free_a=free || true
flock -n "$LOCK_B" -c true && free_b=free || true
matching=$(ps -eo args= | grep -E '[G]radleDaemon|[G]radleWrapperMain|[g]radle --no-daemon' | grep -F "$ROOT" | wc -l | tr -d ' ')
final_inode=$(inode_free_pct)
python3 - "$TASK/executor-stop.json" "$GLOBAL_ABORT" "$ABORT_REASON" "$free_a" "$free_b" "$matching" "$final_inode" "$HEAD_SHA" <<'PY'
import json,sys,datetime
path,aborted,reason,lock_a,lock_b,matching,inode,head=sys.argv[1:]
d={"observed_at_utc":datetime.datetime.now(datetime.timezone.utc).isoformat(),"host":"phone-agent-2 Linux gate host","head":head,"runner_aborted":aborted!="0","abort_reason":reason or None,"matching_executor_count":int(matching),"host_locks":{"/workspace/tools/.gradle-0609f7968656.lock":lock_a,"/workspace/tools/.gradle-phone-agent-2.lock":lock_b},"free_inode_percent_approx":float(inode),"stop_threshold_free_percent":15,"source_checkout_clean":None}
with open(path,'w') as f: json.dump(d,f,indent=2); f.write('\n')
print(json.dumps(d,sort_keys=True))
PY
cat "$RESULTS"
[[ "$GLOBAL_ABORT" == 0 ]]
