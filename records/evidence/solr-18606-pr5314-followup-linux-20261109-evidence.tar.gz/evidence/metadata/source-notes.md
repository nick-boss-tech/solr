# PR 5314 gate source notes

The active queue was revalidated on `nick-boss-tech/solr:coordination-v2` (pre-result snapshot `397f0525d724f02cefe2b3807af1cbe41ebc6594`). The assignment and gate are `records/assignment/solr-18606-pr5314-followup-linux-20261109.json` and `records/gate/solr-18606-pr5314-followup-linux-20261109.json`; the canonical claim is `records/claim/solr-18606-pr5314-followup-linux-20261109.json`.

The assigned fork branch is `nick-boss-tech/solr:solr-18606-pr5314-followup`. Its head remained `672448a49c33a257e7a2f8722c84e823b100199c`; that commit's parent is `9d4dc33e5d829d2bc9d1304054b5af6746879b34`.

At gate preflight, public Apache Solr PR #5314 was open and draft at the required base/head `9d4dc33e5d829d2bc9d1304054b5af6746879b34`. It was last observed at that head at `2026-11-10T02:54:10Z`. At `2026-11-10T02:55:41Z`, the gate guard first observed PR #5314 at `672448a49c33a257e7a2f8722c84e823b100199c` instead. The fork branch itself had not moved. The final pre-publication read-only query at `2026-11-10T03:02:04.237697+00:00` reported the PR still open/draft at head `672448a49c33a257e7a2f8722c84e823b100199c`, with `updatedAt=2026-11-10T03:00:19Z`. This violated the gate's requirement that the public PR remain on the base, so the worker stopped before `check -x test`; the Linux gate did not change source or PR content.

Sources:
- Public PR: https://github.com/apache/solr/pull/5314
- Assigned fork branch API: https://api.github.com/repos/nick-boss-tech/solr/branches/solr-18606-pr5314-followup
- Assigned commit API: https://api.github.com/repos/nick-boss-tech/solr/commits/672448a49c33a257e7a2f8722c84e823b100199c
- Active board branch: https://github.com/nick-boss-tech/solr/tree/coordination-v2
