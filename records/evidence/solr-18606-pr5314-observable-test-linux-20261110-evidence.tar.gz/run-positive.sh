#!/bin/bash
# PR 5314 observable-test gate: positive legs at f9988d951a. Phone agent.
set -u
CLONE=~/workspace/solr-clones/5314-obs
OUT=~/workspace/tools/gate-5314-obs/runs
CH2T=org.apache.solr.client.solrj.impl.CloudHttp2SolrClientTest
exec 9>~/workspace/tools/.solr-test-queue.lock
flock 9
pkill -f 'Gradle[D]aemon' 2>/dev/null; sleep 2
rm -f ~/.gradle/caches/journal-1/journal-1.lock
cd "$CLONE" || exit 2
{
  echo "HEAD=$(git rev-parse HEAD)"
  echo "TREE=$(git rev-parse HEAD^{tree})"
  echo ".git is: $(if [ -d .git ]; then echo directory; else echo FILE; fi)"
  echo "STATUS_BEFORE=$(git status --porcelain | grep -v '^?? gradle.properties' | wc -l)"
  echo "SETUP END $(date -u +%FT%TZ)"
} > "$OUT/positive.log"
cp_xml () { cp "solr/$1/build/test-results/test/TEST-$2.xml" "$OUT/$3" 2>/dev/null || echo "NO XML $2" >> "$OUT/positive.log"; }
echo "LEG alias CAFE START $(date -u +%FT%TZ)" >> "$OUT/positive.log"
~/workspace/tools/solr-gradle.sh --no-daemon :solr:solrj:cleanTest :solr:solrj:test --tests "$CH2T.testZkAliasDoesNotReadAliasCollectionState" -Ptests.seed=18606CAFE >> "$OUT/positive.log" 2>&1 9>&-
echo "alias CAFE rc=$?" >> "$OUT/positive.log"
cp_xml solrj "$CH2T" TEST-alias-CAFE.xml
echo "LEG alias BEEF START $(date -u +%FT%TZ)" >> "$OUT/positive.log"
~/workspace/tools/solr-gradle.sh --no-daemon :solr:solrj:cleanTest :solr:solrj:test --tests "$CH2T.testZkAliasDoesNotReadAliasCollectionState" -Ptests.seed=18606BEEF >> "$OUT/positive.log" 2>&1 9>&-
echo "alias BEEF rc=$?" >> "$OUT/positive.log"
cp_xml solrj "$CH2T" TEST-alias-BEEF.xml
echo "LEG solrj suite START $(date -u +%FT%TZ)" >> "$OUT/positive.log"
~/workspace/tools/solr-gradle.sh --no-daemon :solr:solrj:cleanTest :solr:solrj:test --tests org.apache.solr.client.solrj.impl.ClusterStateProviderTest --tests org.apache.solr.client.solrj.impl.CloudSolrClientCacheTest --tests org.apache.solr.client.solrj.impl.CloudSolrClientRoutingTest --tests "$CH2T.testHttpCspPerf" --tests "$CH2T.testAliasHandling" -Ptests.seed=18606CAFE >> "$OUT/positive.log" 2>&1 9>&-
echo "solrj suite rc=$?" >> "$OUT/positive.log"
cp_xml solrj org.apache.solr.client.solrj.impl.ClusterStateProviderTest TEST-csp.xml
cp_xml solrj org.apache.solr.client.solrj.impl.CloudSolrClientCacheTest TEST-cache.xml
cp_xml solrj org.apache.solr.client.solrj.impl.CloudSolrClientRoutingTest TEST-routing.xml
cp_xml solrj "$CH2T" TEST-ch2-suite.xml
echo "LEG core START $(date -u +%FT%TZ)" >> "$OUT/positive.log"
~/workspace/tools/solr-gradle.sh --no-daemon :solr:core:cleanTest :solr:core:test --tests org.apache.solr.cloud.overseer.ZkStateReaderTest --tests org.apache.solr.cloud.AliasIntegrationTest -Ptests.seed=18606CAFE >> "$OUT/positive.log" 2>&1 9>&-
echo "core rc=$?" >> "$OUT/positive.log"
cp_xml core org.apache.solr.cloud.overseer.ZkStateReaderTest TEST-zksr.xml
cp_xml core org.apache.solr.cloud.AliasIntegrationTest TEST-aliasint.xml
echo "LEG zk START $(date -u +%FT%TZ)" >> "$OUT/positive.log"
~/workspace/tools/solr-gradle.sh --no-daemon :solr:solrj-zookeeper:cleanTest :solr:solrj-zookeeper:test --tests org.apache.solr.common.cloud.SolrZkClientTest -Ptests.seed=18606CAFE >> "$OUT/positive.log" 2>&1 9>&-
echo "zk rc=$?" >> "$OUT/positive.log"
cp_xml solrj-zookeeper org.apache.solr.common.cloud.SolrZkClientTest TEST-zkclient.xml
echo "LEG tidy START $(date -u +%FT%TZ)" >> "$OUT/positive.log"
~/workspace/tools/solr-gradle.sh --no-daemon tidy >> "$OUT/positive.log" 2>&1 9>&-
echo "tidy rc=$?" >> "$OUT/positive.log"
echo "TRACKED_CHANGES_AFTER_TIDY=$(git status --porcelain | grep -v '^?? gradle.properties' | wc -l)" >> "$OUT/positive.log"
git diff --check >> "$OUT/positive.log" 2>&1
echo "diff-check rc=$?" >> "$OUT/positive.log"
echo "LEG check START $(date -u +%FT%TZ)" >> "$OUT/positive.log"
JAVA_TOOL_OPTIONS="-Djava.net.preferIPv4Stack=true -Djavax.net.ssl.trustStore=$HOME/workspace/tools/truststore-with-hatch-ca.jks" ~/workspace/tools/solr-gradle.sh --no-daemon check -x test >> "$OUT/positive.log" 2>&1 9>&-
echo "check rc=$?" >> "$OUT/positive.log"
{
  echo "validateSourcePatterns executions: $(grep -c '> Task :solr:core:validateSourcePatterns' "$OUT/positive.log")"
  echo "TRACKED_CHANGES_AFTER=$(git status --porcelain | grep -v '^?? gradle.properties' | wc -l)"
  echo "HEAD_AFTER=$(git rev-parse HEAD)"
  echo "POSITIVE END $(date -u +%FT%TZ)"
} >> "$OUT/positive.log"
