#!/bin/bash
# PR 5314 observable-test gate: five isolated mutations, each in a fresh clean checkout. Phone agent.
set -u
OUT=~/workspace/tools/gate-5314-obs/runs2
H=5da7243cb75e2f3d2fb7b3557b6e30477dbbf97d
PROV=solr/solrj-zookeeper/src/java/org/apache/solr/client/solrj/impl/ZkClientClusterStateProvider.java
ZKC=solr/solrj-zookeeper/src/java/org/apache/solr/common/cloud/SolrZkClient.java
CSP=org.apache.solr.client.solrj.impl.ClusterStateProviderTest
CH2T=org.apache.solr.client.solrj.impl.CloudHttp2SolrClientTest
exec 9>~/workspace/tools/.solr-test-queue.lock
flock 9
run_mut () {
  local name="$1" testfqcn="$2"
  local CLONE=~/workspace/solr-clones/5314-obs2-mut-$name
  pkill -f 'Gradle[D]aemon' 2>/dev/null; sleep 2
  rm -f ~/.gradle/caches/journal-1/journal-1.lock
  rm -rf "$CLONE"
  git clone -q ~/workspace/solr "$CLONE" || { echo "clone fail $name" >> "$OUT/mutations.log"; return; }
  cd "$CLONE" || return
  git fetch -q https://github.com/nick-boss-tech/solr.git refs/heads/solr-18606-pr5314-observable-test || { echo "fetch fail $name" >> "$OUT/mutations.log"; return; }
  git checkout -q "$H" || { echo "checkout fail $name" >> "$OUT/mutations.log"; return; }
  cp ~/workspace/solr/gradle.properties .
  {
    echo "=== MUT $name HEAD=$(git rev-parse HEAD) $(date -u +%FT%TZ) ==="
    python3 - "$name" <<'PY'
import sys
name = sys.argv[1]
PROV = 'solr/solrj-zookeeper/src/java/org/apache/solr/client/solrj/impl/ZkClientClusterStateProvider.java'
ZKC = 'solr/solrj-zookeeper/src/java/org/apache/solr/common/cloud/SolrZkClient.java'
def sub(path, old, new, count=1):
    s = open(path).read()
    assert old in s, f'{name}: pattern not found in {path}'
    open(path, 'w').write(s.replace(old, new, count))
if name == 'guard':
    sub(PROV, '    if (ref != null || reader.getAliases().hasAlias(collection)) {',
              '    if (ref != null) {')
elif name == 'sync':
    sub(PROV, '      reader.getZkClient().sync(ZkStateReader.COLLECTIONS_ZKNODE);\n', '')
elif name == 'await':
    sub(ZKC, '    if (!completed.await(zkClientTimeout, TimeUnit.MILLISECONDS)) {',
             '    if (false) {')
elif name == 'reclass':
    old = """    } catch (SolrException e) {
      Throwable cause = e.getCause();
      if (e.code() == SolrException.ErrorCode.BAD_REQUEST.code
          && (cause instanceof KeeperException || cause instanceof InterruptedException)) {
        if (cause instanceof InterruptedException) {
          Thread.currentThread().interrupt();
        }
        throw new ZooKeeperException(SolrException.ErrorCode.SERVER_ERROR, e.toString(), cause);
      }
      throw e;
    }"""
    new = """    } catch (SolrException e) {
      throw e;
    }"""
    sub(PROV, old, new)
elif name == 'getstate':
    old_start = '    try {\n      // Curator sync is asynchronous; wait for it before reading a missing collection.'
    s = open(PROV).read()
    i = s.index(old_start)
    j = s.index('      throw e;\n    }', i) + len('      throw e;\n    }')
    open(PROV, 'w').write(s[:i] + '    return ref;\n' + s[j:])
    print('getstate: try/catch miss-refresh replaced with return ref')
else:
    raise SystemExit('unknown mutation ' + name)
print(name + ': mutation applied')
PY
    echo "mutated paths:"
    git status --porcelain | grep -v '^?? gradle.properties'
    git diff
  } >> "$OUT/mutations.log" 2>&1
  echo "LEG mut $name START $(date -u +%FT%TZ)" >> "$OUT/mutations.log"
  ~/workspace/tools/solr-gradle.sh --no-daemon :solr:solrj:cleanTest :solr:solrj:test --tests "$testfqcn" -Ptests.seed=18606CAFE >> "$OUT/mutations.log" 2>&1 9>&-
  echo "mut $name rc=$?" >> "$OUT/mutations.log"
  local cls="${testfqcn%.*}"
  cp "solr/solrj/build/test-results/test/TEST-$cls.xml" "$OUT/TEST-mut-$name.xml" 2>/dev/null || echo "NO XML mut $name" >> "$OUT/mutations.log"
  cd ~/workspace
}
: > "$OUT/mutations.log"
run_mut guard "$CH2T.testZkAliasDoesNotReadAliasCollectionState"
run_mut sync "$CSP.testProviderUnknownCollection"
run_mut await "$CSP.testSyncWaitsForCallbackAndPropagatesFailure"
run_mut reclass "$CSP.testProviderPropagatesCollectionReadFailures"
run_mut getstate "$CSP.testProviderRefreshesCollectionMissingFromLocalState"
echo "MUTATIONS END $(date -u +%FT%TZ)" >> "$OUT/mutations.log"
