#!/bin/bash
# PR 5314 gate: four mutation legs in the dedicated clone 5314-mut.
# Each leg: verify clean at H, apply one guarded exact replacement, run the
# single named ZkStateReaderTest method at seed 18606CAFE, restore, verify clean.
set -u
MUT=~/workspace/solr-clones/5314-mut
OUT=~/workspace/tools/gate-5314
H=9d4dc33e5d829d2bc9d1304054b5af6746879b34
SEED=18606CAFE
ZSR=solr/solrj-zookeeper/src/java/org/apache/solr/common/cloud/ZkStateReader.java
PROV=solr/solrj-zookeeper/src/java/org/apache/solr/client/solrj/impl/ZkClientClusterStateProvider.java
SZK=solr/solrj-zookeeper/src/java/org/apache/solr/common/cloud/SolrZkClient.java
CLS=org.apache.solr.cloud.overseer.ZkStateReaderTest
exec 9>~/workspace/tools/.solr-test-queue.lock
flock 9
cd "$MUT" || exit 2
: > "$OUT/mutations.log"

apply_mutation () {
  # $1 file, $2 old, $3 new ; requires exactly one occurrence of old
  python3 - "$MUT/$1" "$2" "$3" <<'PYEOF'
import sys
path, old, new = sys.argv[1], sys.argv[2], sys.argv[3]
src = open(path).read()
n = src.count(old)
if n != 1:
    print(f"PREMISE FAIL: {path}: found {n} occurrences of target")
    sys.exit(4)
open(path, "w").write(src.replace(old, new))
print(f"applied: {path}")
PYEOF
}

run_mutation () {
  name=$1; method=$2; file=$3; old=$4; new=$5
  echo "=== $name START $(date -u +%FT%TZ) ===" >> "$OUT/mutations.log"
  [ "$(git rev-parse HEAD)" = "$H" ] || { echo "$name ABORT head mismatch" >> "$OUT/mutations.log"; return; }
  st=$(git status --porcelain | grep -v '^?? gradle.properties' | wc -l)
  [ "$st" = "0" ] || { echo "$name ABORT dirty checkout" >> "$OUT/mutations.log"; return; }
  if ! apply_mutation "$file" "$old" "$new" >> "$OUT/mutations.log" 2>&1; then
    echo "$name PREMISE FAILED, leg not run" >> "$OUT/mutations.log"
    git checkout -- "$file" 2>/dev/null
    return
  fi
  git diff > "$OUT/$name.diff"
  rm -rf "$MUT/solr/core/build/test-results/test"
  ~/workspace/tools/solr-gradle.sh :solr:core:test --tests "$CLS.$method" -Ptests.seed=$SEED > "$OUT/$name.log" 2>&1 9>&-
  echo "$name rc=$?" >> "$OUT/mutations.log"
  mkdir -p "$OUT/xml-$name"
  find "$MUT/solr/core/build/test-results/test" -name 'TEST-*.xml' -exec cp {} "$OUT/xml-$name/" \; 2>/dev/null
  git checkout -- "$file"
  st=$(git status --porcelain | grep -v '^?? gradle.properties' | wc -l)
  echo "$name restored, dirty_entries=$st" >> "$OUT/mutations.log"
  echo "=== $name END $(date -u +%FT%TZ) ===" >> "$OUT/mutations.log"
}

run_mutation m1 testProviderPropagatesCollectionReadFailures "$ZSR" \
  'DocCollection state = fetchCollectionState(collection, null);' \
  'DocCollection state = new LazyCollectionRef(collection).get();'
run_mutation m2 testProviderUnknownCollection "$PROV" \
  'reader.getZkClient().sync(ZkStateReader.COLLECTIONS_ZKNODE);' \
  '// mutation: provider sync call removed'
run_mutation m3 testSyncWaitsForCallbackAndPropagatesFailure "$SZK" \
  'if (!completed.await(zkClientTimeout, TimeUnit.MILLISECONDS)) {' \
  'if (false) {'
run_mutation m4 testProviderDoesNotRefreshKnownAlias "$PROV" \
  'if (ref != null || reader.getAliases().hasAlias(collection)) {' \
  'if (ref != null) {'
echo "MUTATIONS DONE $(date -u +%FT%TZ)" >> "$OUT/mutations.log"
