#!/bin/bash
# PR 5314 / SOLR-18606 review-fixes Linux gate, positive legs. Phone agent.
# Exact head 9d4dc33e5d829d2bc9d1304054b5af6746879b34, seed 18606CAFE.
set -u
POS=~/workspace/solr-clones/5314-pos
OUT=~/workspace/tools/gate-5314
H=9d4dc33e5d829d2bc9d1304054b5af6746879b34
SEED=18606CAFE
mkdir -p "$OUT"
exec 9>~/workspace/tools/.solr-test-queue.lock
flock 9
pkill -f 'Gradle[D]aemon' 2>/dev/null; sleep 2
rm -f ~/.gradle/caches/journal-1/journal-1.lock
cd "$POS" || exit 2
{
  echo "HEAD=$(git rev-parse HEAD)"
  echo "TREE=$(git rev-parse 'HEAD^{tree}')"
  echo "STATUS_BEGIN"; git status --porcelain; echo "STATUS_END"
} > "$OUT/positive-head.txt" 2>&1
[ "$(git rev-parse HEAD)" = "$H" ] || { echo "HEAD MISMATCH" > "$OUT/positive.ABORT"; exit 3; }

run_leg () {
  name=$1; xmldir=$2; shift 2
  echo "=== $name START $(date -u +%FT%TZ) ===" >> "$OUT/positive.log"
  rm -rf "$POS/$xmldir"
  ~/workspace/tools/solr-gradle.sh "$@" -Ptests.seed=$SEED > "$OUT/$name.log" 2>&1 9>&-
  echo "$name rc=$?" >> "$OUT/positive.log"
  mkdir -p "$OUT/xml-$name"
  find "$POS/$xmldir" -name 'TEST-*.xml' -exec cp {} "$OUT/xml-$name/" \; 2>/dev/null
  echo "=== $name END $(date -u +%FT%TZ) ===" >> "$OUT/positive.log"
}

: > "$OUT/positive.log"
run_leg p1 solr/core/build/test-results/test :solr:core:test --tests org.apache.solr.cloud.overseer.ZkStateReaderTest
run_leg p2 solr/core/build/test-results/test :solr:core:test --tests org.apache.solr.cloud.AliasIntegrationTest
run_leg p3 solr/solrj/build/test-results/test :solr:solrj:test --tests org.apache.solr.client.solrj.impl.CloudSolrClientCacheTest --tests org.apache.solr.client.solrj.impl.CloudSolrClientRoutingTest
run_leg p4 solr/modules/solrj-zookeeper/build/test-results/test :solr:solrj-zookeeper:test --tests org.apache.solr.common.cloud.SolrZkClientTest
# solrj-zookeeper module path fallback: also sweep the alternate results dir
find "$POS" -path '*solrj-zookeeper*test-results*' -name 'TEST-*SolrZkClientTest*.xml' -exec cp {} "$OUT/xml-p4/" \; 2>/dev/null
git status --porcelain > "$OUT/positive-final-status.txt"
echo "POSITIVE DONE $(date -u +%FT%TZ)" >> "$OUT/positive.log"
