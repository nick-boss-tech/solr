#!/bin/bash
# PR 5314 gate: root tidy and root check -x test on the unmodified head, in the
# normal clone 5314-pos (Antora rule). Phone agent.
set -u
POS=~/workspace/solr-clones/5314-pos
OUT=~/workspace/tools/gate-5314
H=9d4dc33e5d829d2bc9d1304054b5af6746879b34
exec 9>~/workspace/tools/.solr-test-queue.lock
flock 9
cd "$POS" || exit 2
[ "$(git rev-parse HEAD)" = "$H" ] || { echo "HEAD MISMATCH" > "$OUT/tidy-check.ABORT"; exit 3; }
git status --porcelain > "$OUT/pre-tidy-status.txt"
echo "TIDY START $(date -u +%FT%TZ)" > "$OUT/tidy-check.log"
~/workspace/tools/solr-gradle.sh tidy > "$OUT/tidy.log" 2>&1 9>&-
echo "tidy rc=$?" >> "$OUT/tidy-check.log"
git status --porcelain > "$OUT/post-tidy-status.txt"
git diff > "$OUT/tidy.diff" 2>&1
git diff --check > "$OUT/diffcheck.log" 2>&1; echo "diffcheck rc=$?" >> "$OUT/tidy-check.log"
pkill -f 'Gradle[D]aemon' 2>/dev/null; sleep 2
rm -f ~/.gradle/caches/journal-1/journal-1.lock
echo "CHECK START $(date -u +%FT%TZ)" >> "$OUT/tidy-check.log"
JAVA_TOOL_OPTIONS=-Djavax.net.ssl.trustStore=$HOME/workspace/tools/truststore-with-hatch-ca.jks ~/workspace/tools/solr-gradle.sh check -x test > "$OUT/check.log" 2>&1 9>&-
echo "check rc=$?" >> "$OUT/tidy-check.log"
echo "ALL DONE $(date -u +%FT%TZ)" >> "$OUT/tidy-check.log"
