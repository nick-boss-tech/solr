SOLR-18606 PR 5314 review-round2 Linux gate evidence (vm6 host)
Job: solr-18606-pr5314-review-round2-linux-20261113
Head: a20facda3ee83d307dbc26a33a229c7b082c62bb (fork branch solr-18606-pr5314-review-round2, verified by git ls-remote at claim)
Head commit: a20facda3ee "SOLR-18606: Use SolrTestCase for alias regression" (2026-11-14)
Seed: 18606CAFE for every test leg
Verdict: PASSED

== Head verification (gate requirement 4)
Isolated clean worktrees at a20facda3 (solr-18606-round2-head for positive/tidy/check;
solr-18606-round2-mut for the mutation leg), rev-parse HEAD equals the offered head,
zero modifications at setup. Fork branch solr-18606-pr5314-review-round2 verified ==
gate head by git ls-remote at claim time. The head switches ZkClientClusterStateProviderTest
from SolrTestCaseJ4 to SolrTestCase and renames the collection from "target_<testname>"
to "target". Gate supersedes records/gate/solr-18606-pr5314-alias-signal-linux-gate-2dbfc9f32aa-r2.json
(which passed at 2dbfc9f3).

== Positive legs (gate requirement 1)
Leg A: :solr:solrj-zookeeper:test --tests org.apache.solr.client.solrj.impl.ZkClientClusterStateProviderTest.testKnownAliasDoesNotReadAliasCollectionState -Dtests.seed=18606CAFE
  rc=0 (BUILD SUCCESSFUL in 4m 51s). 1 test, 0 failures, 0 errors, 0 skipped.
  The same-client positive control records the exact missing alias collection-state
  path with NoNodeException; the guarded known-alias call records no read of that path.
Leg B: :solr:solrj:test --tests org.apache.solr.client.solrj.impl.CloudHttp2SolrClientTest.testZkAliasRequestsResolveAndQuery -Dtests.seed=18606CAFE
  rc=0. 1 test, 0 failures, 0 errors, 0 skipped. Alias resolution and repeated query coverage remain.
Leg C: :solr:solrj:test --tests org.apache.solr.client.solrj.impl.ClusterStateProviderTest --tests org.apache.solr.client.solrj.impl.CloudSolrClientCacheTest --tests org.apache.solr.client.solrj.impl.CloudSolrClientRoutingTest -Dtests.seed=18606CAFE
  rc=0. 7+2+22 = 31 tests, 0 failures, 0 errors, 0 skipped.
Leg D: :solr:core:test --tests org.apache.solr.cloud.overseer.ZkStateReaderTest --tests org.apache.solr.cloud.AliasIntegrationTest -Dtests.seed=18606CAFE
  rc=0. 9+16 = 25 tests, 0 failures, 0 errors, 0 skipped.
Leg E: :solr:solrj-zookeeper:test --tests org.apache.solr.common.cloud.SolrZkClientTest -Dtests.seed=18606CAFE
  rc=0. 7 tests, 0 failures, 0 errors, 0 skipped.
Total positive: 65 tests, 0 failures, 0 errors, 0 skipped.

== Tidy leg (gate requirement 3)
Tidy: ./gradlew tidy at head a20facda3. rc=0 (BUILD SUCCESSFUL in 1m 11s).
Post-tidy tracked changes: 0 — the head is spotless-clean.

== Check leg (gate requirement 3)
./gradlew check -x test -Prefguide.include=false at head a20facda3. rc=0
(BUILD SUCCESSFUL in 8m 32s). 515 actionable tasks. forbiddenApis and all other
non-test checks passed. The solr-ref-guide/Antora checks are not enforced for gate
runs per the standing owner rule (Nick 2026-11-13); -Prefguide.include=false keeps
them out of the run.

== Mutation leg (gate requirement 2) - known-alias guard-removal proof
In the isolated mutation worktree at head a20facda3, remove exactly the known-alias
guard in ZkClientClusterStateProvider.getState:
  -    if (ref != null || reader.getAliases().hasAlias(collection)) {
  +    if (ref != null) {
Diff SHA-256: bc96b4760086e154c8ae342309a0f4b841568c92560882c124a6ff241946d7a9
Focused test: :solr:solrj-zookeeper:test --tests org.apache.solr.client.solrj.impl.ZkClientClusterStateProviderTest.testKnownAliasDoesNotReadAliasCollectionState -Dtests.seed=18606CAFE
compile rc=0. Test FAILED behaviorally (BUILD FAILED in 4m 36s), 1 test, 1 failure,
0 errors, 0 skipped:
  java.lang.AssertionError: Known alias triggered a read of /collections/target_alias/state.json:
    [ReadAttempt[path=/collections/target_alias/state.json, failure=NoNodeException]]
This is a behavioral assertion failure on the exact alias state-path read the guard
prevents — not a compile/setup failure or skip. Source restored; worktree clean.

== Notes
Test logs include non-fatal Java security-policy/CLDR warnings; all positive legs
exited 0 and their JUnit XMLs report 0 failures/errors/skips. No source edits, PR
comments, or public posts were made by this host.
