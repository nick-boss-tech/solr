#!/bin/bash
# PR 5314 successor: root check only, at the moved head 672448a49c, clean normal clone. Phone agent.
set -u
CLONE=~/workspace/solr-clones/5314-root
OUT=~/workspace/tools/gate-5314-root/runs
H=672448a49c33a257e7a2f8722c84e823b100199c
exec 9>~/workspace/tools/.solr-test-queue.lock
flock 9
pkill -f 'Gradle[D]aemon' 2>/dev/null; sleep 2
rm -f ~/.gradle/caches/journal-1/journal-1.lock
{
  echo "PREFLIGHT $(date -u +%FT%TZ)"
  echo "fork solr-18606-submit: $(git ls-remote https://github.com/nick-boss-tech/solr.git refs/heads/solr-18606-submit | cut -f1)"
  echo "PR 5314 head ref: $(git ls-remote https://github.com/apache/solr.git refs/pull/5314/head | cut -f1)"
} > "$OUT/check.log"
rm -rf "$CLONE"
git clone -q ~/workspace/solr "$CLONE" || exit 2
cd "$CLONE" || exit 2
git fetch -q https://github.com/nick-boss-tech/solr.git refs/heads/solr-18606-submit || exit 2
git checkout -q "$H" || exit 2
cp ~/workspace/solr/gradle.properties .
{
  echo "HEAD=$(git rev-parse HEAD)"
  echo ".git is: $(if [ -d .git ]; then echo directory; else echo FILE; fi)"
  echo "STATUS_BEFORE=$(git status --porcelain | grep -v '^?? gradle.properties' | wc -l)"
  echo "CHECK START $(date -u +%FT%TZ)"
} >> "$OUT/check.log"
JAVA_TOOL_OPTIONS="-Djava.net.preferIPv4Stack=true -Djavax.net.ssl.trustStore=$HOME/workspace/tools/truststore-with-hatch-ca.jks" ~/workspace/tools/solr-gradle.sh --no-daemon check -x test >> "$OUT/check.log" 2>&1 9>&-
echo "check rc=$?" >> "$OUT/check.log"
{
  echo "validateSourcePatterns executions: $(grep -c '> Task :solr:core:validateSourcePatterns' "$OUT/check.log")"
  echo "TRACKED_CHANGES_AFTER=$(git status --porcelain | grep -v '^?? gradle.properties' | wc -l)"
  echo "HEAD_AFTER=$(git rev-parse HEAD)"
  echo "CHECK END $(date -u +%FT%TZ)"
} >> "$OUT/check.log"
