#!/bin/bash
# PR 5314 successor: rerun the root check in the surviving clone after a runtime restart killed run 1. Phone agent.
set -u
CLONE=~/workspace/solr-clones/5314-root
OUT=~/workspace/tools/gate-5314-root/runs
exec 9>~/workspace/tools/.solr-test-queue.lock
flock 9
pkill -f 'Gradle[D]aemon' 2>/dev/null; sleep 2
rm -f ~/.gradle/caches/journal-1/journal-1.lock
cd "$CLONE" || exit 2
{
  echo "RESTART-RUN $(date -u +%FT%TZ) HEAD=$(git rev-parse HEAD)"
  echo "STATUS_BEFORE=$(git status --porcelain | grep -v '^?? gradle.properties' | wc -l)"
} >> "$OUT/check.log"
JAVA_TOOL_OPTIONS="-Djava.net.preferIPv4Stack=true -Djavax.net.ssl.trustStore=$HOME/workspace/tools/truststore-with-hatch-ca.jks" ~/workspace/tools/solr-gradle.sh --no-daemon check -x test >> "$OUT/check.log" 2>&1 9>&-
echo "check rc=$? (restart run)" >> "$OUT/check.log"
{
  echo "validateSourcePatterns executions: $(grep -c '> Task :solr:core:validateSourcePatterns' "$OUT/check.log")"
  echo "TRACKED_CHANGES_AFTER=$(git status --porcelain | grep -v '^?? gradle.properties' | wc -l)"
  echo "HEAD_AFTER=$(git rev-parse HEAD)"
  echo "CHECK END $(date -u +%FT%TZ)"
} >> "$OUT/check.log"
