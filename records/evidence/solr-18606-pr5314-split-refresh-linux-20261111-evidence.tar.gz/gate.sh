#!/bin/bash
set -u
T=~/workspace/tools/5314-refresh; C=~/workspace/solr-clones/5314-refresh
SUM=$T/runs/summary.txt; : > $SUM
G=~/workspace/tools/solr-gradle.sh
run() { # name, module, seed, tests...
  local name=$1; shift; local mod=$1; shift; local seed=$1; shift
  rm -rf $C/solr/$mod/build/test-results/test $C/solr/$mod/build/reports/tests/test 2>/dev/null
  find $C/solr -path "*build/test-results/test" -name "TEST-*.xml" -delete 2>/dev/null
  timeout 2400 $G :solr:$mod:test "$@" -Ptests.seed=$seed --console=plain 9>&- > $T/runs/$name.log 2>&1
  echo "$name rc=$?" | tee -a $SUM
  mkdir -p $T/runs/$name-xml
  find $C/solr -path "*build/test-results/test/TEST-*.xml" -newer $T/runs/setup.log -exec cp {} $T/runs/$name-xml/ \; 2>/dev/null
  ls $T/runs/$name-xml/ | head -8 >> $SUM
}
cd $C
{
  flock 9
  pkill -f "Gradle[Daemon]" 2>/dev/null; sleep 1; rm -f ~/.gradle/caches/journal-1/journal-1.lock
  echo "== alias method seed CAFE $(date -Is)" | tee -a $SUM
  run alias-cafe solrj 18606CAFE --tests "org.apache.solr.client.solrj.impl.CloudHttp2SolrClientTest.testZkAliasDoesNotReadAliasCollectionState"
  echo "== alias method seed BEEF $(date -Is)" | tee -a $SUM
  run alias-beef solrj 18606BEEF --tests "org.apache.solr.client.solrj.impl.CloudHttp2SolrClientTest.testZkAliasDoesNotReadAliasCollectionState"
  echo "== solrj provider suites $(date -Is)" | tee -a $SUM
  run solrj-suites solrj 18606CAFE --tests org.apache.solr.client.solrj.impl.ClusterStateProviderTest --tests org.apache.solr.client.solrj.impl.CloudSolrClientCacheTest --tests org.apache.solr.client.solrj.impl.CloudSolrClientRoutingTest
  echo "== core suites $(date -Is)" | tee -a $SUM
  run core-suites core 18606CAFE --tests org.apache.solr.cloud.overseer.ZkStateReaderTest --tests org.apache.solr.cloud.AliasIntegrationTest
  echo "== solrj-zookeeper SolrZkClientTest $(date -Is)" | tee -a $SUM
  run zkclient solrj-zookeeper 18606CAFE --tests org.apache.solr.common.cloud.SolrZkClientTest
} 9>~/workspace/tools/.solr-test-queue.lock
echo "TEST LEGS DONE $(date -Is)" | tee -a $SUM
