#!/bin/bash
set -u
T=~/workspace/tools/5314-refresh; SUM=$T/runs/summary.txt
C=~/workspace/solr-clones/5314-refresh-mut
rm -rf "$C"; cp -a ~/workspace/solr-clones/5314-refresh "$C"
cd "$C"
P=solr/solrj-zookeeper/src/java/org/apache/solr/client/solrj/impl/ZkClientClusterStateProvider.java
python3 - <<'PYEOF'
p = 'solr/solrj-zookeeper/src/java/org/apache/solr/client/solrj/impl/ZkClientClusterStateProvider.java'
s = open(p).read()
old = "if (ref != null || reader.getAliases().hasAlias(collection)) {"
new = "if (ref != null) { // MUTATION: known-alias guard removed"
assert old in s
open(p, 'w').write(s.replace(old, new))
print('mutation inserted')
PYEOF
git diff > $T/runs/mutation.diff; cat $T/runs/mutation.diff
{
  flock 9
  pkill -f "Gradle[Daemon]" 2>/dev/null; sleep 1; rm -f ~/.gradle/caches/journal-1/journal-1.lock
  find solr -path "*build/test-results/test" -name "TEST-*.xml" -delete 2>/dev/null
  timeout 1800 ~/workspace/tools/solr-gradle.sh :solr:solrj:test --tests "org.apache.solr.client.solrj.impl.CloudHttp2SolrClientTest.testZkAliasDoesNotReadAliasCollectionState" -Ptests.seed=18606CAFE --console=plain 9>&- > $T/runs/mut-alias.log 2>&1
  echo "mut-alias rc=$?" | tee -a $SUM
  cp solr/solrj/build/test-results/test/TEST-org.apache.solr.client.solrj.impl.CloudHttp2SolrClientTest.xml $T/runs/mut-alias.xml 2>/dev/null || echo "mut XML MISSING" | tee -a $SUM
} 9>~/workspace/tools/.solr-test-queue.lock
echo "MUTATION LEG DONE $(date -Is)" | tee -a $SUM
