#!/bin/bash
set -u
T=~/workspace/tools/5314-refresh; C=~/workspace/solr-clones/5314-refresh; SUM=$T/runs/summary.txt
cd $C
{
  flock 9
  pkill -f "Gradle[Daemon]" 2>/dev/null; sleep 1; rm -f ~/.gradle/caches/journal-1/journal-1.lock
  timeout 1200 ~/workspace/tools/solr-gradle.sh tidy --console=plain 9>&- > $T/runs/tidy.log 2>&1
  echo "tidy rc=$? tracked changes: $(git status --porcelain | wc -l)" | tee -a $SUM
  git status --porcelain >> $SUM
  pkill -f "Gradle[Daemon]" 2>/dev/null; sleep 1; rm -f ~/.gradle/caches/journal-1/journal-1.lock
  timeout 3600 ~/workspace/tools/solr-gradle.sh check -x test --console=plain 9>&- > $T/runs/check.log 2>&1
  echo "check rc=$?" | tee -a $SUM
  grep -E "BUILD (SUCCESSFUL|FAILED)" $T/runs/check.log | tail -1 | tee -a $SUM
} 9>~/workspace/tools/.solr-test-queue.lock
echo "TIDY+CHECK DONE $(date -Is)" | tee -a $SUM
