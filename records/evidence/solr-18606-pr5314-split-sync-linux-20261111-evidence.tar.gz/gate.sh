#!/bin/bash
set -u
T=~/workspace/tools/5314-sync; C=~/workspace/solr-clones/5314-sync; SUM=$T/runs/summary.txt; : > $SUM
G=~/workspace/tools/solr-gradle.sh
cd $C
{
  flock 9
  pkill -f "Gradle[Daemon]" 2>/dev/null; sleep 1; rm -f ~/.gradle/caches/journal-1/journal-1.lock
  find solr -path "*build/test-results/test" -name "TEST-*.xml" -delete 2>/dev/null
  timeout 2400 $G :solr:solrj-zookeeper:test --tests org.apache.solr.common.cloud.SolrZkClientTest -Ptests.seed=18606CAFE --console=plain 9>&- > $T/runs/zkclient.log 2>&1
  echo "zkclient rc=$?" | tee -a $SUM
  mkdir -p $T/runs/zkclient-xml; cp solr/solrj-zookeeper/build/test-results/test/TEST-*.xml $T/runs/zkclient-xml/ 2>/dev/null
  find solr -path "*build/test-results/test" -name "TEST-*.xml" -delete 2>/dev/null
  timeout 2400 $G :solr:core:test --tests org.apache.solr.cloud.overseer.ZkStateReaderTest --tests org.apache.solr.update.TestInPlaceUpdatesDistrib -Ptests.seed=18606CAFE --console=plain 9>&- > $T/runs/core.log 2>&1
  echo "core rc=$?" | tee -a $SUM
  mkdir -p $T/runs/core-xml; cp solr/core/build/test-results/test/TEST-*.xml $T/runs/core-xml/ 2>/dev/null
  timeout 1200 $G tidy --console=plain 9>&- > $T/runs/tidy.log 2>&1
  echo "tidy rc=$? tracked changes: $(git status --porcelain | wc -l)" | tee -a $SUM
  git status --porcelain >> $SUM
  pkill -f "Gradle[Daemon]" 2>/dev/null; sleep 1; rm -f ~/.gradle/caches/journal-1/journal-1.lock
  timeout 3600 $G check -x test --console=plain 9>&- > $T/runs/check.log 2>&1
  echo "check rc=$?" | tee -a $SUM
  grep -E "BUILD (SUCCESSFUL|FAILED)" $T/runs/check.log | tail -1 | tee -a $SUM
} 9>~/workspace/tools/.solr-test-queue.lock
echo "SYNC GATE MAIN LEGS DONE $(date -Is)" | tee -a $SUM
