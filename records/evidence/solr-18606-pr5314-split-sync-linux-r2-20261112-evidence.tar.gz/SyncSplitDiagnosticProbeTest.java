/*
 * Licensed to the Apache Software Foundation (ASF) under one or more
 * contributor license agreements.  See the NOTICE file distributed with
 * this work for additional information regarding copyright ownership.
 * The ASF licenses this file to You under the Apache License, Version 2.0
 * (the "License"); you may not use this file except in compliance with
 * the License.  You may obtain a copy of the License at
 *
 *     http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
package org.apache.solr.client.solrj.impl;

import static org.mockito.ArgumentMatchers.any;
import static org.mockito.ArgumentMatchers.anyString;
import static org.mockito.ArgumentMatchers.eq;
import static org.mockito.Mockito.clearInvocations;
import static org.mockito.Mockito.doReturn;
import static org.mockito.Mockito.inOrder;
import static org.mockito.Mockito.mock;
import static org.mockito.Mockito.spy;
import static org.mockito.Mockito.when;

import java.time.Instant;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.concurrent.CountDownLatch;
import java.util.concurrent.ExecutionException;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Future;
import java.util.concurrent.TimeUnit;
import java.util.concurrent.TimeoutException;
import java.util.concurrent.atomic.AtomicReference;
import org.apache.curator.framework.CuratorFramework;
import org.apache.curator.framework.api.BackgroundCallback;
import org.apache.curator.framework.api.CuratorEvent;
import org.apache.curator.framework.api.ErrorListenerPathable;
import org.apache.curator.framework.api.SyncBuilder;
import org.apache.solr.SolrTestCase;
import org.apache.solr.SolrTestCaseJ4;
import org.apache.solr.cloud.Stats;
import org.apache.solr.cloud.ZkController;
import org.apache.solr.cloud.ZkTestServer;
import org.apache.solr.cloud.overseer.ZkStateWriter;
import org.apache.solr.cloud.overseer.ZkWriteCommand;
import org.apache.solr.common.cloud.DocCollection;
import org.apache.solr.common.cloud.DocRouter;
import org.apache.solr.common.cloud.PerReplicaStatesOps;
import org.apache.solr.common.cloud.SolrZkClient;
import org.apache.solr.common.cloud.ZkStateReader;
import org.apache.solr.common.util.ExecutorUtil;
import org.apache.solr.common.util.SolrNamedThreadFactory;
import org.apache.solr.handler.admin.ConfigSetsHandler;
import org.apache.zookeeper.KeeperException;
import org.junit.Test;

/**
 * Disposable diagnostic probe for the SOLR-18606 sync split. Not part of the branch; it exists
 * only to demonstrate, behaviorally, that SolrZkClient.sync waits for its callback, maps a
 * callback error, and honors interruption, and that ZkStateReader.forceUpdateCollection invokes
 * sync before its reads without holding the update lock while it waits. The sync wait/error
 * technique adapts the prior combined-branch diagnostic
 * ClusterStateProviderTest.testSyncWaitsForCallbackAndPropagatesFailure (head 5da7243).
 */
public class SyncSplitDiagnosticProbeTest extends SolrTestCase {

  private static final long TIMEOUT_SECONDS = 30;

  private static class SyncMock {
    final AtomicReference<BackgroundCallback> callback = new AtomicReference<>();
    final CountDownLatch started = new CountDownLatch(1);
  }

  private SyncMock stubCuratorSync(SolrZkClient zkClient) throws Exception {
    SyncMock syncMock = new SyncMock();
    CuratorFramework curator = mock(CuratorFramework.class);
    SyncBuilder builder = mock(SyncBuilder.class);
    @SuppressWarnings("unchecked")
    ErrorListenerPathable<Void> operation = mock(ErrorListenerPathable.class);
    doReturn(curator).when(zkClient).getCuratorFramework();
    when(curator.sync()).thenReturn(builder);
    when(builder.inBackground(any(BackgroundCallback.class)))
        .thenAnswer(
            invocation -> {
              syncMock.callback.set(invocation.getArgument(0));
              return operation;
            });
    when(operation.forPath(anyString()))
        .thenAnswer(
            invocation -> {
              syncMock.started.countDown();
              return null;
            });
    return syncMock;
  }

  private CuratorEvent eventWithCode(KeeperException.Code code) {
    CuratorEvent event = mock(CuratorEvent.class);
    when(event.getResultCode()).thenReturn(code.intValue());
    return event;
  }

  private ExecutorService newExecutor() {
    return ExecutorUtil.newMDCAwareFixedThreadPool(
        1, new SolrNamedThreadFactory("zk-sync-probe"));
  }

  @Test
  public void testSyncWaitsForCallbackAndMapsError() throws Exception {
    SolrTestCaseJ4.assumeWorkingMockito();
    ZkTestServer server = new ZkTestServer(createTempDir("sync-probe-wait"));
    server.run();
    try (SolrZkClient realClient =
        new SolrZkClient.Builder().withUrl(server.getZkAddress()).build()) {
      SolrZkClient zkClient = spy(realClient);
      SyncMock syncMock = stubCuratorSync(zkClient);
      ExecutorService executor = newExecutor();
      try {
        Future<?> result =
            executor.submit(
                () -> {
                  zkClient.sync(ZkStateReader.COLLECTIONS_ZKNODE);
                  return null;
                });
        assertTrue(syncMock.started.await(TIMEOUT_SECONDS, TimeUnit.SECONDS));
        // The callback has not fired: sync must still be waiting.
        expectThrows(TimeoutException.class, () -> result.get(200, TimeUnit.MILLISECONDS));
        syncMock
            .callback
            .get()
            .processResult(zkClient.getCuratorFramework(), eventWithCode(KeeperException.Code.CONNECTIONLOSS));
        ExecutionException error =
            expectThrows(
                ExecutionException.class, () -> result.get(TIMEOUT_SECONDS, TimeUnit.SECONDS));
        assertTrue(
            "expected ConnectionLossException, got " + error.getCause(),
            error.getCause() instanceof KeeperException.ConnectionLossException);
      } finally {
        executor.shutdownNow();
        assertTrue(executor.awaitTermination(TIMEOUT_SECONDS, TimeUnit.SECONDS));
      }
    } finally {
      server.shutdown();
    }
  }

  @Test
  public void testSyncHonorsInterruption() throws Exception {
    SolrTestCaseJ4.assumeWorkingMockito();
    ZkTestServer server = new ZkTestServer(createTempDir("sync-probe-interrupt"));
    server.run();
    try (SolrZkClient realClient =
        new SolrZkClient.Builder().withUrl(server.getZkAddress()).build()) {
      SolrZkClient zkClient = spy(realClient);
      SyncMock syncMock = stubCuratorSync(zkClient);
      ExecutorService executor = newExecutor();
      try {
        AtomicReference<Thread> syncThread = new AtomicReference<>();
        CountDownLatch entered = new CountDownLatch(1);
        Future<?> result =
            executor.submit(
                () -> {
                  syncThread.set(Thread.currentThread());
                  entered.countDown();
                  zkClient.sync(ZkStateReader.COLLECTIONS_ZKNODE);
                  return null;
                });
        assertTrue(entered.await(TIMEOUT_SECONDS, TimeUnit.SECONDS));
        assertTrue(syncMock.started.await(TIMEOUT_SECONDS, TimeUnit.SECONDS));
        syncThread.get().interrupt();
        // The callback never fires and the client timeout is far longer than this window:
        // only honoring the interruption lets the call complete here.
        ExecutionException error =
            expectThrows(ExecutionException.class, () -> result.get(10, TimeUnit.SECONDS));
        assertTrue(
            "expected InterruptedException, got " + error.getCause(),
            error.getCause() instanceof InterruptedException);
      } finally {
        executor.shutdownNow();
        assertTrue(executor.awaitTermination(TIMEOUT_SECONDS, TimeUnit.SECONDS));
      }
    } finally {
      server.shutdown();
    }
  }

  @Test
  public void testForceUpdateCollectionSyncsBeforeReads() throws Exception {
    SolrTestCaseJ4.assumeWorkingMockito();
    ZkTestServer server = new ZkTestServer(createTempDir("sync-probe-order"));
    server.run();
    SolrZkClient realClient = null;
    SolrZkClient zkClient = null;
    ZkStateReader reader = null;
    try {
      realClient = new SolrZkClient.Builder().withUrl(server.getZkAddress()).build();
      zkClient = spy(realClient);
      ZkController.createClusterZkNodes(zkClient);
      reader = new ZkStateReader(zkClient);
      reader.createClusterStateWatchersAndUpdate();
      ZkStateWriter writer =
          new ZkStateWriter(reader, new Stats(), -1, new org.apache.solr.common.util.ZLibCompressor());
      synchronized (reader.getUpdateLock()) {
        zkClient.makePath(ZkStateReader.COLLECTIONS_ZKNODE + "/probe_collection", true);
        DocCollection state =
            DocCollection.create(
                "probe_collection",
                new HashMap<>(),
                Map.of(ZkStateReader.CONFIGNAME_PROP, ConfigSetsHandler.DEFAULT_CONFIGSET_NAME),
                DocRouter.DEFAULT,
                0,
                Instant.now(),
                PerReplicaStatesOps.getZkClientPrsSupplier(
                    zkClient, DocCollection.getCollectionPath("probe_collection")));
        writer.enqueueUpdate(
            reader.getClusterState(), List.of(new ZkWriteCommand("probe_collection", state)), null);
        writer.writePendingUpdates();
        // The watcher cannot publish the new collection while this lock is held.
        assertNull(reader.getClusterState().getCollectionRef("probe_collection"));
        clearInvocations(zkClient);
        reader.forceUpdateCollection("probe_collection");
        assertNotNull(reader.getClusterState().getCollectionRef("probe_collection"));
      }
      var order = inOrder(zkClient);
      order.verify(zkClient).sync(ZkStateReader.COLLECTIONS_ZKNODE);
      order
          .verify(zkClient)
          .getData(eq(DocCollection.getCollectionPath("probe_collection")), any(), any());
    } finally {
      if (reader != null) reader.close();
      // Close the real client, not the spy: the release tracker keys on the constructed
      // instance, and a call through the spy releases the spy, which was never tracked.
      if (realClient != null) realClient.close();
      server.shutdown();
    }
  }

  @Test
  public void testForceUpdateCollectionDoesNotHoldUpdateLockWhileSyncWaits() throws Exception {
    SolrTestCaseJ4.assumeWorkingMockito();
    ZkTestServer server = new ZkTestServer(createTempDir("sync-probe-lock"));
    server.run();
    SolrZkClient realClient = null;
    SolrZkClient zkClient = null;
    ZkStateReader reader = null;
    try {
      realClient = new SolrZkClient.Builder().withUrl(server.getZkAddress()).build();
      zkClient = spy(realClient);
      ZkController.createClusterZkNodes(zkClient);
      reader = new ZkStateReader(zkClient);
      reader.createClusterStateWatchersAndUpdate();
      // Stub only after watcher setup, so setup uses the real framework throughout.
      SyncMock syncMock = stubCuratorSync(zkClient);
      final ZkStateReader finalReader = reader;
      ExecutorService executor = newExecutor();
      try {
        Future<?> result =
            executor.submit(
                () -> {
                  finalReader.forceUpdateCollection("probe_collection");
                  return null;
                });
        assertTrue(syncMock.started.await(TIMEOUT_SECONDS, TimeUnit.SECONDS));
        // While the sync callback is withheld, the update lock must be acquirable.
        CountDownLatch acquired = new CountDownLatch(1);
        Thread lockThread =
            new Thread(
                () -> {
                  synchronized (finalReader.getUpdateLock()) {
                    acquired.countDown();
                  }
                });
        lockThread.start();
        assertTrue(
            "update lock was held while sync waited",
            acquired.await(5, TimeUnit.SECONDS));
        lockThread.join(TIMEOUT_SECONDS * 1000);
        // Release the waiter with an error: forceUpdateCollection must surface it from sync,
        // before any read is attempted.
        syncMock
            .callback
            .get()
            .processResult(zkClient.getCuratorFramework(), eventWithCode(KeeperException.Code.CONNECTIONLOSS));
        ExecutionException error =
            expectThrows(
                ExecutionException.class, () -> result.get(TIMEOUT_SECONDS, TimeUnit.SECONDS));
        assertTrue(
            "expected ConnectionLossException, got " + error.getCause(),
            error.getCause() instanceof KeeperException.ConnectionLossException);
      } finally {
        executor.shutdownNow();
        assertTrue(executor.awaitTermination(TIMEOUT_SECONDS, TimeUnit.SECONDS));
      }
    } finally {
      if (reader != null) reader.close();
      if (realClient != null) realClient.close();
      server.shutdown();
    }
  }
}
