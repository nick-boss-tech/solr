#!/bin/bash
set -u
T=~/workspace/tools/5314-sync; SUM=$T/runs/summary-r2.txt
C=~/workspace/solr-clones/5314-sync-probe
rm -rf "$C"; mkdir -p "$C"; cd ~/workspace/solr-clones/5314-sync-r2 && git archive HEAD | tar -x -C "$C"; cp gradle.properties "$C"/
mkdir -p "$C/solr/webapp/build/ui-download"; cp solr/webapp/build/ui-download/solr-ui-wasm-473a55ef64a9a1605e00eb6c1c386887d4cb7dac.zip "$C/solr/webapp/build/ui-download/" 2>/dev/null || true
cp $T/SyncSplitDiagnosticProbeTest.java "$C/solr/solrj/src/test/org/apache/solr/client/solrj/impl/"
cd "$C"
{
  flock 9
  pkill -f "Gradle[Daemon]" 2>/dev/null; sleep 1; rm -f ~/.gradle/caches/journal-1/journal-1.lock
  timeout 2400 ~/workspace/tools/solr-gradle.sh :solr:solrj:test --tests org.apache.solr.client.solrj.impl.SyncSplitDiagnosticProbeTest -Ptests.seed=18606CAFE --console=plain 9>&- > $T/runs/r2-probe.log 2>&1
  echo "r2 probe rc=$?" | tee -a $SUM
  cp solr/solrj/build/test-results/test/TEST-org.apache.solr.client.solrj.impl.SyncSplitDiagnosticProbeTest.xml $T/runs/r2-probe.xml 2>/dev/null || echo "probe XML MISSING" | tee -a $SUM
} 9>~/workspace/tools/.solr-test-queue.lock
echo "PROBE DONE $(date -Is)" | tee -a $SUM
