#!/bin/bash
set -u
T=~/workspace/tools/5314-sync; SUM=$T/runs/summary-r2.txt; : > $SUM
C=~/workspace/solr-clones/5314-sync-r2
rm -rf "$C"; mkdir -p "$C"; cd "$C"
git init -q .; git remote add origin https://github.com/nick-boss-tech/solr.git
for attempt in 1 2 3 4 5; do git fetch -q --depth 10 origin solr-18606-sync-split && break; sleep 5; done
git checkout -q d17427ca2cf164f75d3072b8a07767e1e38f5cc4
echo "HEAD=$(git rev-parse HEAD) modified=$(git status --porcelain | wc -l)" | tee -a $SUM
cp ~/workspace/solr/gradle.properties .
# seed the UI wasm zip (egress relay corrupts the Gradle download; verified remedy)
mkdir -p solr/webapp/build/ui-download
curl -sL --max-time 300 -o solr/webapp/build/ui-download/solr-ui-wasm-473a55ef64a9a1605e00eb6c1c386887d4cb7dac.zip https://nightlies.apache.org/solr/ui/wasm/473a55ef64a9a1605e00eb6c1c386887d4cb7dac/solr-ui-wasm.zip
echo "wasm sha: $(sha256sum solr/webapp/build/ui-download/solr-ui-wasm-473a55ef64a9a1605e00eb6c1c386887d4cb7dac.zip | cut -d' ' -f1) (pin 654494303e4af3b8bfb26a83d250603f19033820295591d88db0597991ce8ad2)" | tee -a $SUM
G=~/workspace/tools/solr-gradle.sh
{
  flock 9
  pkill -f "Gradle[Daemon]" 2>/dev/null; sleep 1; rm -f ~/.gradle/caches/journal-1/journal-1.lock
  find solr -path "*build/test-results/test" -name "TEST-*.xml" -delete 2>/dev/null
  timeout 2400 $G :solr:solrj-zookeeper:test --tests org.apache.solr.common.cloud.SolrZkClientTest -Ptests.seed=18606CAFE --console=plain 9>&- > $T/runs/r2-zkclient.log 2>&1
  echo "r2 zkclient rc=$?" | tee -a $SUM
  mkdir -p $T/runs/r2-zkclient-xml; cp solr/solrj-zookeeper/build/test-results/test/TEST-*.xml $T/runs/r2-zkclient-xml/ 2>/dev/null
  find solr -path "*build/test-results/test" -name "TEST-*.xml" -delete 2>/dev/null
  timeout 2400 $G :solr:core:test --tests org.apache.solr.cloud.overseer.ZkStateReaderTest --tests org.apache.solr.update.TestInPlaceUpdatesDistrib -Ptests.seed=18606CAFE --console=plain 9>&- > $T/runs/r2-core.log 2>&1
  echo "r2 core rc=$?" | tee -a $SUM
  mkdir -p $T/runs/r2-core-xml; cp solr/core/build/test-results/test/TEST-*.xml $T/runs/r2-core-xml/ 2>/dev/null
  timeout 1200 $G tidy --console=plain 9>&- > $T/runs/r2-tidy.log 2>&1
  echo "r2 tidy rc=$? tracked changes: $(git status --porcelain | grep -v '^??' | wc -l)" | tee -a $SUM
  pkill -f "Gradle[Daemon]" 2>/dev/null; sleep 1; rm -f ~/.gradle/caches/journal-1/journal-1.lock
  timeout 3600 $G check -x test --console=plain 9>&- > $T/runs/r2-check.log 2>&1
  echo "r2 check rc=$?" | tee -a $SUM
  grep -E "BUILD (SUCCESSFUL|FAILED)" $T/runs/r2-check.log | tail -1 | tee -a $SUM
} 9>~/workspace/tools/.solr-test-queue.lock
echo "R2 MAIN LEGS DONE $(date -Is)" | tee -a $SUM
