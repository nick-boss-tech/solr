import org.apache.solr.common.util.EnvUtils;

public final class MixedSourcePrecedenceProbe {
  public static void main(String[] args) {
    System.out.println("INPUT_ENV=" + System.getenv("SOLR_CLOUD_WAIT_FOR_ZK_SECONDS"));
    System.out.println("INPUT_LEGACY_SYS=" + System.getProperty("solr.wait.for.zk"));
    System.out.println("INPUT_CURRENT_SYS=" + System.getProperty("solr.cloud.wait.for.zk.seconds"));
    String value = EnvUtils.getProperty("solr.cloud.wait.for.zk.seconds");
    System.out.println("RESULT=" + (value == null ? "<unset>" : value));
    System.out.println("ENVUTILS_ORIGIN=" + EnvUtils.class.getProtectionDomain().getCodeSource().getLocation());
  }
}
