#!/bin/bash
# SOLR-18630 / PR 5313 mixed-source precedence probe: 4 cases x 3 revisions. Phone agent.
set -u
G=~/workspace/tools/gate-5313-mixed
JAVA21=~/workspace/tools/jdk21/jdk-21.0.12.1+1/bin/java
JAVAC21=~/workspace/tools/jdk21/jdk-21.0.12.1+1/bin/javac
export JAVA="$JAVA21"
exec 9>~/workspace/tools/.solr-test-queue.lock
flock 9
pkill -f 'Gradle[D]aemon' 2>/dev/null; sleep 2
rm -f ~/.gradle/caches/journal-1/journal-1.lock

run_revision() {
  local name="$1" sha="$2" fetchspec="$3" origin="$4"
  local clone=~/workspace/solr-clones/5313mx-$name
  local log="$G/runs/$name.log"
  rm -rf "$clone"
  git clone -q ~/workspace/solr "$clone" || { echo "CLONE FAIL $name" >> "$log"; return; }
  cd "$clone" || return
  git fetch -q "$origin" "$fetchspec" || { echo "FETCH FAIL $name" >> "$log"; return; }
  git checkout -q "$sha" || { echo "CHECKOUT FAIL $name" >> "$log"; return; }
  cp ~/workspace/solr/gradle.properties .
  {
    echo "REVISION $name HEAD=$(git rev-parse HEAD)"
    echo "SETUP START $(date -u +%FT%TZ)"
  } > "$log"
  ~/workspace/tools/solr-gradle.sh --no-daemon -I ~/workspace/tools/gate-5313/print-test-classpath.init.gradle :solr:core:printGateProbeClasspath :solr:core:compileJava :solr:solrj:processResources :solr:api:processResources :solr:solrj-zookeeper:processResources :solr:solrj-streaming:processResources :solr:solrj-jetty:processResources >> "$log" 2>&1 9>&-
  echo "gradle setup rc=$?" >> "$log"
  local printed
  printed=$(grep -m1 '^GATE_PROBE_CP=' "$log" | sed 's/^GATE_PROBE_CP=//')
  if [ -z "$printed" ]; then echo "NO PRINTED CP $name" >> "$log"; return; fi
  # Prepend built main classes/resources for every module that has them.
  local prepend="" d
  for d in $(find solr -type d -path '*/build/classes/java/main' 2>/dev/null; find solr -type d -path '*/build/resources/main' 2>/dev/null); do
    prepend="$prepend:$clone/$d"
  done
  # Keep only classpath entries that exist on disk.
  local kept="" e
  IFS=':' read -ra entries <<< "$printed"
  for e in "${entries[@]}"; do
    [ -e "$e" ] && kept="$kept:$e"
  done
  export GATE_PROBE_CP="${prepend#:}$kept"
  echo "CP entries kept: $(echo "$GATE_PROBE_CP" | tr ':' '\n' | wc -l)" >> "$log"
  export PROBE_CLASSES="$G/probe-classes-$name"
  rm -rf "$PROBE_CLASSES"; mkdir -p "$PROBE_CLASSES"
  "$JAVAC21" -cp "$GATE_PROBE_CP" -d "$PROBE_CLASSES" "$G/MixedSourcePrecedenceProbe.java" >> "$log" 2>&1
  echo "javac rc=$?" >> "$log"
  # The four cases, exactly as specified in the gate record.
  echo "CASE mixed_legacy_system_current_environment" >> "$log"
  env -i HOME="$HOME" PATH="$PATH" LANG=C.UTF-8 SOLR_CLOUD_WAIT_FOR_ZK_SECONDS=5 "$JAVA" -Dsolr.wait.for.zk=1 -cp "$PROBE_CLASSES:$GATE_PROBE_CP" MixedSourcePrecedenceProbe >> "$log" 2>&1
  echo "exit=$?" >> "$log"
  echo "CASE legacy_system_only_control" >> "$log"
  env -i HOME="$HOME" PATH="$PATH" LANG=C.UTF-8 "$JAVA" -Dsolr.wait.for.zk=1 -cp "$PROBE_CLASSES:$GATE_PROBE_CP" MixedSourcePrecedenceProbe >> "$log" 2>&1
  echo "exit=$?" >> "$log"
  echo "CASE current_environment_only_control" >> "$log"
  env -i HOME="$HOME" PATH="$PATH" LANG=C.UTF-8 SOLR_CLOUD_WAIT_FOR_ZK_SECONDS=5 "$JAVA" -cp "$PROBE_CLASSES:$GATE_PROBE_CP" MixedSourcePrecedenceProbe >> "$log" 2>&1
  echo "exit=$?" >> "$log"
  echo "CASE both_system_properties_control" >> "$log"
  env -i HOME="$HOME" PATH="$PATH" LANG=C.UTF-8 "$JAVA" -Dsolr.wait.for.zk=1 -Dsolr.cloud.wait.for.zk.seconds=5 -cp "$PROBE_CLASSES:$GATE_PROBE_CP" MixedSourcePrecedenceProbe >> "$log" 2>&1
  echo "exit=$?" >> "$log"
  echo "REVISION $name END $(date -u +%FT%TZ)" >> "$log"
}

run_revision base b771587e9707c49847d728fd1f3ff259a182692c b771587e9707c49847d728fd1f3ff259a182692c ~/workspace/solr
run_revision contributor 358f13d9fdfaed260143a51100cd5657a582d562 refs/pull/5313/head https://github.com/apache/solr.git
run_revision offered 4be1ad602621d2af96565355dce3804ee4744aae 4be1ad602621d2af96565355dce3804ee4744aae https://github.com/nick-boss-tech/solr.git
echo "ALL REVISIONS DONE $(date -u +%FT%TZ)"
