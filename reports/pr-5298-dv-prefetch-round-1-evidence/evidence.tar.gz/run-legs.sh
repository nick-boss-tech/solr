#!/bin/bash
# PR 5298 gate legs: P failures, H passes, suites, Error Prone, root check. Serialized under the host lock.
set -u
OUT=~/workspace/tools/gate-5298
H=4d547451e3914de441fc897ea6a8c0652a48736a
B=7ee68a7000b67bed06ad3130ffff27a086a56aad
CH=~/workspace/solr-clones/5298-h
CP=~/workspace/solr-clones/5298-p
TESTFILE=solr/core/src/test/org/apache/solr/BasicFunctionalityTest.java
SEED=5298C0DE
mkdir -p $OUT
exec 9>~/workspace/tools/.solr-test-queue.lock
flock 9
exec > >(tee -a $OUT/legs.log) 2>&1
echo "legs start UTC: $(date -u +%FT%TZ)"
pkill -f "Gradle[D]aemon" 2>/dev/null; sleep 2
rm -f ~/.gradle/caches/journal-1/journal-1.lock

# ---- P construction: B + H test file only ----
cd $CP || exit 1
echo "P HEAD before overlay: $(git rev-parse HEAD)"
git checkout $H -- $TESTFILE || exit 1
echo "P changed files vs B:"; git diff $B --name-only
echo "P test blob: $(git hash-object $TESTFILE) (expect 379421ae51cef1a9e4b58f0c9889c5ef5e7def6c)"
echo "P test sha256: $(sha256sum $TESTFILE | cut -d' ' -f1) (expect f44182b29339e09d2f3fa41db835fec781495bce052a8b912ecef1c7e57dc6ca)"
echo "P production diff vs B (must be empty):"; git diff $B -- solr/core/src/java | head -5

copy_xml() { # $1 = leg label, $2 = clone dir
  mkdir -p $OUT/$1-xml
  cp $2/solr/core/build/test-results/test/*.xml $OUT/$1-xml/ 2>/dev/null || echo "no XML copied for $1"
}

# ---- P legs: three methods, separate invocations ----
for m in testGlobNonStoredDocValuesPrefetch testGlobSubstitutedDocValuesPrefetch testGlobEmptyPrefetch; do
  cd $CP
  echo "=== P leg $m start UTC: $(date -u +%FT%TZ)"
  ~/workspace/tools/solr-gradle.sh :solr:core:cleanTest :solr:core:test --tests "org.apache.solr.BasicFunctionalityTest.$m" -Ptests.seed=$SEED 9>&- > $OUT/p-$m.log 2>&1
  echo "P leg $m rc=$?"
  copy_xml p-$m $CP
done

# ---- H leg: nine methods ----
cd $CH || exit 1
echo "H HEAD: $(git rev-parse HEAD)"
echo "=== H nine-method leg start UTC: $(date -u +%FT%TZ)"
~/workspace/tools/solr-gradle.sh :solr:core:cleanTest :solr:core:test --tests 'org.apache.solr.BasicFunctionalityTest.testGlob*' --tests org.apache.solr.search.TestPseudoReturnFields.testGlobRTGUncommittedFields -Ptests.seed=$SEED 9>&- > $OUT/h-nine.log 2>&1
echo "H nine-method rc=$?"
copy_xml h-nine $CH

# ---- H leg: full neighbor suites ----
echo "=== H suites leg start UTC: $(date -u +%FT%TZ)"
~/workspace/tools/solr-gradle.sh :solr:core:cleanTest :solr:core:test --tests org.apache.solr.BasicFunctionalityTest --tests org.apache.solr.search.TestPseudoReturnFields --tests org.apache.solr.response.TestRetrieveFieldsOptimizer --tests org.apache.solr.search.ReturnFieldsTest --tests org.apache.solr.highlight.TestUnifiedSolrHighlighter --tests org.apache.solr.search.LargeFieldTest -Ptests.seed=$SEED 9>&- > $OUT/h-suites.log 2>&1
echo "H suites rc=$?"
copy_xml h-suites $CH

# ---- H leg: Error Prone compile ----
echo "=== H Error Prone leg start UTC: $(date -u +%FT%TZ)"
~/workspace/tools/solr-gradle.sh :solr:core:compileJava :solr:core:compileTestJava -Pvalidation.errorprone=true 9>&- > $OUT/h-errorprone.log 2>&1
echo "H Error Prone rc=$?"

# ---- H leg: root check in the normal clone ----
pkill -f "Gradle[D]aemon" 2>/dev/null; sleep 2
rm -f ~/.gradle/caches/journal-1/journal-1.lock
echo "=== H root check leg start UTC: $(date -u +%FT%TZ)"
cd $CH
~/workspace/tools/solr-gradle.sh check -x test 9>&- > $OUT/h-rootcheck.log 2>&1
echo "H root check rc=$?"
echo "final H status:"; git -C $CH status --porcelain
echo "final P status:"; git -C $CP status --porcelain
echo "legs end UTC: $(date -u +%FT%TZ)"
