#!/bin/bash
# PR 5298 gate preflight: clones at H and B, tidy at H. Serialized under the host lock.
set -u
OUT=~/workspace/tools/gate-5298
H=4d547451e3914de441fc897ea6a8c0652a48736a
B=7ee68a7000b67bed06ad3130ffff27a086a56aad
CH=~/workspace/solr-clones/5298-h
CP=~/workspace/solr-clones/5298-p
mkdir -p $OUT
exec 9>~/workspace/tools/.solr-test-queue.lock
flock 9
exec > >(tee -a $OUT/preflight.log) 2>&1
echo "preflight start UTC: $(date -u +%FT%TZ)"
pkill -f "Gradle[D]aemon" 2>/dev/null; sleep 2
rm -f ~/.gradle/caches/journal-1/journal-1.lock
for pair in "$CH $H" "$CP $B"; do
  set -- $pair; dir=$1; sha=$2
  if [ -e "$dir" ]; then echo "ABORT: $dir already exists"; exit 1; fi
  git clone -q ~/workspace/solr "$dir" || exit 1
  cd "$dir" || exit 1
  git remote add fork https://github.com/nick-boss-tech/solr.git
  git fetch -q fork $H $B || exit 1
  git checkout -q $sha || exit 1
  cp ~/workspace/solr/gradle.properties .
  echo "$dir HEAD: $(git rev-parse HEAD)"
  echo "$dir tree: $(git rev-parse HEAD^{tree})"
  [ -d .git ] && echo "$dir .git is a directory" || echo "$dir .git NOT a directory"
done
cd $CH || exit 1
~/workspace/tools/solr-gradle.sh tidy 9>&- > $OUT/tidy.log 2>&1
echo "tidy rc=$?"
git status --porcelain | tee $OUT/tidy-status.txt
if git status --porcelain | grep -q 'gradle/libs.versions.toml'; then
  git checkout -- gradle/libs.versions.toml
  echo "restored libs.versions.toml prune"
fi
echo "post-tidy status:"; git status --porcelain
echo "preflight end UTC: $(date -u +%FT%TZ)"
