#!/bin/bash
# PR 5298 gate: root check leg rerun (first attempt killed by a runtime restart, no outcome)
set -u
OUT=~/workspace/tools/gate-5298
CH=~/workspace/solr-clones/5298-h
exec 9>~/workspace/tools/.solr-test-queue.lock
flock 9
exec > >(tee -a $OUT/rootcheck2.log) 2>&1
echo "rootcheck rerun start UTC: $(date -u +%FT%TZ)"
pkill -f "Gradle[D]aemon" 2>/dev/null; sleep 2
rm -f ~/.gradle/caches/journal-1/journal-1.lock
cd $CH || exit 1
echo "HEAD: $(git rev-parse HEAD)"; git status --porcelain
~/workspace/tools/solr-gradle.sh check -x test 9>&- > $OUT/h-rootcheck2.log 2>&1
echo "root check rc=$?"
tail -3 $OUT/h-rootcheck2.log
echo "rootcheck rerun end UTC: $(date -u +%FT%TZ)"
