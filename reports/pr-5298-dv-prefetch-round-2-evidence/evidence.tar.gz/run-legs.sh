#!/bin/bash
# PR 5298 gate round 2 legs at R: P negative legs x3, R nine methods, LargeFieldTest, six suites, Error Prone, root check. Host lock held.
set -u
OUT=~/workspace/tools/gate-5298-r2
R=a99e40291ae17fbee56b821113cc9bc15659b147
SEED=5298C0DE
RC=~/workspace/solr-clones/5298-h
PC=~/workspace/solr-clones/5298-p
G=~/workspace/tools/solr-gradle.sh
mkdir -p $OUT
exec 9>~/workspace/tools/.solr-test-queue.lock
flock 9
exec > >(tee -a $OUT/legs.log) 2>&1
echo "legs start UTC: $(date -u +%FT%TZ)"
pkill -f "Gradle[D]aemon" 2>/dev/null; sleep 2
rm -f ~/.gradle/caches/journal-1/journal-1.lock
copyxml() { mkdir -p $OUT/$2-xml; find $1 -path "*build/test-results/test/TEST-*.xml" -exec cp {} $OUT/$2-xml/ \; 2>/dev/null; ls $OUT/$2-xml/; }
# P negative legs
cd $PC || exit 1
echo "P HEAD: $(git rev-parse HEAD)"
for m in testGlobNonStoredDocValuesPrefetch testGlobSubstitutedDocValuesPrefetch testGlobEmptyPrefetch; do
  echo "=== P leg $m start UTC: $(date -u +%FT%TZ)"
  $G :solr:core:cleanTest :solr:core:test --tests "org.apache.solr.BasicFunctionalityTest.$m" -Ptests.seed=$SEED 9>&- > $OUT/p-$m.log 2>&1
  echo "P $m rc=$?"
  copyxml $PC p-$m
done
# R legs
cd $RC || exit 1
echo "R HEAD: $(git rev-parse HEAD) (expect $R)"
echo "=== R nine methods start UTC: $(date -u +%FT%TZ)"
$G :solr:core:cleanTest :solr:core:test --tests 'org.apache.solr.BasicFunctionalityTest.testGlob*' --tests org.apache.solr.search.TestPseudoReturnFields.testGlobRTGUncommittedFields -Ptests.seed=$SEED 9>&- > $OUT/r-nine.log 2>&1
echo "R nine rc=$?"
copyxml $RC r-nine
echo "=== R LargeFieldTest start UTC: $(date -u +%FT%TZ)"
$G :solr:core:cleanTest :solr:core:test --tests org.apache.solr.search.LargeFieldTest -Ptests.seed=$SEED 9>&- > $OUT/r-largefield.log 2>&1
echo "R LargeFieldTest rc=$?"
copyxml $RC r-largefield
echo "=== R six suites start UTC: $(date -u +%FT%TZ)"
$G :solr:core:cleanTest :solr:core:test --tests org.apache.solr.BasicFunctionalityTest --tests org.apache.solr.search.TestPseudoReturnFields --tests org.apache.solr.response.TestRetrieveFieldsOptimizer --tests org.apache.solr.search.ReturnFieldsTest --tests org.apache.solr.highlight.TestUnifiedSolrHighlighter --tests org.apache.solr.search.LargeFieldTest -Ptests.seed=$SEED 9>&- > $OUT/r-suites.log 2>&1
echo "R suites rc=$?"
copyxml $RC r-suites
echo "=== R Error Prone start UTC: $(date -u +%FT%TZ)"
$G :solr:core:compileJava :solr:core:compileTestJava -Pvalidation.errorprone=true 9>&- > $OUT/r-errorprone.log 2>&1
echo "R Error Prone rc=$?"
echo "=== R root check start UTC: $(date -u +%FT%TZ)"
$G check -x test 9>&- > $OUT/r-rootcheck.log 2>&1
echo "R root check rc=$?"
echo "legs end UTC: $(date -u +%FT%TZ)"
