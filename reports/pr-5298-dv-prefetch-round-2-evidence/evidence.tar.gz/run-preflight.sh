#!/bin/bash
# PR 5298 gate round 2 preflight: tidy at R in the R clone, pin verification. Host lock held.
set -u
OUT=~/workspace/tools/gate-5298-r2
R=a99e40291ae17fbee56b821113cc9bc15659b147
B=7ee68a7000b67bed06ad3130ffff27a086a56aad
RC=~/workspace/solr-clones/5298-h
PC=~/workspace/solr-clones/5298-p
mkdir -p $OUT
exec 9>~/workspace/tools/.solr-test-queue.lock
flock 9
exec > >(tee -a $OUT/preflight.log) 2>&1
echo "preflight start UTC: $(date -u +%FT%TZ)"
df -h /home/hatch | tail -1
pkill -f "Gradle[D]aemon" 2>/dev/null; sleep 2
rm -f ~/.gradle/caches/journal-1/journal-1.lock
cd $RC || exit 1
echo "R clone HEAD: $(git rev-parse HEAD) (expect $R)"
echo "R tree: $(git rev-parse HEAD^{tree})"
git status --porcelain | head -5
echo "--- tidy at R ---"
~/workspace/tools/solr-gradle.sh :solr:core:tidy 9>&- > $OUT/tidy.log 2>&1
echo "tidy rc=$?"
tail -3 $OUT/tidy.log
echo "--- tree after tidy ---"
git status --porcelain | tee $OUT/tidy-status.txt
if [ -s $OUT/tidy-status.txt ]; then echo "TIDY_DIRTY"; else echo "TIDY_CLEAN"; fi
cd $PC || exit 1
echo "P clone HEAD: $(git rev-parse HEAD) (expect $B)"
echo "P changes: $(git diff --name-only)"
echo "P test sha256: $(sha256sum solr/core/src/test/org/apache/solr/BasicFunctionalityTest.java | cut -d' ' -f1)"
echo "preflight end UTC: $(date -u +%FT%TZ)"
