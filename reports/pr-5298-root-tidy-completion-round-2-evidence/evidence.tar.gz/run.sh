#!/bin/bash
# PR 5298 root tidy completion at R. Host lock held.
set -u
OUT=~/workspace/tools/gate-5298-tidy
R=a99e40291ae17fbee56b821113cc9bc15659b147
RC=~/workspace/solr-clones/5298-h
mkdir -p $OUT
exec 9>~/workspace/tools/.solr-test-queue.lock
flock 9
exec > >(tee -a $OUT/run.log) 2>&1
echo "run start UTC: $(date -u +%FT%TZ)"
df -h /home/hatch | tail -1
pkill -f "Gradle[D]aemon" 2>/dev/null; sleep 2
rm -f ~/.gradle/caches/journal-1/journal-1.lock
cd $RC || exit 1
echo "HEAD before: $(git rev-parse HEAD) (expect $R)"
echo "tree before: $(git rev-parse HEAD^{tree})"
git status --porcelain | tee $OUT/status-before.txt
echo "=== root tidy start UTC: $(date -u +%FT%TZ)"
~/workspace/tools/solr-gradle.sh tidy 9>&- > $OUT/tidy.log 2>&1
echo "root tidy rc=$?"
tail -3 $OUT/tidy.log
echo "--- tree after tidy ---"
git status --porcelain | tee $OUT/status-after.txt
if [ -s $OUT/status-after.txt ]; then echo "TIDY_DIRTY"; git diff --stat | tee $OUT/tidy-diff-stat.txt; else echo "TIDY_CLEAN"; fi
echo "HEAD after: $(git rev-parse HEAD)"
echo "tree after: $(git rev-parse HEAD^{tree})"
echo "run end UTC: $(date -u +%FT%TZ)"
