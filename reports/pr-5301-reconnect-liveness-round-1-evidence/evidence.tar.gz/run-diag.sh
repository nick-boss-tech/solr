#!/bin/bash
# PR 5301 gate diagnostics: EP compile at H0 (base proof), stress same-seed rerun at H2, logchangeGenerate at H2. Host lock held.
set -u
OUT=~/workspace/tools/gate-5301
H2=27a9cf105b25f1bf3d604534cf8bdd8674c470fc
H0=01e820f0539cddc4697d26176d216614a776a99a
CL=~/workspace/solr-clones/5301-negb
SEED=5301C0DE
G8=~/workspace/tools/solr-gradle8.sh
mkdir -p $OUT
exec 9>~/workspace/tools/.solr-test-queue.lock
flock 9
exec > >(tee -a $OUT/diag.log) 2>&1
echo "diag start UTC: $(date -u +%FT%TZ)"
pkill -f "Gradle[D]aemon" 2>/dev/null; sleep 2
rm -f ~/.gradle/caches/journal-1/journal-1.lock
cd $CL || exit 1
git checkout -q -- . 2>/dev/null; git restore . 2>/dev/null
git fetch -q https://github.com/apache/solr.git refs/pull/5301/head:refs/heads/pr5301h0 || echo "PR ref fetch failed"
git checkout -q $H0
echo "diag clone HEAD (expect H0): $(git rev-parse HEAD)"
echo "=== EP compile at H0 start UTC: $(date -u +%FT%TZ)"
$G8 :solr:solrj-zookeeper:compileJava :solr:core:compileTestJava -Pvalidation.errorprone=true 9>&- > $OUT/ep-h0.log 2>&1
echo "EP at H0 rc=$?"
grep -E "warning: \[|FAILED|BUILD" $OUT/ep-h0.log | head -6
git checkout -q $H2
echo "diag clone HEAD (expect H2): $(git rev-parse HEAD)"
echo "=== stress rerun at H2 seed $SEED start UTC: $(date -u +%FT%TZ)"
$G8 :solr:core:cleanTest :solr:core:test --tests org.apache.solr.cloud.TestConnectionManagerReconnectStress -Ptests.nightly=true -Ptests.seed=$SEED --rerun-tasks 9>&- > $OUT/stress-rerun.log 2>&1
echo "stress rerun rc=$?"
mkdir -p $OUT/diag-stress-xml
find $CL -path "*build/test-results/test/TEST-org.apache.solr.cloud.TestConnectionManagerReconnectStress.xml" -exec cp {} $OUT/diag-stress-xml/ \; 2>/dev/null
ls $OUT/diag-stress-xml/
echo "=== logchangeGenerate at H2 start UTC: $(date -u +%FT%TZ)"
$G8 logchangeGenerate 9>&- > $OUT/logchange.log 2>&1
echo "logchangeGenerate rc=$?"
grep -rn "18623" solr/CHANGES.txt build/tmp/* 2>/dev/null | head -3
git status --porcelain | head -8
echo "diag end UTC: $(date -u +%FT%TZ)"
