#!/bin/bash
# PR 5301 gate legs at H2: positive legs, root check, negative legs A and B. Host lock held throughout.
set -u
OUT=~/workspace/tools/gate-5301
H2=27a9cf105b25f1bf3d604534cf8bdd8674c470fc
H0=01e820f0539cddc4697d26176d216614a776a99a
POS=~/workspace/solr-clones/5301-pos
NEA=~/workspace/solr-clones/5301-nega
NEB=~/workspace/solr-clones/5301-negb
CM=solr/solrj-zookeeper/src/java/org/apache/solr/common/cloud/ConnectionManager.java
OT=solr/core/src/test/org/apache/solr/common/cloud/ConnectionManagerOrderingTest.java
SEED=5301C0DE
G8=~/workspace/tools/solr-gradle8.sh
mkdir -p $OUT
exec 9>~/workspace/tools/.solr-test-queue.lock
flock 9
exec > >(tee -a $OUT/legs.log) 2>&1
echo "legs start UTC: $(date -u +%FT%TZ)"
pkill -f "Gradle[D]aemon" 2>/dev/null; sleep 2
rm -f ~/.gradle/caches/journal-1/journal-1.lock

copyxml() { # $1 clone, $2 label
  mkdir -p $OUT/$2-xml
  find $1 -path "*build/test-results/test/TEST-*.xml" -exec cp {} $OUT/$2-xml/ \; 2>/dev/null
  ls $OUT/$2-xml/ | head -8
}

cd $POS || exit 1
echo "POS HEAD: $(git rev-parse HEAD)"
git fetch -q https://github.com/apache/solr.git refs/pull/5301/head:refs/heads/pr5301h0 || echo "PR ref fetch failed"
echo "changed files H0..H2:"; git diff --name-only pr5301h0..HEAD | tee $OUT/changed-files.txt

# changelog validation
python3 dev-tools/scripts/validateChangelogs.py > $OUT/changelog.log 2>&1
echo "validateChangelogs rc=$?"
if grep -q "Traceback" $OUT/changelog.log; then
  echo "validator crashed; falling back to logchangeGenerate" | tee -a $OUT/changelog.log
  $G8 logchangeGenerate 9>&- >> $OUT/changelog.log 2>&1
  echo "logchangeGenerate rc=$?" | tee -a $OUT/changelog.log
fi

# Error Prone compile
echo "=== EP compile start UTC: $(date -u +%FT%TZ)"
$G8 :solr:solrj-zookeeper:compileJava :solr:core:compileTestJava -Pvalidation.errorprone=true 9>&- > $OUT/ep.log 2>&1
echo "EP compile rc=$?"

# Ordering suites
echo "=== ordering leg start UTC: $(date -u +%FT%TZ)"
$G8 :solr:core:cleanTest :solr:core:test --tests org.apache.solr.common.cloud.ConnectionManagerOrderingTest --tests org.apache.solr.cloud.ConnectionManagerTest -Ptests.seed=$SEED --rerun-tasks 9>&- > $OUT/ordering.log 2>&1
echo "ordering rc=$?"
copyxml $POS ordering

# SolrZkClientTest
echo "=== zkclient leg start UTC: $(date -u +%FT%TZ)"
$G8 :solr:solrj-zookeeper:cleanTest :solr:solrj-zookeeper:test --tests org.apache.solr.common.cloud.SolrZkClientTest -Ptests.seed=$SEED --rerun-tasks 9>&- > $OUT/zkclient.log 2>&1
echo "zkclient rc=$?"
copyxml $POS zkclient

# Nightly stress
echo "=== stress leg start UTC: $(date -u +%FT%TZ)"
$G8 :solr:core:cleanTest :solr:core:test --tests org.apache.solr.cloud.TestConnectionManagerReconnectStress -Ptests.nightly=true -Ptests.seed=$SEED --rerun-tasks 9>&- > $OUT/stress.log 2>&1
echo "stress rc=$?"
copyxml $POS stress

# Root check
pkill -f "Gradle[D]aemon" 2>/dev/null; sleep 2
rm -f ~/.gradle/caches/journal-1/journal-1.lock
echo "=== root check start UTC: $(date -u +%FT%TZ)"
cd $POS
$G8 check -x test 9>&- > $OUT/rootcheck.log 2>&1
echo "root check rc=$?"
echo "POS final status:"; git -C $POS status --porcelain

# Negative leg A: H1 tests, H0 ConnectionManager.java
cd $NEA || exit 1
echo "NEA HEAD: $(git rev-parse HEAD)"
git fetch -q https://github.com/apache/solr.git refs/pull/5301/head:refs/heads/pr5301h0 || echo "PR ref fetch failed (nega)"
git show pr5301h0:$CM > $CM || exit 1
git diff > $OUT/nega-baseline.diff
echo "nega CM sha256: $(sha256sum $CM | cut -d' ' -f1)" | tee $OUT/nega-hashes.txt
echo "nega test sha256: $(sha256sum $OT | cut -d' ' -f1)" | tee -a $OUT/nega-hashes.txt
echo "=== negative A start UTC: $(date -u +%FT%TZ)"
$G8 :solr:core:cleanTest :solr:core:test --tests org.apache.solr.common.cloud.ConnectionManagerOrderingTest.testExpiredReplacementDoesNotBlockRecovery -Ptests.seed=$SEED --rerun-tasks 9>&- > $OUT/nega.log 2>&1
echo "negative A rc=$?"
copyxml $NEA nega

# Negative leg B: acceptStateEvent returns true unconditionally
cd $NEB || exit 1
echo "NEB HEAD: $(git rev-parse HEAD)"
python3 - <<'PYEOF'
p = 'solr/solrj-zookeeper/src/java/org/apache/solr/common/cloud/ConnectionManager.java'
s = open(p).read()
old = """  private synchronized boolean acceptStateEvent(long sequence) {
    if (sequence < lastStateEventSequence) {
      return false;
    }
    lastStateEventSequence = sequence;
    return true;
  }"""
new = """  private synchronized boolean acceptStateEvent(long sequence) {
    return true;
  }"""
assert s.count(old) == 1
open(p, 'w').write(s.replace(old, new))
print('mutation applied')
PYEOF
git diff > $OUT/negb-mutation.diff
cat $OUT/negb-mutation.diff
echo "negb CM sha256: $(sha256sum $CM | cut -d' ' -f1)" | tee $OUT/negb-hashes.txt
echo "negb test sha256: $(sha256sum $OT | cut -d' ' -f1)" | tee -a $OUT/negb-hashes.txt
echo "=== negative B start UTC: $(date -u +%FT%TZ)"
$G8 :solr:core:cleanTest :solr:core:test --tests org.apache.solr.common.cloud.ConnectionManagerOrderingTest.testStaleDisconnectedDoesNotUndoConnectedState --tests org.apache.solr.common.cloud.ConnectionManagerOrderingTest.testStaleConnectedDoesNotUndoDisconnectedState --tests org.apache.solr.common.cloud.ConnectionManagerOrderingTest.testStaleConnectedDoesNotClearExpiredState -Ptests.seed=$SEED --rerun-tasks 9>&- > $OUT/negb.log 2>&1
echo "negative B rc=$?"
copyxml $NEB negb

echo "legs end UTC: $(date -u +%FT%TZ)"
