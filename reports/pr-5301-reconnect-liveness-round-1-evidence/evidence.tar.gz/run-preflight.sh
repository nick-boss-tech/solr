#!/bin/bash
# PR 5301 gate preflight: clones at H1 (positive, negative A, negative B), tidy at H1. Host lock held.
set -u
OUT=~/workspace/tools/gate-5301
H1=19579b2ed2397929c0cc903a6c682331cc865586
mkdir -p $OUT
exec 9>~/workspace/tools/.solr-test-queue.lock
flock 9
exec > >(tee -a $OUT/preflight.log) 2>&1
echo "preflight start UTC: $(date -u +%FT%TZ)"
pkill -f "Gradle[D]aemon" 2>/dev/null; sleep 2
rm -f ~/.gradle/caches/journal-1/journal-1.lock
for dir in 5301-pos 5301-nega 5301-negb; do
  d=~/workspace/solr-clones/$dir
  if [ -e "$d" ]; then echo "ABORT: $d already exists"; exit 1; fi
  git clone -q ~/workspace/solr "$d" || exit 1
  cd "$d" || exit 1
  git remote add fork https://github.com/nick-boss-tech/solr.git
  git fetch -q fork $H1 || exit 1
  git checkout -q $H1 || exit 1
  cp ~/workspace/solr/gradle.properties .
  echo "$dir HEAD: $(git rev-parse HEAD)"
  echo "$dir tree: $(git rev-parse HEAD^{tree})"
  [ -d .git ] && echo "$dir .git is a directory" || echo "$dir .git NOT a directory"
done
cd ~/workspace/solr-clones/5301-pos || exit 1
~/workspace/tools/solr-gradle8.sh tidy 9>&- > $OUT/tidy.log 2>&1
echo "tidy rc=$?"
git status --porcelain | tee $OUT/tidy-status.txt
if git status --porcelain | grep -q 'gradle/libs.versions.toml'; then
  git checkout -- gradle/libs.versions.toml
  echo "restored libs.versions.toml prune"
fi
echo "post-tidy status:"; git status --porcelain
git diff --check; echo "diff --check rc=$?"
echo "preflight end UTC: $(date -u +%FT%TZ)"
